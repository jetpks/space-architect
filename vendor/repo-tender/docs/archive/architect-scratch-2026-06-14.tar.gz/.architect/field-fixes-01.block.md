Execute the architect spec below. Operating rules:

PHASE 0 — Before any code: reply with your plan and EVERY disagreement you have
with this spec, with reasons, citing real files in this repo. Silent compliance
is a failure. Silent scope additions are a failure. If you have no
disagreements, state what you checked before concluding the spec is sound.
Verify the named APIs/formats/versions against the live dependencies before
planning around them — in particular, reproduce the actual `^C`/Open3
thread-noise behavior ONCE (e.g. spawn a `git` subprocess via `Open3.capture3`
inside a `Sync{}`/`Async{}` block that blocks on stdin, then kill it / send INT)
so you suppress the real thing, not a guess.

PHASE 1 — There are no new shared contracts to freeze in this slice (no schema /
interface changes). The files under docs/gates/ are read-only at all times —
editing them fails the slice regardless of results. Skip straight to PHASE 2.

PHASE 2 — Build exactly the files listed in BOUNDARIES, no others. You are the
only lane; you work in the main checkout. No placeholder implementations — search
the codebase before implementing; full implementations only. Verify your work by
running the gate commands and record the verbatim output. Do NOT commit and do
NOT run any git write command (commit/add/branch/reset/checkout/stash) — the
architect commits and merges after verification, and verifies you made no
commits. Note: `bin/repo-tender` is ALREADY modified in the working tree (the
`-W:no-experimental` shebang) — leave that change in place; do not revert it. Do
NOT delete lock files or escalate privileges if a command fails; record the exact
error and continue. Give every potentially long command an explicit timeout (the
suite runs in well under a minute; never busy-wait). When done, write your lane
report to docs/lanes/field-fixes-01.md with RAW results only — tables, numbers,
command output — no interpretation, no "promising". Every status claim must be
backed by a command result from this run. Keep the report compact. End it with
exactly one status line:
STATUS: COMPLETE | COMPLETE_WITH_CONCERNS (list them) | BLOCKED (exact blocker +
what you tried). Verdicts belong to the architect and the human. Persist until
your lane is fully handled end-to-end; do not stop at analysis or partial fixes.

=== OBJECTIVE (and why) ===
The project was PRD-complete, but the FIRST real `repo-tender sync` on a clean
machine surfaced three field defects. Close all three:

1. SSH transport. `lib/repo_tender/sync/engine.rb` `DEFAULT_URL_BUILDER` builds
   `https://<host>/<owner>/<name>.git`, so cloning a missing repo prompts
   `Username for 'https://github.com':`. Change the default to the scp-like SSH
   form `git@<host>:<owner>/<name>.git` so git uses the user's SSH keys with no
   interactive prompt. This is the seam the Slice 2 disagreement-#6 ruling
   anticipated. DO NOT add a config field or make transport configurable — SSH
   default only; that is the entire change to the builder.

2. Clean `^C`. SIGINT during a clone/fetch (e.g. at the git username prompt)
   kills the `git` child; `Open3.capture3`'s internal reader threads then raise
   `IOError: stream closed in another thread` and print backtraces (because
   `Thread.report_on_exception` is on), and there is no top-level `Interrupt`
   rescue so the main thread dumps a trace too. A user ^C must get a clean exit
   (code 130, at most one human line), with ZERO Ruby backtraces and none of the
   `report_on_exception` / `stream closed in another thread` noise. Suppress
   ONLY interrupt noise — genuine non-interrupt failures must still surface
   through the existing Result/exit-code/last_error paths. Do NOT blanket-rescue
   StandardError and do NOT make failures exit 0.

3. Binstub warning (already done). `bin/repo-tender` already carries the
   `-W:no-experimental` shebang (working-tree change). Leave it as-is; the
   architect commits it with this slice. No further action needed beyond not
   reverting it and confirming the binary still runs.

Full intent, scope guards, and the no-data-loss/atomicity constraint are in the
frozen gate file docs/gates/field-fixes.md — read it in full first.

=== OUTPUT FORMAT (docs/lanes/field-fixes-01.md) ===
Raw evidence only:
- PHASE-0 plan + disagreements table (with file:line citations) + your rulings'
  inputs (you propose; the architect decides).
- For each gate G0–G4: the exact command(s) run and verbatim output (or the
  relevant tail), plus pass/fail per the gate's own threshold (your reading is
  hearsay — the architect re-runs).
- G1: the printed default URL string.
- G2/G3: the interrupt test(s) you added, their output, and — for G3 — your
  suppression mechanism + the justification that it is targeted (no app-owned
  worker threads hidden). If you concluded G3 cannot be made deterministic
  offline, say so with the exact reason.
- `git diff --name-only af847d6..` (the freeze sha) — must list only in-scope
  files. `git status`. Confirm you made no commits.
- The new `DEFAULT_URL_BUILDER` source line and the interrupt-handling diff,
  quoted.
- End with the single STATUS line.

=== TOOL GUIDANCE (verification commands; verify-against-reality list) ===
- Build/test (from AGENTS.md): `bundle install`; `bundle exec rake test` (expect
  failures=0 errors=0 skips=0); `bundle exec standardrb` (exit 0);
  `bundle exec standardrb --fix` to autoformat. Single file:
  `bundle exec ruby -Itest test/path/to/foo_test.rb`.
- G1 reproducer command is in the gate file (prints the default URL).
- Verify against reality BEFORE coding: reproduce the Open3 reader-thread
  `IOError` once so your suppression targets the real mechanism; confirm scp-like
  `git@host:owner/name.git` is the SSH form git/`gh` use (the form that needs no
  username); confirm `CLI.run` (lib/repo_tender/cli.rb) is the entrypoint
  Dry::CLI dispatch happens in and that it already calls `Kernel.exit`.
- Existing seams to reuse: `test/repo_tender/cli/test_helper.rb` has `run_cli`
  (spawns the real `bin/repo-tender` via `Open3.capture3` and returns
  [stdout,stderr,status]); `engine_test.rb` ~L488 injects a `file://` url_builder
  (this is the regression to keep green unmodified); `RepoTender::CLI::Registry`
  is where commands register (a throwaway interrupt-raising command can register
  here for a unit-level test). `lib/repo_tender/shell.rb` is the single
  `Open3.capture3` call site.

=== BOUNDARIES (may touch / must not touch / out of scope) ===
MAY TOUCH:
- lib/repo_tender/sync/engine.rb  (DEFAULT_URL_BUILDER only)
- bin/repo-tender                 (preserve the shebang; add interrupt handling here if you choose)
- lib/repo_tender/cli.rb          (top-level Interrupt rescue — preferred testable seam)
- lib/repo_tender/shell.rb        (Open3 reader-thread noise suppression if you choose)
- test/repo_tender/sync/engine_test.rb
- test/repo_tender/cli/sync_test.rb
- test/repo_tender/cli/test_helper.rb        (only if you need a new spawn/seam helper)
- test/repo_tender/shell_test.rb
- test/repo_tender/cli/interrupt_test.rb     (NEW file — allowed)

MUST NOT TOUCH: everything else — lib/repo_tender/scm/*, forge/*, config/*,
state/*, launchd/*, sync/repo_plan.rb, paths.rb, log_rotator.rb,
cli/{repo,org,status,config,daemon}.rb, lib/repo_tender.rb, version.rb, the
gemspec, test/test_helper.rb, any other test_helper.rb, and anything under
docs/gates/.

OUT OF SCOPE: a configurable transport/url_template/token-auth config field;
any `ssh://` vs scp-like toggle; touching the no-data-loss state-write path;
refactors beyond the three fixes; the hardcoded abs path in daemon_test.rb (not
yours this slice).

=== DISAGREEMENT RULINGS (from last session) ===
None — this is the first dispatch of this slice. Raise yours in PHASE 0.

=== ACCEPTANCE GATES (frozen at docs/gates/field-fixes.md — read-only) ===
Read docs/gates/field-fixes.md in full. Gates: G0 suite/lint/no-new-gems; G1 SSH
default URL (`git@github.com:foo/bar.git`); G2 deterministic clean-^C exit-130
test (+ real-failure-still-exits-1 guard); G3 Open3 thread-noise suppression
(best-effort automated + targeted-mechanism justification); G4 in-scope files /
no builder commits. Plus the M1/M2/M3 manual checklist (human-run; not yours).
The freeze sha for the in-scope diff check is af847d6.
