You are a web research agent. Answer ONE narrow objective. Do not write code, do
not make recommendations. Budget: 12 searches; if two consecutive searches
yield no new load-bearing facts, STOP and return. HARD CONTEXT RULES: never
open a full page when the search snippet answers the question; quote at most 2
sentences per source; the MOMENT you can answer, STOP and write findings —
partial findings beat context exhaustion (agents that fill their window die
without writing anything, returning NOTHING). Do NOT fetch more than ~5 full
pages total; prefer search snippets and RubyGems/GitHub metadata. OUTPUT:
markdown — every finding carries source URL, source date, exact figure or short
quote, confidence tag (high=primary / med=reputable secondary / low=single
blog). Record exact gem versions + dates. Report disagreements; never resolve.
NOT FOUND beats inference. End with the 2-3 findings most likely to change a
design decision.

CONTEXT: A Ruby 4.0.5 daemon on macOS (Apple Silicon) using socketry/async must
shell out to `git`/`gh` repeatedly and capture stdout/stderr/exit status
WITHOUT blocking the async reactor. Ruby 4.0 has a mature Fiber scheduler.

OBJECTIVE — Only the SUBPROCESS-EXECUTION question. Determine the current
(2026) correct, idiomatic way to run an external command under Async and
capture its output non-blockingly.

1. Does the `async-process` gem exist (github socketry/async-process,
   rubygems.org/gems/async-process)? Current version, last release date,
   maintenance status, and its API for running a command and getting
   stdout/stderr/exit. If it does NOT exist or is abandoned, say so explicitly.

2. Does plain stdlib `Open3.capture3` / `IO.popen` automatically yield to the
   Async reactor when run inside an `Async do ... end` block — i.e. does Async's
   Fiber scheduler hook process IO and `Process.wait`? Cite Async docs or
   socketry source. Does the Ruby Fiber::Scheduler interface define
   `process_wait`, and does the `async` gem implement it? (search: "async ruby
   process_wait scheduler", "Async Open3 non-blocking", "io-event process").

3. `io-event` backend on macOS: io_uring is Linux-only — confirm io-event uses
   kqueue on Darwin, and whether subprocess pipe IO is handled by the
   selector. Current `io-event` gem version + date.

Subjects (cap 3): socketry/async-process, the async gem's scheduler/process
handling, socketry/io-event. Stay narrow — do NOT investigate daemon structure
or concurrency primitives (a separate lane covers those).

End with the 2-3 findings most likely to change our design.
