I have enough data now. Let me write the findings.

---

# Research Findings: dry-rb CLI + Persisted Config Patterns (2026)

All evidence collected between 2026-04 and 2026-06. Dates shown are release/publication dates as observed on primary sources.

---

## 1. dry-cli — current version, structure, subcommand nesting

**Versions (rubygems.org, source: high):**
- `dry-cli` **1.4.1** released **2026-01-21**; **1.4.0** released **2026-01-09**.
- v1.4.0 explicitly **"Require Ruby 3.2 or later"** (timriley).
- https://rubygems.org/gems/dry-cli/versions
- https://github.com/dry-rb/dry-cli/releases/tag/v1.4.0

**Idiomatic CLI structure (source: high — dry-rb.org docs):**
- One module extended with `Dry::CLI::Registry`. Commands are subclasses of `Dry::CLI::Command` that respond to `#call(*)`.
- Registry keyword: `module Commands; extend Dry::CLI::Registry; ...; end` then `Foo::CLI::Commands.register "name", CommandClass`. Entry point: `Dry::CLI.new(Foo::CLI::Commands).call`.
- https://dry-rb.org/gems/dry-cli/1.0/commands/
- https://dry-rb.org/gems/dry-cli/1.0/subcommands/

**Nested subcommands (v1.3+; source: high — release notes + docs):**
- Since v1.3.0 (2025-07-29) "Support unlimited nesting when registering commands via `register` with blocks" (aaronmallen, PR #149). Prior to that only fully-qualified strings worked.
- Block form (current idiom):
  ```ruby
  Commands.register "repo" do
    register "add",    Repo::Add
    register "remove", Repo::Remove
    register "list",   Repo::List
  end
  Commands.register "daemon" do
    register "start",   Daemon::Start
    register "stop",    Daemon::Stop
    register "restart", Daemon::Restart
    register "status",  Daemon::Status
  end
  ```
- "If you call a command with an argument equal to the name of the subcommand, it will call the subcommand instead of the parent command." Arguments and options are declarable on both parent and child commands.
- https://github.com/dry-rb/dry-cli/blob/main/CHANGELOG.md
- https://dry-rb.org/gems/dry-cli/main/commands-with-subcommands-and-params/

**v1.4.0 added (high):** "Provide the CLI's `out` and `err` streams to command instances (unless `@out` and `@err` ivars already exist in the command)" — relevant for capturing output in tests / for the daemon.
- https://github.com/dry-rb/dry-cli/releases/tag/v1.4.0

---

## 2. CONFIG PERSISTENCE in dry-rb — the load + validate + write-back picture

### 2a. `dry-configurable` is **in-memory only — no file write-back** (source: high)

- Latest `dry-configurable` is **1.3.0 (2025-01-06)**. It is a mixin: `extend Dry::Configurable`, then `setting :foo, default: ...`. It manages in-process settings, not file I/O.
- https://rubygems.org/gems/dry-configurable/versions
- https://dry-rb.org/gems/dry-configurable/1.0/
- v1.0.0 changelog documents the canonical LOAD pattern:
  ```ruby
  class App
    extend Dry::Configurable
    setting :db do
      setting :host
      setting :port
    end
    config.update(YAML.load(File.read("config.yml")))
  end
  ```
  i.e. the gem **expects YOU to call `YAML.load` (or `JSON.parse`) yourself and hand the hash to `config.update`**. There is **no built-in `to_yaml` / `save` / `write` method** anywhere in the gem (verified: no `write_yaml_file` or `to_yaml` in the public surface; only "alienfast/dry-config" — a separate, unrelated 3rd-party gem — has a `#write_yaml_file` method).
- https://github.com/dry-rb/dry-configurable/blob/main/CHANGELOG.md
- https://www.rubydoc.info/gems/dry-config/1.2.1/Dry/Config/Base  ← unrelated `alienfast/dry-config`; do not confuse with `dry-rb/dry-configurable`.

**Verdict (high confidence):** `dry-configurable` is the wrong tool for "user-editable AND machine-mutable" persisted config. It will hold an in-process mirror of the file, but the file I/O is your problem. The dry-rb team has NOT blessed a persistence story for it.

### 2b. `dry-schema` (validate loaded config) — current version (source: high)

- `dry-schema` **1.16.0** released **2026-03-03** (set minimum Ruby 3.x; UUID v6/v8 predicates; JSON Schema export extension `:json_schema`).
- https://github.com/dry-rb/dry-schema/blob/main/CHANGELOG.md
- https://github.com/dry-rb/dry-schema/releases
- Two schema flavors matter here:
  - **`Dry::Schema.Params`** — coerces from stringified HTTP-form-style input (coerces with `Types::Params`).
  - **`Dry::Schema.JSON`** — coerces from JSON-shaped input (uses `Types::JSON`, stricter — e.g. will not silently coerce strings to integers).
  - For a YAML/JSON/TOML config file you parsed, **`JSON` is the more appropriate choice** because YAML/JSON/TOML parsed values are already real integers/booleans/strings and you do NOT want the loose string→int coercion that `Params` does. The official docs explicitly say "The difference between Params and JSON is coercion logic."
  - https://dry-rb.org/gems/dry-schema/main/params/
  - https://hanakai.org/learn/dry/dry-schema/v1.14/json
- For pure shape/type checking of config, `Dry::Schema.JSON` is the idiomatic pick. Reach for `Dry::Validation::Contract` only when you need cross-field business rules (e.g. "if A is set, B must be set"); the `Contract` itself wraps a `Schema`.

### 2c. `dry-validation` — current version (source: high)

- `dry-validation` **1.11.1** released **2025-01-21** (set minimum Ruby 3.1).
- https://rubygems.org/gems/dry-validation
- https://github.com/dry-rb/dry-validation/blob/main/CHANGELOG.md
- Stable, but **no new release in 2026 yet** (as of 2026-06). This is worth flagging — it's the slowest-moving piece of the dry-rb stack.

### 2d. `dry-types` + `dry-struct` — in-memory config model (source: high)

- `dry-struct` **1.8.1** released **2026-03-03**; `1.8.0` **2025-03-09**.
- https://github.com/dry-rb/dry-struct/blob/main/CHANGELOG.md
- https://rubygems.org/gems/dry-struct/versions
- Common pattern: `Dry::Schema.JSON` does the *first-pass validation/coercion*, then you `Dry::Struct` to give yourself a typed read API with attribute accessors. dry-struct depends on dry-types under the hood. No release-date info needed for `dry-types` itself here; it ships in lockstep with dry-struct.

### 2e. The round-trip WRITE — **dry-rb has no blessed tool, period** (source: high)

After searching, there is no `dry-config` writer, no `dry-persistence`, no official round-trip helper. The idiomatic 2026 pattern for a CLI that mutates a user-owned config file is:

1. Parse (Psych / JSON / TOML gem) → plain hash
2. Validate with `Dry::Schema.JSON` (or `Dry::Validation::Contract` if business rules)
3. Coerce/load into `Dry::Struct` for the in-memory model
4. Mutate the struct
5. Serialize the struct back to a hash (`to_h`) and **write it yourself** with `YAML.dump` / `JSON.pretty_generate` / TOML writer
6. Optionally: pretty-print, atomic write (`File.rename` over a tempfile), preserve permissions

This is the gap that `anyway_config` / `myway_config` and the `psych-pure` / `rb-toml-kit` ecosystem exist to fill (see §4, §5).

---

## 3. dry-monads — current idiom for CLI command outcomes (source: high)

- `dry-monads` **1.10.0** released **2026-04-24** (adds JRuby support; fixes param names in API doc examples).
- https://github.com/dry-rb/dry-monads/releases/tag/v1.10.0
- https://rubygems.org/gems/dry-monads/versions
- Standard 2026 idiom for fallible CLI/operation pipelines:
  ```ruby
  class SyncRepo
    include Dry::Monads[:result, :do]
    def call(repo)
      config      = yield load_config(repo)   # returns Success(config) or Failure(:missing)
      validated   = yield validate(config)     # Failure([:invalid, errors]) on bad
      remote_data = yield fetch_remote(repo)   # Failure([:network, e]) on error
      Success(persist(validated.merge(remote_data)))
    end
  end
  ```
  The CLI command `#call` unwraps the final `Result` and maps to exit code + stderr.
- https://dry-rb.org/gems/dry-monads/main/do-notation/ (current `main` docs version)
- Pattern matching on `Success(...)` / `Failure(...)` is supported in Ruby 3+ and integrates cleanly. https://dry-rb.org/gems/dry-monads/1.6/pattern-matching/

---

## 4. XDG PATHS in Ruby — `xdg` gem (source: high)

- `xdg` (a.k.a. ruby-xdg, by Brooke Kuhlmann) **10.2.0** released **2026-04-17**; **10.1.0** 2026-01-18; **10.0.0** 2026-01-01. **76 releases since 2008, actively maintained.**
- https://rubygems.org/gems/xdg/versions
- https://github.com/bkuhlmann/xdg
- API: `XDG['CONFIG_HOME']`, `XDG['DATA_HOME']`, `XDG['CACHE_HOME']`, `XDG['STATE_HOME']`, `XDG['CONFIG_DIRS']`, `XDG['DATA_DIRS']`, `XDG['RUNTIME_DIR']` — returns a `Pathname` joined with your app name. Backed by the freedesktop XDG Base Directory Specification.
- https://www.rubydoc.info/gems/xdg/frames
- Debian ships it as `ruby-xdg` (currently `10.2.0-2`): https://tracker.debian.org/pkg/ruby-xdg

**NOT FOUND:** Any "official" Ruby standard-library path-resolution mechanism. People still reach for `ENV.fetch("XDG_CONFIG_HOME", "~/.config")` by hand, but **the `xdg` gem is the maintained, idiomatic answer in 2026** (and it's tiny — 17 KB, zero runtime deps).

**Companion: `anyway_config` 2.8.0 (2026-01-28)** and its `myway_config` 0.1.2 wrapper (2026-01-24) provide XDG-aware multi-source config loading (YAML + env vars + Rails credentials). `anyway_config` does NOT do file write-back either — but it standardizes the **load** side. Pair with `psych-pure` / `rb-toml-kit` for the **write** side if you need comment preservation.
- https://rubygems.org/gems/anyway_config
- https://github.com/palkan/anyway_config
- https://github.com/MadBomber/myway_config

---

## 5. CONFIG FILE FORMAT — round-trip & comment preservation

### YAML (Psych, stdlib) — does **not** preserve comments; insertion order preserved (source: high)

- `Psych.dump` (stdlib) **discards all comments** on write. This is by design — the YAML spec says "comments are presentation details". Quote: "Ruby's standard YAML library (Psych) doesn't preserve comments … This isn't a bug; the YAML spec treats comments as 'presentation details' that parsers may discard, and most do." — https://blog.discourse.org/2026/02/how-we-fixed-yaml-comment-preservation-in-ruby-and-why-we-sponsored-it/
- Ruby Hashes preserve insertion order since 1.9, so `Psych.dump` writes keys in insertion order, but you still lose all `# comments` and blank-line formatting on round-trip.
- https://docs.ruby-lang.org/en/master/Psych.html

**Solution in 2026 — `psych-pure` 0.3.1 (2026-04-03)** by Kevin Newton (the maintainer of Psych). "YAML 1.2 parser and emitter, pure Ruby, preserves comments on load and dump." Sponsorship by Discourse (Feb 2026 blog post) stabilized it. Only 8 versions, all in 2025–2026, so it's new but actively maintained and now considered production-ready by a major Ruby user.
- https://github.com/kddnewton/psych-pure
- https://rubygems.org/gems/psych-pure/versions
- https://kddnewton.com/2025/12/25/psych-pure.html

**Older alternative:** `wantedly/psych-comments` (last push 2024-08) — works but is less actively maintained. https://github.com/wantedly/psych-comments

### JSON (stdlib) — does **not** preserve comments (JSON has no comment syntax); preserves key insertion order

- `JSON.pretty_generate` round-trips fine for structure and key order. No comments exist to preserve (JSON spec doesn't define them). Fine for machine-mutated configs.

### TOML — three viable gems, divergent on comment preservation (source: high)

- **`toml-rb` 4.2.0 (2026-04-26)** by emancu — Citrus-parser based, **TOML 1.0 compliant, does NOT preserve comments on dump** (parses comments only via separate `toml-rb-comments` style extension if any). https://github.com/emancu/toml-rb
- **`tomlrb` 2.0.4 (2025-12-18)** by fbernier — Racc-based, TOML 1.0 compliant, **does NOT preserve comments**. https://github.com/fbernier/tomlrb
- **`tomlib` 0.7.3 (2024-11-29)** by kgiszczak — fast native C extension (tomlc99), TOML 1.0 compliant, **does NOT preserve comments**; last release ~18 months old → **lowest activity of the three**. https://github.com/kgiszczak/tomlib
- **`philiprehberger/rb-toml-kit`** — newer (2025+) "TOML v1.0 parser and serializer with **comment preservation**, schema validation, merging, querying, type coercion, and diffing." `TomlKit.parse_with_comments(toml)` returns a `CommentDocument` that round-trips comments. This is the TOML equivalent of `psych-pure` / Python's `tomlkit`. https://github.com/philiprehberger/rb-toml-kit

**Verdict (high confidence):** Of the three "main" TOML gems, only the Citrus-based **`toml-rb` 4.2.0** is actively developed in 2026 and is the safe default; for comment preservation use `rb-toml-kit`.

---

## Cross-cutting observations

- The dry-rb suite (as of mid-2026) has a clear validation / typing story and a clear CLI story, **but no blessed "persisted user config" story**. `dry-configurable` is for in-app settings, not for files.
- The 2026 ecosystem has converged on a two-piece pattern: **dry-rb for the in-memory model + validation**, and a **comment-preserving parser** (psych-pure for YAML, rb-toml-kit for TOML) for the I/O layer, with `xdg` + `anyway_config` for path resolution and multi-source loading.

---

## Top 3 findings most likely to change a design decision

1. **`dry-configurable` will NOT write your config file back — ever.** It has `config.update(hash)` for the load path and zero write/serialize methods. If the design assumed "use dry-configurable to own the config file end-to-end," it is wrong: dry-configurable is a thread-safe in-memory settings store. The write-back has to be hand-rolled (YAML/JSON/TOML dump + atomic file replace). (Confidence: high; verified by reading the official docs, changelog, and source — the alienfast `dry-config` gem with `#write_yaml_file` is a separate, unrelated project.)

2. **YAML and TOML both lose comments on a vanilla stdlib round-trip — but in 2026 there are now production-grade solutions:** `psych-pure` 0.3.1 (sponsored by Discourse, 2026-04) for YAML, and `rb-toml-kit` for TOML. If the design assumes "user edits a hand-written config, CLI rewrites it, and we want to preserve their comments / key order," we can do that in Ruby 4.0 — but only with one of these specific gems, not with the obvious stdlib choice. (Confidence: high; both gems are recent and well-documented, but the ecosystem is still young — only ~14 months of `psych-pure` history.)

3. **`dry-cli` v1.3+ supports unlimited nested subcommand registration via blocks** (released 2025-07-29; the v1.4 series 2026-01 added stream injection). The `repo add|remove|list` / `daemon start|stop|restart|status` shape maps 1:1 onto the modern `register "repo" do ... end` block syntax. The design should target v1.4.x, which requires **Ruby ≥ 3.2** — perfectly compatible with Ruby 4.0.5. (Confidence: high; verified against release notes and main-branch docs.)
