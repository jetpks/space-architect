I have enough findings. Let me compile the research output.

---

# Research: Async subprocess execution on Ruby 4.0.5 / macOS (Apple Silicon)

## 1. `async-process` gem

**Exists. Alive but quiet.**

- **Repo:** https://github.com/socketry/async-process
- **RubyGems:** https://rubygems.org/gems/async-process
- **Current version:** **1.4.0** — released **November 8, 2024**
- **Last push:** 2024-11-08 (same date as the 1.4.0 release)
- **License:** MIT. Owner: `ioquatix` (Samuel Williams). 25 stars. 0 open issues.
- **Maintenance status:** Slow but not abandoned. No 1.5.0 in ~19 months. Recent re-packaging activity in Debian (1.4.0-2, March 2026) shows the package is still in distros, not orphaned.
- **Confidence:** high (primary: rubygems + GitHub metadata).

**API (from `lib/async/process.rb`):**

```ruby
Async::Process.spawn(*args, **opts)    # → Process::Status, no captured output
Async::Process.capture(*args, **opts)  # → String (stdout only, no stderr, no status)
```

`capture` returns **stdout only** — no stderr, no exit status, no streaming. It internally uses `kernel/sync` to read the pipe synchronously while the child runs in an `Async do` block. (Source: https://github.com/socketry/async-process/blob/main/lib/async/process.rb — confirmed by direct file read.)

**Internal mechanism (`lib/async/process/child.rb`):** spawns the child, then creates a dedicated **thread** that does `Process.wait2(@pid)` and closes a notification pipe. The current task blocks on a `read(1)` from that pipe. **The thread is redundant on modern Async** — see §2.

The README still contains the stale line: *"Internally, we use a thread, since `nio4r` doesn't support monitoring pids."* nio4r is no longer in the stack; `io-event` does support pids natively (pidfd on Linux, `EVFILT_PROC` on macOS).

---

## 2. Does `Open3.capture3` / `IO.popen` yield to the Async reactor?

**Yes — automatically, on the current Async (≥ ~v2.24, July 2024).**

Mechanism:

1. `Process.wait` and `Process.wait2` are Ruby's standard blocking calls. In Ruby 3.0+ they invoke `Fiber::Scheduler#process_wait(pid, flags)` if a scheduler is set. Confirmed in Ruby source (`rb_fiber_scheduler_process_wait`) and in the Fiber::Scheduler docs: *"Invoked by `Process::Status.wait` in order to wait for a specified process."* (https://docs.ruby-lang.org/en/3.4/Fiber/Scheduler.html)
2. `Open3.capture3` → `Open3.popen3` → `Process.spawn` + read pipe + `Process.wait2` → all three are scheduler-aware.
3. `IO#read` on the capture pipe → `io_wait` hook when the pipe is empty.
4. The Async scheduler's current implementation (master, `lib/async/scheduler.rb`):

   ```ruby
   def process_wait(pid, flags)
     return @selector.process_wait(Fiber.current, pid, flags)
   end
   ```
   (Confirmed verbatim from source: https://github.com/socketry/async/blob/master/lib/async/scheduler.rb)

   ```ruby
   def io_wait(io, events, timeout = nil)
     ...
     return @selector.io_wait(fiber, io, events)
   end
   ```

   Both delegate to `IO::Event::Selector`, which on macOS is the KQueue selector (see §3).

5. **Historical caveat:** in `async 1.28.x` (2022) `process_wait` was `Thread.new { ::Process::Status.wait(pid, flags) }.value` — a true blocking thread. This was refactored to delegate to the selector at some point before v2.24.0 (July 2024). On current `async` (v2.39.0, April 2026), the scheduler is genuinely non-blocking — **no thread is spawned for `Process.wait` inside an `Async do ... end` block.** (Confidence: high — verified by reading master source and the v2.24.0→v2.25.0 diff.)

So: `Open3.capture3("gh", "issue", "list", ...)` inside an `Async do` block on macOS will use kqueue's `EVFILT_PROC` + kqueue's `EVFILT_READ` for the pipe — true kernel-level non-blocking, no extra thread.

---

## 3. `io-event` on macOS

**io_uring is Linux-only. On macOS, `io-event` uses kqueue. Subprocess pipe IO is fully kqueue-handled.**

- **Current version:** **`io-event 1.16.2`**, released **June 13, 2026** (1 month before this research). (Source: https://rubygems.org/gems/io-event, confirmed via direct read.)
- **License:** MIT. Owner: `ioquatix`. Active: 4 releases in 2026 alone (1.16.0/1/2 + 1.15.x).
- **Required Ruby:** ≥ 3.3. (Compatible with Ruby 4.0.5.)

**Selector auto-selection** (`lib/io/event/selector.rb`):

```ruby
def self.default(env = ENV)
  if name = env["IO_EVENT_SELECTOR"]&.to_sym
    return const_get(name)
  end
  if self.const_defined?(:URing)   # Linux 5.6+ with io_uring
    URing
  elsif self.const_defined?(:EPoll)  # Linux
    EPoll
  elsif self.const_defined?(:KQueue) # macOS/BSD
    KQueue
  else
    Select                          # pure-Ruby fallback
  end
end
```

**On macOS, KQueue is used. There is no `URing` class defined in the C extension when compiling for Darwin.**

**Native process wait on macOS** (`ext/io/event/selector/kqueue.c:225-228`):

```c
kevents[count].filter = EVFILT_PROC;
kevents[count].flags  = EV_ADD | EV_ONESHOT;
kevents[count].fflags = NOTE_EXIT;
```

`IO_Event_Selector_KQueue_process_wait` (line 475) registers the pid with kqueue using `EVFILT_PROC | NOTE_EXIT`, then transfers control back to the reactor. The fiber resumes when the kernel fires the exit event. **This is a real kernel event, not a thread fallback.** Edge cases: a single `process_prewait(pid)` (blocking `waitid(WNOWAIT)`) runs only if the process has already exited at registration time (zombie; `ESRCH`).

**Pipe IO on macOS:** standard kqueue `EVFILT_READ` / `EVFILT_WRITE` readiness for any fd (see `kqueue.c:185-189` mapping). Works for normal pipes, sockets, and files. There are known issues with **TTYs/ptys** (async issue #301: `Errno::EINVAL: Invalid argument - IO_Event_Selector_KQueue_io_wait:IO_Event_Selector_KQueue_Waiting_register`) but **`gh`/`git` stdout pipes are fine.**

(Confidence: high — verified by reading the C source directly.)

---

## Disagreements / tensions

- **async-process README is stale.** It cites nio4r, but the actual stack is io-event; the "use a thread" reasoning no longer applies. async-process is *not broken* (the thread path still works), but its design is now strictly worse than the underlying scheduler hook.
- **No single "officially recommended" gem for async subprocess in 2026.** The Async docs do not mention `async-process`. The canonical example in the Async project is `Open3`/`Process.spawn` with no extra gem (see async issue #73 where the maintainer shows that `IO.pipe` + `Process.spawn` + `pipe_r.gets` works under the reactor with no extra dependency).
- **Older blog posts (pre-mid-2024)** that say "use async-process" or "spawn a thread for `Process.wait`" are out of date. Don't trust them.

---

## Top 2–3 findings that should change a design decision

1. **`async-process` is optional, not required.** Plain `Open3.capture3` / `Open3.capture2` / `IO.popen` inside an `Async do` block are already non-blocking on macOS — `Process.wait2` and `IO#read` both flow through the fiber scheduler into kqueue (`EVFILT_PROC | NOTE_EXIT` for the wait, `EVFILT_READ` for the pipe). Drop the `async-process` dependency unless you specifically want its 1.4.0-era `Async::Process.capture` API (which loses stderr and exit status anyway). **Implication: simpler code, no extra gem, full access to stdout/stderr/exit.**

2. **async v2.24+ process_wait is genuinely non-blocking — no thread.** Older design notes that recommend "spawn a thread per shell-out so the reactor doesn't block" are obsolete as of mid-2024. On macOS Apple Silicon with the current stack (`async ≥ ~2.24` + `io-event ≥ 1.6.5`), `Process.wait` is a real kqueue event, latency-bounded by the kernel, not by a Ruby thread. A thread-per-shellout model adds GVL contention and a thread-creation cost per `gh`/`git` call with no benefit.

3. **macOS path uses `KQueue` selector, confirmed native.** `io-event 1.16.2` (June 13, 2026) compiles KQueue on Darwin and uses `EVFILT_PROC` for process exit and standard kqueue readiness for pipe IO. There is no Linux-only dependency leaking into the macOS fast path. The only known macOS friction is with **TTYs/ptys** (issue #301) — not relevant for `gh`/`git` whose stdout is a plain pipe. **No design change required for macOS Apple Silicon; the fast path is real.**
