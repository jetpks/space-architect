I have sufficient information from primary sources. Let me write the findings.

---

# Git & gh CLI Mechanics for Evergreen Local Clones

## 1. Clean-State Detection (`git status --porcelain`)

### v1 vs v2 trade-off
- **`--porcelain=v1`** (default for `--porcelain`): path-relative lines `<XY> <path>` or `<XY> <orig> -> <path>` for renames. No header. Tracked entries have spaces in `XY`; untracked use `??`; submodules in v1 are flattened to `M` (no `m` or `?` distinction).
- **`--porcelain=v2`**: prefixed line-types (`1`/`2`/`u` for ordinary/rename-copied/unmerged), 8 fixed-width fields, plus optional `#` header lines from `--branch` and `--show-stash`. Parsers should "ignore headers they don't recognize" — extensible by design. Submodule state is preserved in the 4-char `<sub>` field.
- Both ignore `color.status` and `status.relativePaths` config (paths are always repo-root relative).

### Header lines (only emitted with `--branch` in v2)
```
# branch.oid <commit>          (or "(initial)" on unborn)
# branch.head <branch>         (or "(detached)")
# branch.upstream <upstream>   (only if upstream configured)
# branch.ab +<ahead> -<behind> (only if upstream + commit is present)
```
These are the canonical machine-readable source for current branch, upstream, ahead/behind. Confidence: high. Source: https://git-scm.com/docs/git-status (v2 spec).

### "Clean" semantics
- **v1**: empty stdout ⇒ clean. Any non-empty line (including `??` for untracked) ⇒ not clean. Ignored files (`.gitignore` matches) are NOT printed unless `--ignored` is given.
- **v2**: same. With `--branch` you can still detect clean (only headers, no `1`/`2`/`u`/`?`/`!` body lines). With `--show-stash` you also get `# stash <N>` only if N>0.

### Untracked / Ignored in v2
Source: `wt_porcelain_v2_print_other` in `wt-status.c:2524-2542`.
```
fprintf(s->fp, "%c %s%c", prefix, path, eol_char);
```
- Untracked line: `? <quoted-path>\n` (path is C-quoted per `core.quotePath`; with `-z` the path is raw and lines terminate in NUL).
- Ignored line: `! <quoted-path>\n` (only with `--ignored[=…]`; `traditional` mode shows whole directories unless `--untracked-files=all`).
- Confidence: high (source-verified).

### `--untracked-files` matrix
- `normal` (default): show untracked files/dirs but hide empty dirs and files inside ignored dirs.
- `all`: also show individual files inside ignored directories and deeply nested untracked files.
- `no`: no untracked output at all. **This is the right flag to make "clean" mean "no modified/staged/deleted"** (still see `?` lines only if they exist).

### Submodule gotchas
- v1 collapses all submodule state to `M`. To detect "submodule is dirty" use **v2** (look at `<sub>` = `SMMU`, `S..U`, `S.M.`, etc.) or run `git submodule status --recursive`. v2 also reports submodule HEAD change vs index as the first `XY` letter (e.g. `MM`).
- Default `ignoreSubmodules` config can mask dirty submodules; pass `--ignore-submodules=none` to force full reporting. Confidence: high (v2 spec).

### Recommended clean-detection command
```sh
git -C "$REPO" status --porcelain=v2 --branch --untracked-files=no
# → clean iff: no `1` / `2` / `u` lines AND `# branch.head <default>` matches
# AND no `# branch.ab` line is present (or `+0 -0`).
```

---

## 2. Remote Default-Branch Detection

Four options, ranked by cost and reliability:

| Method | Network? | Output | Gotchas |
|---|---|---|---|
| `git symbolic-ref refs/remotes/origin/HEAD` | **No** | `<target-ref>` on stdout, non-zero exit if ref missing | **Most reliable local-only** — reads the local symbolic ref written by `git clone` or `git remote set-head`. Confidence: high (primary). |
| `git rev-parse --abbrev-ref origin/HEAD` | **No** | `origin/<branch>` (or `origin/HEAD` if unset, or fatal error if origin unknown) | Shortcut for symbolic-ref deref. Same caveat: requires the ref to exist locally. Confidence: high. |
| `git remote set-head origin -a` | **Yes** (queries remote) | prints `origin/HEAD set to refs/remotes/origin/<branch>` after setting the local symref; also errors with `Couldn't find remote ref HEAD` if server doesn't advertise it | Side-effect: writes `refs/remotes/origin/HEAD`. **Idempotent and safe to call during the bootstrap step**; afterwards the cheap local read works. Confidence: high. |
| `git ls-remote --symref origin HEAD` | **Yes** (no objects fetched) | `<oid>\t<ref>\n` lines, plus `ref: refs/heads/<branch>\tHEAD\n` for the symref (protocol v0) | v2 protocol does NOT advertise the symref at all (only v0 does). Output is also different between v0 and v2. **Avoid relying on this without `--upload-pack` forcing v0.** Source: https://git-scm.com/docs/git-ls-remote, commit `b2f73b70b2` (Peff). Confidence: high. |
| `git remote show origin` | **Yes** (calls `ls-remote`) | multi-line human report including `HEAD branch: <name>` | Slow, requires parsing free text, calls `ls-remote` + config reads. **Don't use for scripting.** Confidence: high. |

### Recommended strategy
1. `git symbolic-ref --quiet refs/remotes/origin/HEAD` → if success, parse `<target>` and trim `refs/remotes/origin/`.
2. On failure, run `git remote set-head origin --auto` (one-time bootstrap; queries remote) and re-read the local symref.
3. Cache the resolved name alongside the clone metadata so subsequent runs never hit the network for this check.

### `set-head` failure modes
- `origin/HEAD` doesn't exist: error, no change.
- Remote doesn't advertise a `HEAD` ref (rare; some bare mirrors): error, leaves symref unset.
- Per docs, `-a` "will only work if `refs/remotes/origin/<branch>` already exists; if not it must be fetched first." — first `git fetch` then `set-head -a`. Source: https://git-scm.com/docs/git-remote (set-head section). Confidence: high.

---

## 3. Staleness / Up-to-Date

### Last-fetch time
- **The mtime of `.git/FETCH_HEAD` is the canonical, no-network signal.** Junío (git maintainer) confirms: "It looks like the timestamp of file `.git/FETCH_HEAD` would be enough" and recommends pairing it with the **reflog of the relevant remote-tracking ref** to know which remote a given fetch actually concerned. Source: public-inbox.org `x9qq34guzi0f.fsf@gitster.g` (Junio Hamano).
- Gotcha: a single `git fetch` overwrites the whole file (unless `--append` is passed, which `git fetch` doesn't accept; only internal users do). The whole file is rewritten on every fetch, so mtime is monotonically updated. Confidence: high (source-code verified in `builtin/fetch.c:1145-1208`; see FETCH_HEAD format below).

### FETCH_HEAD line format (per `builtin/fetch.c:1145-1208`)
```c
strbuf_addf(&fetch_head->buf, "%s\t%s\t%s",
            oid_to_hex(old_oid), merge_status_marker, note);
/* note for a branch ref is built as: "branch '<name>' of " */
strbuf_addch(&fetch_head->buf, '\n');
```
Result per line:
```
<40hex-oid>\t<marker>\tbranch '<name>' of <url>\n
```
- `<marker>` is empty (merge candidate) or literal `not-for-merge`.
- `<url>` is the remote URL with embedded newlines escaped as `\n`.
- There is **no per-line timestamp** in FETCH_HEAD; rely on the file's mtime (or stat the file).
- `FETCH_HEAD` is created with a `# branch.<name> of <url>` comment style line only on the first line of some legacy paths — modern code uses the tab-separated form. Confidence: high (source-verified).

### Ahead/behind, no network
```sh
git rev-list --left-right --count <local>...origin/<default>
# → "<ahead> <behind>" tab-separated on one line
```
- Three dots (symmetric difference), not two. The left side (`<local>`) is the `<` count, the right (`origin/<default>`) is the `>` count. Source: https://git-scm.com/docs/git-rev-list (`--left-right` / `--count` options). Confidence: high.
- This is the only zero-network way to compute staleness; `git fetch` updates `refs/remotes/<remote>/<branch>` (the `FETCH_HEAD` file is also written, but the remote-tracking ref is what `rev-list` reads).
- If ahead > 0 → local commits that the remote doesn't have → diverged.
- If behind > 0 → remote has new commits.
- If both zero → fully in sync. Confidence: high.

### `git fetch` flags relevant to evergreen maintenance
- `git fetch --prune origin` — deletes remote-tracking refs that no longer exist on the remote. Tags are not pruned unless explicitly fetched via a tag refspec. Use `--prune-tags` to also delete local tags the remote removed. Source: https://git-scm.com/docs/git-fetch (`--prune` section).
- `git fetch --no-tags origin` — does not auto-follow tags pointing to fetched objects. **Recommended for evergreen**: most org-wide clones don't need all tag history. Source: same.
- `git fetch --no-write-fetch-head` — suppresses FETCH_HEAD (default is write). Don't use this if you rely on mtime for staleness.
- `git fetch --quiet` (or `-q`) — silences progress.
- `git fetch --filter=blob:none` (partial clone) — speeds first-time fetch dramatically; can change staleness-detection semantics because some refs are fetched lazily. **Probably out of scope for the evergreen baseline.**
- `git fetch --negotiate-only` — does not fetch; just negotiates common commits. Useful for pre-checks but overkill here. Confidence: high.

---

## 4. Safe Update Strategy

All three commands target the same end state on a non-diverged tree, but they differ in **local-commit handling** and **failure mode**.

| Command | Diverged? | Local commits? | Failure mode | Data-loss risk |
|---|---|---|---|---|
| `git merge --ff-only origin/<default>` | Fails (non-zero exit, "Not possible to fast-forward") | Preserved (no rewrite) | Clean error message | None |
| `git pull --ff-only` (or `--ff-only` flag with default rebase=false) | Same as above | Same | Same | None |
| `git pull --ff-only --rebase` (or default after 2.27 with `pull.ff=only`) | **Rebases local commits on top of `origin/<default>`**, rewriting their SHAs | Rewritten (new SHAs) | Rebase conflicts halt the process | Loses original commit SHAs but not the changes |
| `git reset --hard origin/<default>` | Silently succeeds | **DISCARDED — all local commits on the local default branch vanish** (still recoverable from reflog for ~90 days) | No prompt, no warning | **High** if there are local commits |

- `git pull` is just `git fetch` + `git merge` (or `git rebase` with `--rebase`).
- **Since Git 2.27 (July 2020), `git pull` with no `pull.ff`/`pull.rebase` config prints a warning** ("You have divergent branches…") and exits non-zero. The orchestrator must pick: `git config pull.ff only` (recommended for evergreen) or pass `--ff-only` explicitly. Source: https://github.com/git/git/blob/master/Documentation/RelNotes/2.27.0.adoc ("`git pull` issues a warning message until the `pull.rebase` configuration variable is explicitly given…"). Confidence: high.
- `git merge --ff-only` is preferred over `git pull --ff-only` when you've already done a separate `git fetch` (avoids the redundant second fetch that `pull` performs). Confidence: med (idiomatic).

### Bringing a non-clean / wrong-branch repo back to evergreen (mechanics only; policy is the orchestrator's)
- **Modified/staged/untracked**: stash (`git stash push -u`) → `git switch <default>` → `git merge --ff-only origin/<default>` → `git stash pop`. (Stash may fail to apply; that's the user's call to resolve.)
- **Detached HEAD**: `git switch <default>` (refuses if it'd clobber uncommitted changes; pass `--discard-changes` or `--merge` only with explicit policy).
- **Local commits on default branch ahead of remote**: refuse — divergent history. `git push` would be needed (not an evergreen-maintenance action).
- **Local commits on a non-default branch**: switch the default first via `git switch`/`git checkout`; the local branch's tip is preserved but is not the default-branch state. Policy decision.
- **Submodule in a dirty state**: `git submodule update --init --recursive` (may discard local submodule changes — destructive).

### `git switch` vs `git checkout` (since Git 2.23)
- `git switch <branch>` — **branch-only**; refuses silently to interpret `<branch>` as a file path. Refuses to clobber local uncommitted changes unless `--discard-changes` or `--merge` is passed. Recommended for scripts. Source: https://git-scm.com/docs/git-switch. Confidence: high.
- `git checkout <branch>` — still works, but also accepts `<branch> -- <path>` form (file restore), which makes it unsafe to use in scripts with unsanitized input. Use `git switch` in automation. Confidence: high.
- `git restore` is the new home of the file-restoration side of `checkout`.

---

## 5. gh CLI Org Enumeration

### `gh repo list <org>` essentials
- **Synopsis**: `gh repo list [<owner>] [flags]`. With no `<owner>`, lists the authenticated user's repos. With `<owner>`, lists that org's repos. (No flag to list arbitrary search results — use `gh search repos`.) Source: https://cli.github.com/manual/gh_repo_list. Confidence: high.
- **`--limit, -L <int>`** (default **30**). Use `--limit 1000` to grab up to 1000 in one call (the only way to "page" since `gh repo list` has no `--paginate` and no offset). Source: https://github.com/cli/cli/discussions/7010 (maintainer: "you can supply `gh repo list --limit 1000` and it will fetch up to [1000]"). Confidence: high (primary).
- **`--no-archived`** — exclude archived repos (mutually exclusive with `--archived` which shows **only** archived). `--fork` shows only forks; `--source` shows only non-forks. `--visibility {public|private|internal}` filters by visibility.
- **`--json <fields>`** — emits JSON array; chain with `--jq '...'` or `--template '...'`. Available fields include: `name`, `nameWithOwner`, `sshUrl`, `url`, `defaultBranchRef { name }`, `isArchived`, `isFork`, `pushedAt`, `visibility`, `description`, `id`, `isPrivate`, `updatedAt`, `stargazerCount`, `diskUsage`, `primaryLanguage`. (Full list is in the manual; documented at https://cli.github.com/manual/gh_repo_list.) Confidence: high (primary).
- **One-shot clone-URL + default-branch**:
  ```sh
  gh repo list <org> --limit 1000 --no-archived --source --json sshUrl,defaultBranchRef,name
  # defaultBranchRef is an object: { "name": "main" } — use .defaultBranchRef.name in jq
  ```
- **Sorting**: the manual doesn't expose a sort flag; `gh repo list` uses the API's default sort (most recently updated). For pushedAt sorting use `gh search repos` or `gh api` and sort client-side.

### `gh api` fallback for full / large org lists
- Endpoint: `GET /orgs/{org}/repos` (returns up to 100 per page; `per_page` query param caps at 100, `page` for offset). Source: https://docs.github.com/en/enterprise-server@3.20/rest/repos/repos (`per_page` documented as "max 100"). Confidence: high.
- **Pagination pattern** with `gh api`:
  ```sh
  gh api /orgs/{org}/repos --paginate --jq '.[] | {name, sshUrl, default_branch}'
  # `--paginate` walks all pages via Link headers
  # add `--slurp` to get one outer JSON array of all pages' bodies
  # set per-page: `gh api -F per_page=100` (typed conversion; for raw use -f)
  ```
- For an org with > 5000 repos, you'd still need to handle `Link: rel="last"` manually because `--paginate` walks until exhausted, which is the desired behavior. Confidence: high.

### Auth + rate limits
- Auth: `gh auth status` / `gh auth login`. With auth: **5,000 REST requests/hour** per user token. Unauthenticated (only works for public repos): **60 requests/hour per IP**. Source: https://docs.github.com/rest/using-the-rest-api/rate-limits-for-the-rest-api. Confidence: high.
- **Important 2025 change**: GitHub tightened unauthenticated rate limits in May 2025 for the REST API. If your orchestrator runs `gh repo list` in a context where the `gh` CLI cannot pick up auth (e.g. CI without `GH_TOKEN` / `GITHUB_TOKEN`), you're now more likely to be throttled. Source: https://github.blog/changelog/2025-05-08-updated-rate-limits-for-unauthenticated-requests/. Confidence: high.
- `gh api` responses include `X-RateLimit-Remaining` / `X-RateLimit-Reset` headers; check with `gh api /rate_limit`.

### `--limit` edge case
- The `gh` CLI was added `--limit` in PR #2953 explicitly because GraphQL's `repositoryOwner.repositories(first:)` supports only up to 100 per call, so to get more the CLI iterates internally. Hard cap of 1000 is documented in the maintainer discussion. **For orgs with > 1000 repos, use `gh api /orgs/{org}/repos --paginate`.** Confidence: high (primary).

---

## Top 3 findings most likely to change a design decision

1. **Detached/dirty detection should use `git status --porcelain=v2 --branch` (not v1) when the orchestrator must also report on submodules or read ahead/behind from headers.** v2 with `--branch` emits `# branch.oid`, `# branch.head`, `# branch.upstream`, and `# branch.ab +<a> -<b>` as canonical key-value lines, eliminating the need for a separate `git rev-list --left-right --count ...` call. v1 is only better if simplicity of one grep over `<XY> <path>` matters more than detail. Confidence: high.

2. **`FETCH_HEAD` mtime is the only zero-network staleness signal, but a single fetch rewrites the whole file (mtime bumps regardless of which remote/branch was actually fetched).** If the orchestrator handles multiple remotes, mtime alone is ambiguous — combine with the mtime of the `refs/remotes/<name>/<branch>` loose ref file (which `git fetch` updates per ref) or use `git for-each-ref --format='%(refname) %(updatetime:unix)' refs/remotes/`. This changes a policy decision: "fetched within 6 hours" is cheap to check per-repo (mtime) but the orchestrator must decide which remote/branch the staleness applies to. Confidence: high (Junio, source code).

3. **`git pull` without explicit `pull.ff`/`pull.rebase` config now exits non-zero with a warning (since Git 2.27, 2020).** For evergreen automation this means `git pull` is not safe to call directly — use `git fetch` + `git merge --ff-only` (or set `pull.ff=only` globally first). The same applies when applying 2.43+'s stricter divergent-branch behavior. This directly determines whether the orchestrator's update step is a single command or two (and whether config files need to be written into every clone). Confidence: high (release notes + tests `t7601-merge-pull-config.sh`).
`). For large orgs (>5,000 repos), GraphQL with `repositories(first: 100)` is essential; REST per_page=100 would take 50+ requests.
- Confidence: **med-high** (primary docs for limits; med for the Keychain-silent-failure bug — it's a single GitHub issue, well-corroborated, but not in official docs).

---

## Cross-cutting findings (2-3 most likely to change a design decision)

1. **Default untracked-files mode is `all`, not `no`.** This is a real performance trap: scripts calling `git status --porcelain` against repos with `node_modules/`, `.venv/`, build artifacts not in `.gitignore` will recurse the entire tree. For a "is this clean?" check across many repos, you almost certainly want `--untracked-files=normal` (skips recursion into untracked directories) — and you must explicitly opt in to that. Conversely, if you set `--untracked-files=no`, an untracked file in the repo root will be silently ignored and the working tree will be considered clean. Source: git-scm.com/docs/git-status. This single decision can change evergreen detection from O(repo size) to O(root files) and back.

2. **`git reset --hard origin/<default>` is catastrophic for local commits; `merge --ff-only` is the only safe auto-update.** The orchestrator must never auto-run `reset --hard`. The correct pattern is: assert clean, assert on default, assert `rev-list --left-right --count` shows `0\tN` (no local ahead), then `merge --ff-only`. If that fails, surface divergence. This is the single most common foot-gun in "auto-update scripts" and the difference between the safe and unsafe variants is one flag (`--ff-only` vs `--hard`).

3. **`origin/HEAD` is set only at `git clone` time (or via `git remote set-head -a`).** A plain `git fetch` does **not** update it. If the orchestrator relies on `git symbolic-ref refs/remotes/origin/HEAD` to read the default branch, it will silently return stale results when the repo's default branch was changed upstream after the initial clone. The fix (`git remote set-head origin -a`) requires a network call, which conflicts with the "check staleness locally" goal. Practical pattern: try the local symbolic-ref first; if missing or stale-looking, do the network call once and cache. (Bonus: `git ls-remote --symref origin HEAD` is the one-shot network alternative that doesn't persist anything.)

### NOT FOUND / low confidence

- **Submodule detection parity between v1 and v2**: confirmed by docs that v1 collapses to `M`, but I could not find a definitive statement on whether the v1 `M` always reflects "different HEAD recorded in index" vs "modified content" vs "untracked" — only that they all report as `M`. Confidence: **low** for the loss-of-detail claim beyond the `M` collapse.
- **`FETCH_HEAD` mtime as authoritative last-fetch indicator**: not formally documented as a stable API. Multiple SO answers agree on the behavior, but it's a coincidence of implementation, not a contract. Confidence: **med**.
