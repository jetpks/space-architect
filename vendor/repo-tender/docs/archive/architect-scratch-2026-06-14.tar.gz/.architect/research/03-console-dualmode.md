# Lane 3: socketry/console dual-mode output (raw findings)

BIG FINDING (high, primary source): console does EXACTLY the requested dual-mode with ZERO app config.

- console v1.36.0 released 2026-06-02 (11 days ago). MIT. Ruby >= 3.3. 48.7M downloads. deps: fiber-annotation, fiber-local, json. Maintainer Samuel Williams (ioquatix/socketry).
- ALREADY a transitive dep of async (async.gemspec: console ~> 1.29). async logs through Console.logger.

FORMAT-SWITCHING (primary source default.rb, verbatim):
```
def self.new(stream, env: ENV, **options)
  stream ||= $stderr
  if stream.tty?         -> Terminal.new   (pretty/colored)
  elsif mail?(env)       -> Text.new       (MAILTO set, cron)
  elsif github_actions?  -> XTerm.new      (colored CI)
  else                   -> Serialized.new (structured, one-record-per-line)
end
```
- TTY → Terminal (pretty). Non-TTY → Serialized (structured JSON-ish, one record per line). Under launchd: stderr not TTY, no MAILTO, no GITHUB_ACTIONS → Serialized automatically.
- CONSOLE_OUTPUT env var = explicit override (comma list of Output classes). Source-documented only (not in command-line guide).
- Serialized record hash: time(iso8601), severity, process_id, fiber_id, subject, message, +merged options. Pluggable @format (not hardcoded JSON, default JSON).

COLOR/NO_COLOR:
- Terminal: tty? → XTerm (ANSI) else Text (no color).
- NO_COLOR: NOT FOUND in color-decision path read (keys purely off stream.tty?). med-NEGATIVE. NOT exhaustively grepped.

CUSTOM STRUCTURED EVENTS (first-class):
- Console::Event::Generic base. Define to_hash (with type: discriminator) = structured/JSON repr. Console::Terminal::Formatter = human terminal rendering.
- `UserLoginEvent.new(...).emit(self, "msg")`. Single domain event → pretty in terminal, structured hash when serialized.
- CAVEAT (med): exact custom-terminal-formatter REGISTRATION API not quoted in fetched docs.

API: Console.logger.info/.debug/.warn/.error. CONSOLE_LEVEL=debug|info|... CONSOLE_DEBUG=MyClass (per-subject). Console::Output::Datadog, Adapter::Rails/Sidekiq wrappers exist. Output composable via CONSOLE_OUTPUT.

env-config control via Console::Config (CONSOLE_*) - per-class level.

VIABILITY: console is a viable, zero-app-code daemon-mode structured-output backbone, already in tree, MIT, actively maintained, supports user events with machine(to_hash)+terminal renderings. Caveats: NO_COLOR not honored in path read; formatter-registration API unverified; MAILTO/GITHUB_ACTIONS special-cased.
