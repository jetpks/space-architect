I have enough material. Let me write up the findings.

---

# Research Findings: Async Subprocess, Concurrency, and Daemon Patterns (2026)

**Date of research:** 2026-06-12
**Confidence legend:** high = primary source (gem repo, official docs, source code), med = reputable secondary, low = single blog/forum

---

## 1. SUBPROCESS EXECUTION UNDER ASYNC

### Finding 1.1 — `Process.wait` family is natively non-blocking under Async (on macOS) — high impact

**Source:** `lib/async/scheduler.rb` in socketry/async (lines ~410–418), `ext/io/event/selector/kqueue.c` (lines 189, 222–229, 424–510), `ext/io/event/selector/epoll.c` (lines 437–517), `ext/io/event/selector/uring.c`.
- `https://github.com/socketry/async/blob/master/lib/async/scheduler.rb`
- `https://github.com/socketry/io-event` (cloned source at `/tmp/pi-github-repos/socketry/io-event/ext/io/event/selector/kqueue.c`)
- Fiber::Scheduler interface docs: `https://docs.ruby-lang.org/en/master/Fiber/Scheduler.html`
- Ruby upstream feature #17369: `https://bugs.ruby-lang.org/issues/17369`

**Quote (Async::Scheduler):** `def process_wait(pid, flags); return @selector.process_wait(Fiber.current, pid, flags); end`

**Quote (kqueue.c):** kqueue registers `kevents[count].filter = EVFILT_PROC; kevents[count].fflags = NOTE_EXIT; kevents[count].flags = EV_ADD | EV_ONESHOT;` — kqueue notifies the reactor when the child exits without polling.
On Linux `epoll` uses `pidfd_open(pid, 0)` then waits on the pidfd (epoll.c:478). On io_uring there is a corresponding async variant.

**Confidence:** high (verified in cloned source).

**Implication for design:** Inside an `Async`/`Sync` task, **`Open3.capture3`, `IO.popen`, `Process.spawn` + `Process.wait2`, `Process.waitpid`, and `Process::Status.wait` are all non-blocking** on macOS (kqueue backend) and Linux (epoll+pidfd). You do **not** need `async-process` for capture; stdlib works. Async::Scheduler implements the `Fiber::Scheduler#process_wait` hook (Ruby 3.1+), which is mandatory for `Process.wait` to be non-blocking. The Fiber::Scheduler interface is documented as a hard requirement: *"When not specified otherwise, the hook implementations are mandatory: if they are not implemented, the methods trying to call hook will fail."* (`https://docs.ruby-lang.org/en/master/Fiber/Scheduler.html`)

---

### Finding 1.2 — `async-process` gem exists, version 1.4.0 (released 2024-11-08, dormant since) — medium impact

**Source:** RubyGems page `https://rubygems.org/gems/async-process/versions/1.4.0`, GitHub `https://github.com/socketry/async-process`.
- All 7 versions listed: 1.0.0 (2018-01-31) → 1.4.0 (2024-11-08). **No new release in ~19 months.**
- Total of 7 releases, 25 GitHub stars, 2 contributors (ioquatix + joekhoyar).
- It is a stable/mature gem, not abandoned in the usual sense — `Process.spawn` is now redundant given the Fiber::Scheduler hook, so the maintainer is unlikely to extend it.

**Source code (cloned `/tmp/pi-github-repos/socketry/async-process`):**

`lib/async/process.rb` (full file):
```ruby
module Async
  module Process
    def self.spawn(*arguments, **options)
      Child.new(*arguments, **options).wait
    end
    def self.capture(*arguments, **options)
      input, output = ::IO.pipe
      options[:out] = output
      runner = Async do
        spawn(*arguments, **options)
      ensure
        output.close
      end
      Sync do
        input.read
      ensure
        runner.wait
        input.close
      end
    end
  end
end
```

`lib/async/process/child.rb` highlights: spawns a **real OS thread** running `Process.wait2(pid)`; on exit closes a pipe; the main fiber `@input.read(1)` yields to the scheduler until the pipe byte arrives. It always sets `pgroup: true` and `kill(signal = :TERM)` is sent to `-@pid` (negative pid, i.e. the process group) for hard cleanup.

**The README is misleading/stale:** *"Internally, we use a thread, since `nio4r` doesn't support monitoring pids."* (`https://github.com/socketry/async-process/readme.md`). This was true for nio4r but **io-event (the current backend since Async 2.0) does support `process_wait` natively via kqueue's `EVFILT_PROC | NOTE_EXIT`**, as verified in `kqueue.c` lines 222–229, 475–510. So `Async::Process` is paying the cost of a thread per subprocess unnecessarily; stdlib `Open3` is now both simpler and cheaper.

**Confidence:** high (cloned and read source).

---

### Finding 1.3 — io-event on macOS uses the **kqueue** selector, not a poll-based fallback — high confidence

**Source:** `lib/io/event/selector.rb` (cloned at `/tmp/pi-github-repos/socketry/io-event/`):
```ruby
def self.default(env = ENV)
  if name = env["IO_EVENT_SELECTOR"]&.to_sym
    return const_get(name)
  end
  if self.const_defined?(:URing)
    URing
  elsif self.const_defined?(:EPoll)
    EPoll
  elsif self.const_defined?(:KQueue)
    KQueue
  else
    Select
  end
end
```
- io-event version **1.16.2** is the current release (rubygems `https://rubygems.org/gems/io-event`).
- Selector priority: `URing` (Linux 5.x+ with liburing) → `EPoll` (Linux) → **`KQueue` (macOS / BSD)** → `Select` (pure-Ruby fallback). Forcing is possible via `ENV["IO_EVENT_SELECTOR"]`.
- `kqueue.c` registers `EVFILT_PROC | NOTE_EXIT | EV_ONESHOT` for process monitoring (lines 222–229). Caveat noted in the code itself for FreeBSD/OpenBSD/NetBSD: kevent may return a NOTE_EXIT for a process whose `WNOHANG` `waitpid` is not yet ready; io-event works around this with a hanging `waitid(WEXITED | WNOWAIT)` (`process_prewait`, kqueue.c:432–448). This is BSD-specific and **does not apply to macOS** in practice.
- `Async::IO` itself is for sockets/IO wrappers (`https://github.com/socketry/async-io`); pipes from `IO.popen` work directly via the `Fiber::Scheduler#io_wait` hook, no `Async::IO` wrapper required.

**Confidence:** high.

---

### Finding 1.4 — `Open3.capture3` caveat: captured output is a blocking `read` by default

**Source:** cloned `lib/async/process.rb` shows the `Async::Process.capture` implementation does `input.read` inside a `Sync` block — a synchronous read of the whole pipe until EOF. If the child writes a large volume to stdout and stderr is small, **a blocking `read` on the merged stream can deadlock** when stderr's pipe buffer fills (~64–256 KB on macOS), because the child is blocked writing to stderr while you block reading from stdout. This is a classic pitfall documented in Ruby bug #9082 (`https://bugs.ruby-lang.org/issues/9082`).
- `Open3.popen3` returning four objects (`stdin, stdout, stderr, wait_thread`) is the safer stdlib primitive, because you can drain stdout and stderr concurrently in two fibers using `io_wait`.
- `Async::Process.capture` has the same hazard for any long-running, high-stderr child.

**Confidence:** high (verified in source) + medium (long-standing stdlib behavior).

---

## 2. CONCURRENCY CONTROL

### Finding 2.1 — `Async::Barrier` is the canonical "fan-out, collect" primitive; `Async::Semaphore` is the bounded variant — high confidence

**Source:** `https://socketry.github.io/async/guides/best-practices/index`, `https://socketry.github.io/async/source/Async/Barrier/index.html`, `lib/async/semaphore.md` in async repo.
- `Async::Barrier` is described as: *"A synchronization primitive, which allows one task to wait for a number of other tasks to complete. It can be used in conjunction with class Async::Semaphore."* (`https://socketry.github.io/async/source/Async/Barrier/index.html`)
- The "Sleep sort" example shows the canonical idiom: `barrier.async { |task| ... }; barrier.wait`.
- `Async::Barrier#wait` "now returns the number of tasks that were waited for, or `nil` if there were no tasks" (changelog entry for v2.35 era).
- Default `Barrier(parent: Async::Idler.new, **options)` uses an `Async::Idler` to throttle new task creation when system load is over 80% — so an unbounded fan-out gets soft backpressure for free. Override with `Barrier(parent: nil)` to disable.
- `Async::Semaphore.new(N)` is a counting semaphore: `semaphore.async { ... }` is the idiom for "max N concurrent." See `https://github.com/socketry/async/blob/main/lib/async/semaphore.md`.

**For the "fan out M git fetches, max K at once, collect results" pattern, the cleanest combination is `Semaphore.new(K)` + `Barrier` (or a shared `Array` of result objects):**
- Each child does `semaphore.async { barrier.async { ... } }` — semaphore bounds concurrency, barrier collects.
- Or just `Async::Semaphore.new(K)` plus a plain `Array#push`/`map` and a final `Task#wait_all` (added in Async v2.36; `releases.md`).

**Confidence:** high.

---

### Finding 2.2 — `Async::Waiter` is deprecated; **`Async::WaitGroup` does not exist in socketry/async** — high impact

**Source:** `https://socketry.github.io/async/source/Async/Waiter/index.html` (live docs):
> `Async::Waiter` is deprecated, use `Async::Barrier` instead.

Searches for `Async::WaitGroup` in the socketry repos returned **no hits**. (`NOT FOUND`.)

**Confidence:** high (verified live docs + repo search).

**Implication for design:** If the brief in the prompt is asking "Async::Barrier / Async::Semaphore / Async::WaitGroup," the third name is wrong for socketry. The primitive to reach for is `Async::Barrier` (replaces `Waiter`), with `Async::Semaphore` for the bound.

---

## 3. DAEMON / PERIODIC STRUCTURE

### Finding 3.1 — `Async::Loop.periodic` and `Async::Loop.quantized` are first-party as of async v2.37 (2026-03-08) — high confidence

**Source:** cloned `/tmp/pi-github-repos/socketry/async/lib/async/loop.rb` (header: `Copyright, 2026, by Samuel Williams`), `https://github.com/socketry/async/blob/HEAD/releases.md`:
> v2.37.0 — Introduce `Async::Loop` for robust, time-aligned loops.

API:
```ruby
Async::Loop.periodic(interval: 60) { ... }     # sleep AFTER each run
Async::Loop.quantized(interval: 60) { ... }    # sleep UNTIL next wall-clock boundary
```
- `quantized` aligns to the wall clock: e.g. `interval: 21600` (6 h) lands at 00:00 / 06:00 / 12:00 / 18:00 — useful for "every 6 hours" semantics if the operator wants alignment.
- `periodic` measures end-to-start, so the period is `interval + execution_time`. The official Tasks guide explicitly recommends this pattern: *"Often it's best to measure the periodic delay end-to-start, so that your process always takes a break between iterations and doesn't risk spending 100% of its time on the periodic work."* (`https://socketry.github.io/async/guides/tasks/index`)
- Errors are caught and logged via `Console.error(self, "Loop error:", error)`; the loop continues — important for a daemon.
- Both must be run inside a reactor; pattern is:
  ```ruby
  Async do |task|
    task.async { Async::Loop.periodic(interval: 6*3600) { do_work } }
    # ... other long-lived tasks, signal handling, etc. ...
  end
  ```
- **No third-party periodic gem is needed for this use case.** `async-cron` (`https://github.com/socketry/async-cron`) exists but its README is essentially empty and it has 2 stars — too immature to bet on. `async-background` (third-party, `https://github.com/roman-haidarov/async-background`, v0.6.1 April 2026) is a richer cron+queue but is not maintained by socketry.

**Confidence:** high.

---

### Finding 3.2 — Graceful shutdown: `Async::Container::Controller#run` is the reference pattern (traps SIGINT/SIGTERM via `Thread.handle_interrupt` + `Thread.current.raise(Interrupt)`) — high confidence

**Source:** cloned `/tmp/pi-github-repos/socketry/async-container@main/lib/async/container/controller.rb` (Copyright 2018–2026, Samuel Williams). `https://github.com/socketry/async-container`.
- async-container version 0.18.0 latest stable; v0.30+ makes SIGTERM graceful (the same as SIGINT) for Kubernetes/systemd compatibility, and escalates to SIGKILL after `ASYNC_CONTAINER_GRACEFUL_TIMEOUT`.
- The actual trap snippet:
  ```ruby
  interrupt_action = Signal.trap(:INT) do
    ::Thread.current.raise(Interrupt)
  end
  terminate_action = Signal.trap(:TERM) do
    ::Thread.current.raise(Interrupt)  # same as INT since v0.30
  end
  ::Thread.handle_interrupt(SignalException => :never) do
    yield
  end
  ```
  Then in the loop:
  ```ruby
  while @container&.running?
    begin
      @container.wait
    rescue SignalException => exception
      handler = @signals[exception.signo]
      handler&.call
    end
  end
  ```
- A more idiomatic alternative for an in-reactor daemon (no fork/exec) is `Async::IO::Trap` (`https://www.rubydoc.info/gems/async-io/Async/IO/Trap`) — a cross-reactor/process notification pipe: `trap.async { |task| ... }; trap.wait` — used in the async-io echo server example (`https://github.com/socketry/async-io/commit/4c84b63`).
- And `Async::Reactor#stop` (or `Async::Reactor#close`) is the way to actually break out of the event loop once a signal has been received. The reactor's `close` "stops each of the children tasks and closes the selector" (`https://www.rubydoc.info/gems/async/Async/Reactor`).

**Confidence:** high (cloned source).

---

### Finding 3.3 — The "top-level block" is `Async do |task| ... end` (or `Sync do |task| ... end`) — high confidence

**Source:** `https://www.rubydoc.info/gems/async/1.24.2/Async/Reactor`, `https://socketry.github.io/async/guides/getting-started/index`.
- `Async do |task| ... end` is equivalent to `Sync do |task| ... end` (both create/run a reactor). It returns the task.
- If invoked inside an existing reactor, `Async do ... end` schedules a new task on the parent reactor; outside, it creates and runs one.
- `Async` requires the `async` gem; `Sync` requires `async/sync` (sub-namespace for synchronous-looking async).

**Confidence:** high.

---

### Finding 3.4 — Ruby's `Fiber::Scheduler#io_select` (Ruby 3.1+) is what makes `IO.select` work in Async — useful fact

**Source:** `https://blog.saeloun.com/2025/12/03/ruby-non-blocking-io-select/`, Async PR #352 ("Add support for `Fiber::Scheduler#blocking_operation_wait`", 2024-11).
- Async implements `io_select`, `process_wait`, `io_wait`, `io_close` (Ruby 4.0+), `kernel_sleep`, `block`/`unblock`. So `IO.select`, `IO#wait_readable`/`wait_writable`, and any read/write that hits a not-ready fd will yield to the reactor.

**Confidence:** high.

---

## Gem Inventory (current as of 2026-06-12)

| Gem | Latest version | Released | Notes |
|---|---|---|---|
| `async` | **2.39.0** | 2026-04-05 | Active, biweekly releases. Pulls `io-event` and `async-io` transitively. |
| `io-event` | **1.16.2** | 2026-05-12 | Native C selectors (URing/EPoll/KQueue/Select). |
| `async-io` | 1.x | active | `Async::IO::Trap`, `Async::IO::SharedEndpoint`, etc. |
| `async-process` | **1.4.0** | **2024-11-08** | Last release ~19 months ago. **Effectively superseded by the Fiber::Scheduler `process_wait` hook + io-event kqueue/epoll pidfd.** |
| `async-container` | 0.18.0 (lib 0.32+ in git) | 2025–2026 | `Async::Container::Controller` for supervised multi-process. |
| `async-cron` | (no release tagged) | last commit 2024-06-08 | Stub README, 2 stars — too immature. |
| `async-background` | 0.6.1 | 2026-04-08 | Third-party cron+queue. **Not** by socketry. |

**Confidence:** high (RubyGems + GitHub release tags).

---

## Disagreements / Caveats

- **`async-process` README claim of "we use a thread"** vs. **io-event's native `process_wait` support**: the README is stale; io-event ≥ ~1.0 already has native kqueue/epoll/uring `process_wait` (changelog v1.7.5 even mentions "fix `process_wait` race condition on EPoll"). Treat `Async::Process` as legacy; prefer stdlib `Open3` / `IO.popen` + manual fiber management.
- **`Async::WaitGroup` is not a real class**; the user may be thinking of `Async::Barrier` (which replaced `Async::Waiter`).

---

## 2–3 findings most likely to change the design

1. **`async-process` is unnecessary for this workload.** With io-event ≥ 1.0 + kqueue on macOS (or epoll+pidfd on Linux), `Open3.capture3` / `IO.popen` / `Process.wait2` are non-blocking for free under any `Async do ... end` block. The original `async-process` "we use a thread" rationale is obsolete. The daemon can drop the dependency and use stdlib, removing one thread per subprocess.

2. **`Async::WaitGroup` doesn't exist — the fan-out primitive is `Async::Barrier` (or `Async::Semaphore.new(K)`).** The brief's mention of `Async::WaitGroup` is a misnomer; the right tool is `Async::Barrier` (replaces the deprecated `Async::Waiter`) for "collect results," with `Async::Semaphore.new(K)` layered on top to bound concurrency. `Async::Barrier` also gives you free load-based backpressure via the default `Async::Idler` parent.

3. **There is no need for a third-party cron/periodic gem.** `async` v2.37 (2026-03) ships `Async::Loop.periodic` and `Async::Loop.quantized` first-party. `async-cron` is a stub; `async-background` is third-party. For "every 6 hours," `Async::Loop.periodic(interval: 6*3600)` measures end-to-start and continues on error — exactly what a daemon wants. `Async::Loop.quantized` is the alternative if the operator wants wall-clock alignment (00:00, 06:00, 12:00, 18:00).

**One non-obvious gotcha worth flagging:** stdlib `Open3.capture3` (and `Async::Process.capture`) does a single blocking `read` of the merged stdout pipe while stderr drains in another thread — this can deadlock if the child writes enough to stderr to fill the pipe buffer (~64–256 KB on macOS). The safe pattern for `git`/`gh` is `Open3.popen3` + two fibers draining stdout and stderr independently via the scheduler's `io_wait`, then `Process.wait2` (which is now non-blocking via `Fiber::Scheduler#process_wait`).
4.0 (2024-11-08). Whether it is officially deprecated in favor of built-in `Async::Scheduler#process_wait` is NOT stated explicitly anywhere I could find. (Treat as "stale" not "deprecated".)
- **No benchmark numbers** for `Async::Process.capture` vs hand-rolled `IO.pipe` + `Process.wait2` under load on macOS.
- **No statement from socketry** explicitly recommending the `Barrier + Semaphore` pattern over alternatives; the pattern is the documented "Best Practice" but the docs do not call it *the* answer to fan-out-with-limit.
