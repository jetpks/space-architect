# Lane 5: Progress/event UI architecture (raw findings)

TWO INTERFACE SHAPES recur:
(a) named-event + payload-hash pub/sub (AS::Notifications, dry-events, dry-monitor) — subscribers match by event name, open/extensible.
(b) fixed-method protocol reporters (RSpec example_passed(notification), Minitest #record, Bundler info/warn) — each event a method, value object carries data, closed/compile-checkable.
Both decouple emit from render.

RSpec formatter (HIGH primary): Reporter owns event stream → calls formatters. `RSpec::Core::Formatters.register self, :example_started, :example_passed` — subscribe only to events you render; unsubscribed never called. Notifications delivered as method calls receiving VALUE OBJECTS (not bytes). Same stream → progress(dots)/documentation/json formatters, zero domain change. Multiple formatters independent.

Minitest (HIGH): 4 methods #start/#record(result)/#report/#passed?. CompositeReporter fans out to N reporters (broadcast/multiplex). Override only needed methods.

Bundler::UI (HIGH): single interface error/warn/confirm/info/debug. Shell=real output; Silent=no-ops capturing @warnings/unprinted_warnings. NULL-OBJECT testability swap.

dry-events (HIGH, now under hanakai.org — dry-rb/Hanami/ROM merged into Hanakai):
  include Dry::Events::Publisher[:id]; register_event('users.created'); publish('users.created', user:'Jane'); subscribe('users.created'){|event| event.id; event[:user]}. Listener convention on_users_created(event).
  ASYNC: NOT FOUND in docs (no sync/async statement). Secondary claim "fully synchronous" = LOW unverified.

dry-monitor (HIGH): Notifications INCLUDES Events::Publisher (built on dry-events), "interface compatible with ActiveSupport::Notifications". `Dry::Monitor::Notifications.new(:app); notifications.instrument(event_id, payload, &block)` (times block then notifies). No dry-events↔dry-monads/Result progress integration found.

AS::Notifications (HIGH): instrument('render', extra: :info){block}; subscribe('render'){|event| event.name/duration/payload}. The interface dry-monitor mirrors.

CONCURRENT PROGRESS = single writer owns terminal, per-task handles intercepted:
- indicatif MultiProgress (HIGH): add() REPLACES bar's draw target with "remote draw target intercepted by multi progress object". Internal lock held during ops → serializes drawing, no corruption. Default stderr, ~15fps.
- pterm MultiPrinter (MED): each task gets own writer via multi.NewWriter(), single printer owns rendering. AreaPrinter = live region redraw.
- socketry/console (HIGH, MOST RELEVANT, same author as async): "thread-safe global logger with PER-FIBER CONTEXT" — each async fiber carries own logging context. Same stream → terminal OR JSON. Serialized uses single IO#write per record + fiber_id to avoid interleaving. API: Console.info/warn/error(self, "msg", attrs). CONSOLE_LEVEL severity, CONSOLE_<LEVEL>=ClassName per-class.

TESTABILITY:
- null renderer same interface capturing (Bundler::UI::Silent) HIGH.
- capture structured event stream not bytes (RSpec notif objects, dry-events event[:key]) HIGH.
- pastel: Pastel.new(enabled: false) = passthrough no styling; Pastel.new(enabled: $stdout.tty?) auto-disable when redirected; pastel.strip removes color keeps cursor codes. HIGH. ← mechanism for ANSI-free test output.
- indicatif ProgressDrawTarget::hidden()/is_hidden(), println no-ops when hidden. HIGH.
- Ruby-specific golden-output write-up NOT FOUND.

KEY: socketry/console is only source natively unifying all three repo requirements (async/per-fiber concurrency + terminal-OR-JSON swap + structured key-value events).
