I have enough data. Writing findings now.

---

# Findings: launchd + mise-managed Ruby daemon on macOS

Scope: 4 areas, ~12 searches used. Primary sources preferred (launchd.info, `launchd.plist(5)`, `launchctl(1)`, mise-en-place docs, Apple developer). All quotes ≤ 2 sentences per source.

---

## 1. Plist configuration for a persistent always-on agent

**Minimal correct plist for "run forever, restart if it dies"** (synthesized from primary sources below):

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>           <string>com.example.repotender</string>
  <key>ProgramArguments</key>
  <array>
    <string>/absolute/path/to/runner</string>   <!-- argv[0]; may equal real path -->
    <string>arg1</string>
  </array>
  <key>RunAtLoad</key>       <true/>
  <key>KeepAlive</key>       <dict>
    <key>SuccessfulExit</key><false/>   <!-- restart on any non-zero exit -->
    <key>Crashed</key>      <true/>    <!-- restart on signal death -->
  </dict>
  <key>ThrottleInterval</key><integer>10</integer>
  <key>ProcessType</key>     <string>Background</string>
  <key>WorkingDirectory</key><string>/abs/path/to/working/dir</string>
  <key>EnvironmentVariables</key>
  <dict>
    <key>PATH</key><string>/abs/paths/colon:separated</string>
    <!-- additional vars as needed -->
  </dict>
  <key>StandardOutPath</key>  <string>/abs/path/to/out.log</string>
  <key>StandardErrorPath</key> <string>/abs/path/to/err.log</string>
  <key>SoftResourceLimits</key>
  <dict><key>NumberOfFiles</key><integer>8192</integer></dict>
</dict>
</plist>
```

### Per-key evidence

- **Label** — required, reverse-DNS by convention: *"This key is required for every job definition. It identifies the job and has to be unique for the launchd instance. By convention job names are written in reverse domain notation."* [high] (https://www.launchd.info/)
- **Location** — User Agents: `~/Library/LaunchAgents`. *"Job definitions for a specific user are stored below the respective user's Library directory."* [high] (https://www.launchd.info/)
- **Program / ProgramArguments** — *"A valid job definition requires at least one of these keys: Program and ProgramArguments."* First array element is argv[0] (effectively the executable). Shell expansion is **not** performed. [high] (https://www.launchd.info/)
- **RunAtLoad** — boolean, default false. *"This key is used to start the job as soon as it has been loaded. For daemons this means execution at boot time, for agents execution at login."* [high] (https://www.launchd.info/)
- **KeepAlive** — boolean OR dict. The most basic form (`<true/>`) means run on load and restart on death. [high] (https://www.launchd.info/)
  - `SuccessfulExit`: *"When set to true the job will be restarted until it fails. Setting this value to false will restart the job until it succeeds."* [high] (https://www.launchd.info/)
  - `Crashed`: *"When set to true the job will be restarted after it crashed. Setting this value to false will restart the job unless it has crashed."* [high] (https://www.launchd.info/)
  - `AfterInitialDemand`: suppresses eager start when combined with other conditions.
  - **Disagreement noted**: `KeepAlive=true` is the simplest "forever" form, but Apple's `launchd.plist(5)` documents it as a coarse "any exit causes restart". The dict form `{SuccessfulExit: false, Crashed: true}` is the explicit, semantically rich form and is the modern recommendation. Both are valid; pick the dict form for clarity. [med]
- **ThrottleInterval** — integer seconds. *"This key lets one override the default throttling policy imposed on jobs by launchd. The value is in seconds, and by default, jobs will not be spawned more [frequently than 10s]."* [high] (https://www.launchd.plist.5 man page) The default minimum is effectively 10s; even setting 0 or 1 is clamped to 10s in practice. [med] (https://apple.stackexchange.com/questions/63482/can-launchd-run-programs-more-frequently-than-every-10-seconds)
- **ProcessType** — string. Values: `Standard` (default), `Background`, `Adaptive`, `Interactive`. *"If left unspecified, the system will apply light resource limits to the job, throttling its CPU usage and I/O bandwidth."* For a non-UI daemon that should not be foreground, use `Background` (the system applies tighter CPU/IO caps that prevent it disrupting the user). [high] (https://www.real-world-systems.com/docs/launchdPlist.1.html)
- **WorkingDirectory** — *"This optional key is used to specify a directory to chdir(2) to before running the job."* Absolute path required (no `$HOME`, no `~`). [high] (https://manp.gs/mac/5/launchd.plist)
- **EnvironmentVariables** — dict of strings. *"Each key in the dictionary is the name of an environment variable, with the corresponding value being a string representing the desired value. NOTE: Values other than strings will be ignored."* No shell globbing, no variable expansion. [high] (https://www.launchd.info/) **Critical**: `$HOME` is **not** expanded — the CLI must resolve the user's home at install time and bake the absolute path into the plist. [med] (https://developer.apple.com/forums/thread/120784)
- **StandardOutPath / StandardErrorPath** — absolute paths, files are **appended** (not truncated on each run) and **never rotated by launchd**. *"it automatically appends (equivalent to `>>`, not `>`)"* [med] (https://stackoverflow.com/questions/13207365/how-can-i-add-arguments-to-osx-launchd-plist-to-pipe-output-to-a-log-file)
- **KeepAlive side-effect on launch** — when a KeepAlive subkey is specified, launchd *"will run the job immediately after loading. To avoid this behaviour set the subkey AfterInitialDemand."* Combined with `RunAtLoad=true` this is fine for a daemon; do not rely on it for "start only on demand". [high] (https://www.launchd.info/)

---

## 2. The Ruby / mise environment problem (KEY DECISION)

**Conclusion: use `mise exec -- ruby ...` (or a shim path) in `ProgramArguments`. Do NOT use `mise activate` — it is documented to fail in non-interactive environments.**

### Evidence

- **mise activate is interactive-only** (mise-en-place troubleshooting page, primary docs):
  > *"`mise activate` should only be used in `rc` files. These are the interactive ones used when a real user is using the terminal. (As opposed to being executed by an IDE or something). The prompt isn't displayed in non-interactive environments so PATH won't be modified."*
  > *"For non-interactive setups, consider using shims instead which will route calls to the correct directory by looking at `PWD` every time they're executed. You can also call `mise exec` instead of expecting things to be directly on PATH."*
  [high] (https://mise.en.dev/troubleshooting.html)

- **CI / non-interactive shells section** (same page):
  > *"Option 1: Use shims (recommended for CI): `export PATH="$HOME/.local/share/mise/shims:$PATH`"*
  > *"Option 2: Use `mise exec -- npm test`"*
  [high] (https://mise.en.dev/troubleshooting.html)

- **Shim directory** — `~/.local/share/mise/shims` is the default install location (XDG-style). Shims re-resolve at every invocation by looking at `PWD`, so they pick up the right project's `mise.toml`. [high] (https://mise.en.dev/dev-tools/shims.html)

- **`mise exec` semantics** — runs a one-off command with the full mise context (tools + env vars) loaded, including `mise.toml` env vars and per-tool versions. [high] (https://github.com/jdx/mise/blob/main/docs/getting-started.md)

- **`mise env`** — alternative: prints the resolved env vars to stdout. *"…it will only set up the global tools. It won't modify the environment variables when entering into a different project."* (i.e. per-directory `mise.toml` env won't apply — this is a real footgun for monorepos). [high] (https://mise.en.dev/troubleshooting.html)

### Recommended patterns, ranked

| Pattern | Verdict | Why |
|---|---|---|
| `ProgramArguments = (mise, exec, --, ruby, /abs/path/daemon.rb)` | **Preferred.** | Single `mise exec` resolves tool version + env vars from project `mise.toml` per PWD. No shell wrapper. |
| `ProgramArguments = (/abs/path/to/shims/ruby, daemon.rb)` | OK if you also put the shim dir in `EnvironmentVariables.PATH`. | Works, but requires that `WorkingDirectory` be set to the project root (shims resolve by PWD). |
| Wrapper shell script that `eval`s `mise env` and `exec`s ruby | Works, but adds a layer. **Avoid unless you need extra logic.** | mise docs do not recommend a wrapper; `mise exec` already handles env + version resolution. |
| `EnvironmentVariables.PATH = ".../shims:$PATH"` + use bare `ruby` in ProgramArguments | Brittle. | Requires shim dir to be in PATH; the daemon's `$PATH` is whatever you set; mixing with other tools gets confusing. |
| `mise activate` in any form | **Does not work.** | Confirmed broken in non-interactive contexts by mise docs. |

**Note on a hidden gotcha**: `mise exec` itself reads `mise.toml` from `$CWD` (or walks up). If the daemon's `WorkingDirectory` is not the project root, the wrong `mise.toml` (or none) may be picked. Mitigation: either set `WorkingDirectory` to the project root, or use `MISE_CONFIG_FILE=/abs/path/mise.toml` set in `EnvironmentVariables` to pin the config file explicitly.

**Cite**: mise-en-place troubleshooting (https://mise.en.dev/troubleshooting.html) and shims (https://mise.en.dev/dev-tools/shims.html) are the primary docs.

---

## 3. Modern `launchctl` control commands (NOT legacy `load`/`unload`)

### Subcommand matrix

| Operation | Modern command (use this) | Legacy (do not use in new code) |
|---|---|---|
| Install (first time / after plist edit) | `launchctl bootstrap gui/$UID ~/Library/LaunchAgents/<file>.plist` | `launchctl load -w <plist>` |
| Remove | `launchctl bootout gui/$UID/<label>` | `launchctl unload -w <plist>` |
| Restart (kill + relaunch) | `launchctl kickstart -k gui/$UID/<label>` | `launchctl unload && load` |
| Enable (clear disabled override) | `launchctl enable gui/$UID/<label>` | `launchctl load -w` |
| Disable (persistent across boots) | `launchctl disable gui/$UID/<label>` | n/a |
| Status (human-readable) | `launchctl print gui/$UID/<label>` | `launchctl list <label>` |
| Status (programmatic, PID + last exit) | `launchctl list` (3 cols: PID, last-exit, label) | `launchctl list <label>` |
| Send signal | `launchctl kill SIGTERM gui/$UID/<label>` | `killall` |

### Evidence

- **Legacy is documented as legacy** — `man launchctl`: *"Legacy subcommands should still work."* The man page lists `bootstrap` / `bootout` / `kickstart` / `enable` / `disable` / `print` / `kill` as the current subcommands. [high] (https://manp.gs/mac/1/launchctl)
- **Domain syntax for a per-user LaunchAgent**:
  > *"gui/<uid>/[service-name] Targets the GUI domain or service within. Each GUI domain is associated with a user domain, and a process running as the owner of that user domain may make modifications."*
  [high] (https://manp.gs/mac/1/launchctl)
  - Use `gui/$UID` (not `user/$UID`) for a normal interactive user agent — `gui/$UID` is bound to the logged-in GUI session, which is the conventional target for `~/Library/LaunchAgents` agents. `user/$UID` would target the background-only user domain. [med] (https://thekodelab.com/en/posts/macos-gui-terminal-vs-ssh-session/)
- **`bootstrap` / `bootout`**:
  > *"Bootstrap a domain/service (equivalent to Load in the legacy syntax). Services may be specified as a series of paths or a service identifier."*
  > *"Bootstraps or removes domains and services."*
  [high] (https://ss64.com/mac/launchctl.html)
- **`kickstart -k`**:
  > *"Instructs launchd to run the specified service immediately, regardless of its configured launch conditions. `-k` If the service is running, kill it first."*
  [high] (https://manp.gs/mac/1/launchctl)
- **`enable` / `disable`** — persist across boots via the override database. *"This subcommand may only target services within the system domain or user and user-login domains."* [high] (https://manp.gs/mac/1/launchctl)
- **`print` output** — *"Service output includes various properties of the service, including information about its origin on-disk, its current state, execution context, and last exit status. ... IMPORTANT: This output is NOT API in any sense at all. Do NOT rely on the structure."* [high] (https://ss64.com/mac/launchctl.html). The "state" line is human-readable text like `state = running` / `state = not running`. Real-world parsers grep for `"state = running"` (an-lee/gh-sr, 2026-06-01 commit). [med] (https://github.com/an-lee/gh-sr/commit/88bd0be25b7e9650870cf1846bed2c3537f836bc)
- **`launchctl list` columns** (the canonical programmatic status check):
  > *"The first column displays the PID of the job if it is running. The second column displays the last exit status of the job. If the number in this column is negative, it represents the negative of the signal which killed the job. Thus, '-15' would indicate SIGTERM."*
  [high] (https://www.launchd.info/)
  - PID `-` means "loaded but not running" (which is a normal moment in a restart cycle).
  - Exit code `0` = clean, positive = error, negative = killed by signal.

### Programmatic status recipe (recommended)

```bash
# Quick: PID in column 1 of `launchctl list`
pid=$(launchctl list | awk -v lbl="com.example.repotender" '$3==lbl{print $1}')

# Full: prefer this when you need to know "running vs loaded but not running"
# and you can tolerate a non-stable output format
launchctl print "gui/$UID/com.example.repotender" | grep -E '^\s*(state|last exit code)\s*='
```

**Disagreement noted**: `launchctl print` is human-readable (man page: *"NOT API in any sense"*), while `launchctl list` output is tabular and is the de-facto API. Use `launchctl list` (or parse its columns) in production code; reserve `print` for debugging. [med]

---

## 4. Logging & ops

- **launchd does not rotate logs** — files append forever until something else cleans them. *"When a macOS service uses StandardOutPath and StandardErrorPath in its launchd plist, those files just append forever."* (Real-world report with 38 MB log file as evidence.) [med] (https://patelhiren.com/blog/macos-newsyslog-openclaw-logs/)
- **Known bug after manual rotation** — rotating a launchd-managed log file from outside (e.g. `mv` + recreate) can break stdout redirection until the agent restarts. *"launchd fails to redirect stdout to the file after log rotation."* [med] (https://github.com/apple-opensource/launchd/issues/1)
- **Where to write** — macOS-native convention for per-user app data is `~/Library/Logs/<AppName>/`. There is no Apple-blessed `XDG_STATE_HOME`-style on macOS (XDG is a Linux/Freedesktop convention; not enforced on macOS). Apple TN2083 does not specify a log directory beyond noting `StandardOutPath`/`StandardErrorPath`. [med] (https://developer.apple.com/library/archive/technotes/tn2083/_index.html)
- **Rotation options for a per-user agent**:
  1. Self-rotate from inside the daemon (open with `O_APPEND`, `fwrite`, periodic reopen with timestamp in name). Simplest; daemon controls its own log shape.
  2. `newsyslog` (system log rotator) with a per-user `~/.newsyslog.conf` (works on macOS, config in `/etc/newsyslog.conf` or `~/.newsyslog.conf`). Limitation: newsyslog truncates/rotates on its own schedule, not coordinated with the running daemon's open fd — so reopen-from-within is still safer. [med] (https://patelhiren.com/blog/macos-newsyslog-openclaw-logs/)

---

## 2-3 findings most likely to change a design decision

1. **`mise activate` is documented-broken in non-interactive environments** (cite: mise-en-place troubleshooting page). The CLI must put `mise exec -- ruby ...` (or a shim + `WorkingDirectory` set to project root) into the plist's `ProgramArguments`. Any design that assumes `PATH` activation in the launchd environment will silently fail to find Ruby/gem binaries. **(High confidence, design-critical.)**

2. **`EnvironmentVariables` and `WorkingDirectory` do not perform shell expansion** — no `$HOME`, no `~` (cite: `launchd.plist(5)`; https://developer.apple.com/forums/thread/120784). The CLI must resolve `$HOME` at install time and write absolute paths into the plist. This drives the design of the install command (it must accept a `--user` / `$SUDO_USER` / current `$UID` flag, and compute `~/Library/LaunchAgents/<label>.plist` itself).

3. **launchd does not rotate log files and external rotation can break the agent's fd** (cite: https://github.com/apple-opensource/launchd/issues/1; https://patelhiren.com/blog/macos-newsyslog-openclaw-logs/). The daemon must implement in-process log rotation (reopen on SIGHUP / interval, or write timestamped files from the start). Choosing `newsyslog` as the primary rotation strategy risks the broken-redirect bug after rotation. **(High confidence for launchd's no-rotation; med for the external-rotation fd bug.)**

A close runner-up: **`KeepAlive=true` is acceptable for a forever-running daemon, but the dict form `{SuccessfulExit: false, Crashed: true}` is the explicit, audit-friendly form and is what Apple documents in the man page.** Pick the dict form so the intent is visible to anyone reading the plist.

---

### Sources cited (primary first)

- launchd.info — A launchd Tutorial. https://www.launchd.info/ [primary; high]
- `launchd.plist(5)` man page. https://manp.gs/mac/5/launchd.plist [primary; high]
- `launchctl(1)` man page. https://manp.gs/mac/1/launchctl [primary; high]
- Apple — Creating Launch Daemons and Agents. https://developer.apple.com/library/archive/documentation/MacOSX/Conceptual/BPSystemStartup/Chapters/CreatingLaunchdJobs.html [primary; high]
- Apple TN2083: Daemons and Agents. https://developer.apple.com/library/archive/technotes/tn2083/_index.html [primary; high]
- mise-en-place — Troubleshooting. https://mise.en.dev/troubleshooting.html [primary; high]
- mise-en-place — Shims. https://mise.en.dev/dev-tools/shims.html [primary; high]
- mise-en-place — Getting Started. https://mise.jdx.dev/getting-started.html [primary; high]
- ss64.com — launchctl. https://ss64.com/mac/launchctl.html [secondary; med]
- launchd keywords for plists (real-world-systems). https://www.real-world-systems.com/docs/launchdPlist.1.html [secondary; med]
- launchd fails to redirect stdout to the file after log rotation (apple-opensource/launchd#1). https://github.com/apple-opensource/launchd/issues/1 [secondary; med]
- Using macOS newsyslog to Rotate Service Logs. https://patelhiren.com/blog/macos-newsyslog-openclaw-logs/ [secondary; med]
- Can launchd run programs more frequently than every 10 seconds? https://apple.stackexchange.com/questions/63482/can-launchd-run-programs-more-frequently-than-every-10-seconds [secondary; med]
- $HOME / ~ not expanded in plist. https://developer.apple.com/forums/thread/120784 [secondary; med]
- macOS GUI Terminal vs. SSH Sessions: Why launchctl managername Matters. https://thekodelab.com/en/posts/macos-gui-terminal-vs-ssh-session/ [secondary; med]
