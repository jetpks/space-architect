I have enough material. Writing the findings.

---

# Findings: CLI ↔ Daemon Interaction & Supervision (launchd + socketry)

> **Context recap:** Ruby 4.0.5 macOS LaunchAgent daemon, socketry/async ecosystem, companion CLI that performs CRUD on persisted config and must reflect changes live in the daemon plus report daemon status.

---

## 1. CLI → Daemon Communication: Three Live Patterns

### 1a. CONFIG-FILE-WATCH (CLI rewrites, daemon watches)

- **What `listen` provides on macOS** — listen 3.10.0 (`lib/listen/version.rb`, https://github.com/guard/listen) ships a Darwin adapter that calls directly into `rb-fsevent` (FSEvents under the hood): "private def _run; require 'rb-fsevent'; worker = FSEvent.new; ... worker.watch(dirs_to_watch, { latency: options.latency }, &method(:_process_changes))" (https://github.com/guard/listen/blob/master/lib/listen/adapter/darwin.rb). **confidence: high**
- **Caveats (primary source):** the listen README itself says "OSX adapter has some performance limitations (#342)" and "Some filesystems won't work without polling (VM/Vagrant Shared folders, NFS, Samba, sshfs, etc.)" and "Listeners do not notify across forked processes" (https://github.com/guard/listen README, accessed via repo clone). **confidence: high**
- **macOS-specific gotcha from Apple:** launchd.plist(5) `WatchPaths` key documentation reads: "Use of this key is highly discouraged, as filesystem event monitoring is highly race-prone, and it is entirely possible for modifications to be missed. When modifications are caught, there is no guarantee that the file will be in a consistent state when the job is launched." (https://keith.github.io/xcode-man-pages/launchd.plist.5.html). **confidence: high** — Apple itself says file-watch is not a reliable launch trigger, and the same race applies to a daemon watching a config file (rename-then-write / write-then-rename patterns need debouncing).
- **Trade-off:** cheapest to implement, no new permissions surface, but gives **no live answer back to CLI** (CLI cannot ask "is the daemon healthy / what is the current status").

### 1b. SIGNAL RELOAD (CLI triggers SIGHUP via launchctl)

- **launchd kill support is real and documented** — `launchctl kill signal-name | signal-number service-target` "Sends the specified signal to the specified service if it is running. The signal number or name (SIGTERM, SIGKILL, etc.) may be specified." (https://keith.github.io/xcode-man-pages/launchctl.1.html). For a per-user LaunchAgent the specifier is `gui/$UID/<label>`, so the CLI can do e.g. `launchctl kill SIGHUP gui/$UID/com.example.repo-tender`. **confidence: high**
- **Daemon-side pattern is well-defined in async** — `Async::IO::Trap.new('SIGHUP').install!` + `wait { |task| reload_config }` (https://github.com/socketry/async-io/blob/master/lib/async/io/trap.rb). Ruby `Signal.trap` runs in a safe context; `Async::IO::Trap` marshals the signal into the reactor via a notification pipe so the reload happens on a fiber, not in the trap handler. **confidence: high**
- **Trade-off:** still no synchronous answer back to the CLI ("did reload succeed? what version is loaded?"). SIGHUP is fire-and-forget.

### 1c. IPC SOCKET (UNIX domain — daemon listens, CLI connects)

- **io-endpoint 0.17.2** is the current, supported library (https://github.com/socketry/io-endpoint, releases in README). The `async-io` gem that previously held `Async::IO::UNIXEndpoint` is **deprecated**: "This library is deprecated and should not be used in new projects. Instead, you should use https://github.com/socketry/io-endpoint" (https://github.com/socketry/async-io README). **confidence: high**
- **Working UNIX socket code (primary source, https://socketry.github.io/io-endpoint/guides/getting-started/):**
  ```ruby
  require "io/endpoint"
  endpoint = IO::Endpoint.unix("/tmp/myapp.sock")
  endpoint.bind do |server|
    server.listen(10)
    loop do
      client, address = server.accept
      # Handle the client connection
      client.close
    end
  end
  ```
  Client side is the symmetric `endpoint.connect { |socket| ... }`. **confidence: high**
- **Stale-socket safety is built in** — `IO::Endpoint::UNIXEndpoint#bind` catches `Errno::EADDRINUSE`, attempts `bound?` (a probe `connect`), and unlinks + retries if the socket is not actually held by a live process (https://github.com/socketry/io-endpoint/blob/master/lib/io/endpoint/unix_endpoint.rb). **confidence: high**
- **Long-path safety is built in** — release v0.17.2: "When the unix path is bigger than what can fit into `struct sockaddr_un`, a shorter temporary path will be used instead and a symlink created at the original path." (https://github.com/socketry/io-endpoint README, current release notes). **confidence: high**
- **Mac/Linux UNIX path length is typically 104–108 bytes (sizeof sockaddr_un.sun_path)** — the symlink trick matters if you put the socket inside `~/.local/state/repo-tender/`. **confidence: high** (well-known POSIX limit; io-endpoint paper over it for you).
- **A line/JSON or new-line-delimited-JSON protocol over a UNIX socket is idiomatic** and matches what `Async::IO::Protocol::Line` provides (https://github.com/socketry/async-io, `lib/async/io/protocol/line.rb` exists; example `examples/unix/server.rb` and `examples/unix/client.rb` use exactly this shape with `read(6)` + `send "elloh\n"`). **confidence: high**
- **Falcon, the canonical socketry web server, uses a UNIX IPC socket for its "virtual" deployment mode** — Falcon v0.55.5 README/deployment guide: "This configuration will bind Falcon to an [IPC socket](...) and is designed to be used with a reverse proxy such as `falcon virtual`" (https://socketry.github.io/falcon/guides/deployment/). The proxy diagram in that guide labels the link "HTTP/2 UNIX PIPE". **confidence: high** — this is the most direct precedent inside the socketry ecosystem for "daemon listens on a UNIX socket, peer speaks an HTTP-ish line protocol to it."
- **Trade-off:** gives synchronous liveness (`connect` to socket = "daemon alive" in O(1ms)"), supports CRUD commands + status queries, but adds a new surface that needs: socket path (XDG), file mode (0600), and a way for CLI to find it when the daemon is not running.

### Trade-off matrix (synthesis)

| Pattern | Liveness to CLI | Complexity | New attack surface | Failure mode |
|---|---|---|---|---|
| File-watch (1a) | none | lowest | none | silent drop on FSEvents race; Apple itself says "highly race-prone" |
| SIGHUP reload (1b) | none (ack is async) | low | none (uses launchd) | if daemon crashed, SIGHUP returns "service not running" |
| UNIX socket (1c) | yes, synchronous | medium | socket file mode/path | stale socket on crash → io-endpoint handles unlink+retry |

---

## 2. Daemon Supervision Under launchd

- **Hard rule (Apple primary source, https://developer.apple.com/library/archive/documentation/MacOSX/Conceptual/BPSystemStartup/Chapters/CreatingLaunchdJobs.html):** "You must not daemonize your process. This includes calling the `daemon` function, calling `fork` followed by `exec`, or calling `fork` followed by `exit`. If you do, `launchd` thinks your process has died. Depending on your property list key settings, `launchd` will either keep trying to relaunch your process until it gives up (with a 'respawning too fast' error message) or will be unable to restart it if it really does die." **confidence: high**
- **launchd.plist(5) mirrors it in MUST language:** "A daemon or agent launched by `launchd` MUST NOT: Call daemon(3). Do the moral equivalent of daemon(3) by calling fork(2) and have the parent process exit(3) or _exit(2)." (https://keith.github.io/xcode-man-pages/launchd.plist.5.html). **confidence: high**
- **Implication for PID files:** a traditional PID file is essentially a workaround for the missing init/supervisor. Under launchd you do not need one for supervision — `launchctl print gui/$UID/<label>` shows the live PID (and `kickstart -p` prints it). The only legitimate use of a PID file under launchd is "the CLI needs to do something that requires knowing the PID" — and even then `launchctl` is the canonical source. **confidence: high** (synthesis from launchd docs).
- **Recommended behavior (Apple):** "Handle the SIGTERM signal, preferably with a dispatch(3) source, and respond to this signal by unwinding any outstanding work quickly and then exiting." `Async::IO::Trap` is the Ruby analog. **confidence: high**
- **How a CLI detects "is the daemon running?":** three viable signals, in increasing order of cost and decreasing order of precision:
  1. `launchctl print gui/$UID/<label>` — parses "state = running" + PID. Slow (~50–200ms) and Apple warns output is not API: "_IMPORTANT_: This output is NOT API in any sense at all. Do NOT rely on the structure or information emitted for ANY reason. It may change from release to release without warning." (launchctl(1)). **confidence: high**
  2. UNIX socket `connect` — fastest, no process spawn, doubles as a real liveness + version probe. **confidence: high** (the idiomatic answer).
  3. PID file written by the daemon at startup — works, but offers no live signal beyond "is this PID alive?" (`kill -0`), so you usually end up doing 1 or 2 anyway. **confidence: med** (synthesis; the docs do not directly recommend or forbid it).

---

## 3. State vs Config vs Runtime Separation (XDG)

- **Current spec is v0.8, dated 2021-05-08** (https://specifications.freedesktop.org/basedir-spec/basedir-spec-latest.html). Defaults: `XDG_CONFIG_HOME=$HOME/.config`, `XDG_STATE_HOME=$HOME/.local/state`, `XDG_DATA_HOME=$HOME/.local/share`, `XDG_RUNTIME_DIR` user-owned 0700. **confidence: high**
- **$XDG_RUNTIME_DIR is the explicitly-correct location for our UNIX socket.** Direct quote from spec: "The `$XDG_RUNTIME_DIR` ... user-specific non-essential runtime files and other file objects (such as sockets, named pipes, ...) should be placed. The directory MUST be owned by the user, and they MUST be the only one having read and write access to it. Its Unix access mode MUST be 0700." The spec also says "Applications should use this directory for communication and synchronization purposes and should not place larger files in it." **confidence: high**
- **$XDG_STATE_HOME purpose (direct quote from spec):** "contains state data that should persist between (application) restarts, but that is not important or portable enough to the user that it should be stored in `$XDG_DATA_HOME`. It may contain: actions history (logs, history, recently used files, …); current state of the application that can be reused on a restart (view, layout, open files, undo history, …)." **confidence: high** — this is exactly the right place for "last-sync timestamps, per-repo status cache, run logs."
- **$XDG_CONFIG_HOME** is for "user-specific configuration files" — this is where tracked repos / orgs / base dir go. **confidence: high**
- **Concrete mapping for this project:**
  - `~/.config/repo-tender/config.toml` (or `.json`) — tracked repos, orgs, base dir (durable user intent, edited by CLI)
  - `~/.local/state/repo-tender/` — last-sync timestamps, per-repo status cache, log file
  - `$XDG_RUNTIME_DIR/repo-tender.sock` — the daemon's UNIX socket
  - StandardOutPath / StandardErrorPath in the LaunchAgent plist → a file under `~/.local/state/repo-tender/` (Apple creates the file for you if it does not exist: "If the file does not exist, it will be created with writable permissions and ownership reflecting the user..."). **confidence: high** (launchd.plist(5) `StandardOutPath`).

---

## 4. Adjacent Production Tools — Structural Lessons

### 4a. `ghq` (https://github.com/x-motemen/ghq) — Go, single CLI, no daemon

- **Architecture:** one binary, one-shot subcommands (`get`, `list`, `root`, `rm`, `create`, `migrate`). No background process, no IPC, no socket. **confidence: high** (README structure: 6 cmd_*.go files, all CLI handlers, no daemon entrypoint).
- **Config location:** **does not use XDG**. Configuration is stored in `git config` variables: "Configuration uses 'git-config' variables. ... `ghq.root` ... Defaults to `~/ghq`." (https://github.com/x-motemen/ghq README). **confidence: high**
- **Update strategy:** user-driven, on-demand: `ghq get -u` does a `git pull --ff-only`. No periodic auto-sync. **confidence: high**
- **Structural lesson:** for a "where is X" tool, having a single config root and one CLI is enough — no daemon needed. But the moment you want background polling, the design flips and you need a long-running process. **confidence: med** (synthesis).

### 4b. `mr` / myrepos (https://myrepos.branchable.com/) — Perl, single CLI, no daemon

- **Architecture:** "All you need to get started is some already checked out repos... Inside each of your repositories, run `mr register`. That sets up a `~/.mrconfig` file listing your repositories." Recursive CLI: "any `mr` command runs recursively over any repository located somewhere in or under the current directory." **confidence: high**
- **Config location:** `~/.mrconfig` — **a single flat file**, not a directory, with `[DEFAULT]` and per-section blocks. **confidence: high**
- **Refresh pacing:** built into the tool's mental model: "Update a repository no more frequently than once every twelve hours." **confidence: high**
- **Failed-action queuing:** "Remember actions that failed due to a laptop being offline, so they can be retried when it comes back online." (no in-memory state — persisted to config so it survives a restart). **confidence: high**
- **Structural lesson:** rate-limiting refresh and persisting the work queue are features of the *config model*, not of a daemon. If we add a daemon, we should still let the config express per-repo cadence and last-tried-at. **confidence: med** (synthesis).

### 4c. `Falcon` (https://github.com/socketry/falcon) — Ruby/socketry, the canonical reference

- **Architecture:** multi-process, multi-fiber HTTP server on top of `async`, `async-container`, `async-http`, `async-service`. **confidence: high** (Falcon README)
- **Deployment mode relevant to us:** `falcon virtual` is built around a UNIX IPC socket between a reverse proxy and the app server: "graph TD; client[Client Browser] -->|TLS + HTTP/2 TCP| proxy["Falcon Proxy (SNI)"]; proxy -->|HTTP/2 UNIX PIPE| server[Application Server]" (https://socketry.github.io/falcon/guides/deployment/). **confidence: high**
- **Supervisor service:** Falcon's own deployment config adds an `Async::Service::Supervisor` service in the same `falcon.rb` so one process tree covers the app, its workers, and the supervisor — i.e. one user-facing unit, multiple coordinated processes. **confidence: high**
- **Structural lesson for us:** the socketry project's own pattern for "long-running async daemon + CLI/admin" is a UNIX domain socket as the boundary, with a structured line/HTTP protocol on top, and a separate supervisor process. **confidence: high**

---

## 5. The 2–3 Findings Most Likely to Change a Design Decision

1. **Async::IO is deprecated; io-endpoint (0.17.2) is the current UNIX-socket API in the socketry ecosystem** (https://github.com/socketry/async-io README "deprecated"; https://github.com/socketry/io-endpoint). If the design says `Async::IO::Endpoint.unix(...)`, it should say `IO::Endpoint.unix(...)` instead, on `io-endpoint` 0.17.x. Stale-socket handling and long-path symlink tricks are built in.

2. **launchd forbids self-daemonization in MUST language and explicitly says to handle SIGTERM, not SIGHUP** (https://keith.github.io/xcode-man-pages/launchd.plist.5.html). A SIGHUP-reload pattern is *fine* — `launchctl kill SIGHUP gui/$UID/<label>` works — but a LaunchAgent is not a SysV init script, and double-fork / PID-file-for-supervision designs are actively wrong here. The CLI should detect "daemon running" by `connect()`-to-socket, not by parsing `launchctl print` output (Apple's docs say that output is not API and may change).

3. **The UNIX socket belongs in `$XDG_RUNTIME_DIR`, not next to the config or in `/tmp`** (https://specifications.freedesktop.org/basedir-spec/basedir-spec-latest.html — "user-specific non-essential runtime files and other file objects (such as sockets, named pipes, ...) should be placed" in `$XDG_RUNTIME_DIR`, mode 0700, owned by the user). On macOS, `$XDG_RUNTIME_DIR` is **not set by default** for GUI sessions; well-behaved tools fall back to a per-user directory with 0700 (e.g. `Dir.tmpdir`/per-user subdir, or a fixed `$HOME/.run/repo-tender/`). The spec says: "If `$XDG_RUNTIME_DIR` is not set applications should fall back to a replacement directory with similar capabilities and print a warning message." This is a real cross-platform portability issue and a security choice (world-readable `/tmp/repo-tender.sock` would be a bug).

---

**Sources used (all primary):**
- https://github.com/guard/listen (README, `lib/listen/version.rb`, `lib/listen/adapter/darwin.rb`)
- https://github.com/socketry/io-endpoint (README, `lib/io/endpoint/unix_endpoint.rb`, getting-started guide)
- https://github.com/socketry/async-io (README — deprecation notice, `lib/async/io/trap.rb`, `examples/unix/`)
- https://github.com/socketry/falcon (README, https://socketry.github.io/falcon/guides/deployment/)
- https://developer.apple.com/library/archive/documentation/MacOSX/Conceptual/BPSystemStartup/Chapters/CreatingLaunchdJobs.html
- https://keith.github.io/xcode-man-pages/launchd.plist.5.html and launchctl.1.html
- https://specifications.freedesktop.org/basedir-spec/basedir-spec-latest.html (v0.8, 2021-05-08)
- https://github.com/x-motemen/ghq (README)
- https://myrepos.branchable.com/

**NOT FOUND (could not verify from primary source within search budget):** `mani` and `gita` — both attempted GitHub URLs returned 404, suggesting the repos have moved/been renamed/been deleted. Not load-bearing for this objective given the three tools I did verify cover the spectrum (single-CLI no-daemon in Go, single-CLI no-daemon in Perl with per-repo config, and socketry's own UNIX-socket RPC pattern).
