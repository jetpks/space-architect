# Lane 2: Animation under Async fibers (raw findings)

VERDICT: Thread-free fiber-driven animation IS feasible (high confidence on mechanism).

Q1 manual single-step:
- tty-spinner: `spin` = manual single frame, NO thread, advances frame counter + renders. `auto_spin` is the threaded one (Thread.new { loop { spin; sleep } }). No `tick` method. Lifecycle: start/stop/success/error manual.
- tty-progressbar: intrinsically manual, NO animation thread. advance(n), current=, ratio=, start, finish/stop/pause/resume. `frequency:` option (Hz) throttles repaint.
- whirly: NO manual mode; start always spawns Thread. render is private. Avoid.

Q2 timing in reactor:
- `Kernel#sleep duration` inside Async task → scheduler hooks kernel_sleep → `block(nil, duration)` → suspends fiber, reactor runs others. NO Thread. (primary: Async::Scheduler source)
- Async::Task#sleep DEPRECATED → use plain Kernel#sleep.
- `Async { loop { render; sleep 0.08 } }` valid pattern.
- Async::Scheduler#with_timeout(duration) exists. socketry/timers gem for periodic (#every) but not needed.
- NOT FOUND: no class literally `Async::Timer` in current async.

Q3 concurrent N bars:
- TTY::ProgressBar::Multi exists. Threads EXPLICITLY OPTIONAL — synchronous advancement documented & supported. Multi handles cursor save/restore/redraw internally. Maps cleanly to single-writer-fiber.
- Single-threaded reactor = no interleaved mid-print writes; each fiber's advance/spin runs to completion before another resumes (yield only at sleep/IO). Single-writer-fiber is natural fit, eliminates thread-corruption bugs.

Q4 prior art:
- NOT FOUND: no published example of async + tty-spinner/progressbar.
- Console::Progress (socketry/console): increment(n), mark, resize(total), ratio. Emits STRUCTURED progress events via Console.call with payload {type: :progress, current:, total:, duration:, estimated_remaining_time:}, rate-limited minimum_output_duration default 0.1s. Log/structured, NOT animated in-place. async depends on console ~> 1.29.

MECHANISM (grounded): animation gem with manual single-step (tty-spinner spin / tty-progressbar advance) + Async task loop using Kernel#sleep + single render/writer fiber that ticks while bounded worker fibers update shared progress state (serialized by single-threaded reactor). Eliminates cross-thread terminal corruption.
