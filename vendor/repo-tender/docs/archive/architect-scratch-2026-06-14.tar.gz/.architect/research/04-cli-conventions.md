# Lane 4: Dual-mode CLI conventions (raw findings)

NO_COLOR (no-color.org, HIGH primary): "check for NO_COLOR env var that, when present and not an empty string (regardless of value), prevents addition of ANSI color." Trigger = presence + non-empty. NO_COLOR= (empty) does NOT trigger; NO_COLOR=0/false DO.

CLICOLOR/CLICOLOR_FORCE (bixense.com/clicolors, HIGH):
- NO_COLOR set → no color.
- CLICOLOR_FORCE set (NO_COLOR unset) → force color always (even piped).
- CLICOLOR set → color when writing to terminal.
Precedence: NO_COLOR > CLICOLOR_FORCE > CLICOLOR > default.

TERM=dumb (clig.dev): disable color.

clig.dev rules (HIGH primary, verbatim):
- Disable color when: stdout/stderr not a TTY; NO_COLOR set non-empty; TERM=dumb; --no-color passed. Optionally MYAPP_NO_COLOR.
- "If stdout is not an interactive terminal, don't display any animations" (stops progress bars → christmas trees in CI).
- --plain = plain tabular for grep/awk. --json = formatted JSON.
- -q/--quiet = less output.
- stdout = primary + machine-readable output. stderr = logs/errors. Don't print log-level labels to stderr by default (only verbose).

PRECEDENCE (clig.dev, HIGH): Flags > env vars > project config > user config > system config. = flag > env > autodetect.

TTY detection (Ruby STDOUT.tty?/isatty) INSUFFICIENT alone: pipes/redirects make non-TTY even for humans (less); CI has no TTY but human reads (need CI env var); stdout/stderr independent; gh GH_FORCE_TTY for styled-through-pipe; systemd /dev/console isatty can fail (false negatives, issue #26864).

CI detection (MED, convention not spec): check CI env var (+ CONTINUOUS_INTEGRATION). ci-info detects vendor vars. clig.dev does NOT mention CI.

PER-CLI:
- git: --color=auto|always|never, color.ui config; auto=default. respects NO_COLOR recent.
- gh: NO --color flag (declined). env only: NO_COLOR, CLICOLOR (0=disable), CLICOLOR_FORCE, GH_FORCE_TTY. --json <fields> +--jq/--template; auto tab-delimited no-color when piped.
- cargo: --color auto|always|never, CARGO_TERM_COLOR; flag overrides env. --message-format=json.
- ripgrep: --color never|auto|always|ansi (auto default); respects NO_COLOR.
- kubectl: -o json|yaml|wide|name|go-template|jsonpath|custom-columns.
- npm: --color/--no-color, NO_COLOR, FORCE_COLOR=0..3, --json.
- systemd: SYSTEMD_COLORS; auto-suppress color/pager when not TTY.
DISAGREEMENT: machine-mode signal varies (--json / -o / --format / --plain / --porcelain), no universal flag. gh deliberately no --color flag.

DAEMON/SERVICE:
- 12factor (HIGH): each process writes event stream UNBUFFERED to stdout; execution env captures/routes. Canonical daemon pattern.
- systemd/launchd: stdout/stderr are pipes → isatty false → tools auto-pick non-interactive/quiet/structured.
- No universal --daemon output flag. --daemon usually governs backgrounding not output format. Rely on TTY autodetect + --quiet/--no-color/--json. NOT FOUND: standardized cross-tool --non-interactive output flag.

RENDERER ABSTRACTION (MED/LOW): Strategy pattern. nvme-cli stdout_print_ops struct of fn pointers per mode. AWS CLI --output json|text|table|yaml single selector. General shape: Renderer/Formatter interface w/ Interactive vs Plain vs JSON impls, selected by resolver: flag > env(NO_COLOR/CLICOLOR_FORCE/CI) > stdout.tty?. NOT FOUND: single canonical named pattern (it's Strategy + clig.dev precedence).
