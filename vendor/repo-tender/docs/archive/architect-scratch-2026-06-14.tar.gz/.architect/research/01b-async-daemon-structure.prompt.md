You are a web research agent. Answer ONE narrow objective. Do not write code, do
not make recommendations. Budget: 12 searches; if two consecutive searches
yield no new load-bearing facts, STOP and return. HARD CONTEXT RULES: never
open a full page when the search snippet answers the question; quote at most 2
sentences per source; the MOMENT you can answer, STOP and write findings —
partial findings beat context exhaustion (agents that fill their window die
without writing anything, returning NOTHING). Do NOT fetch more than ~5 full
pages total; prefer search snippets and GitHub README/source metadata. OUTPUT:
markdown — every finding carries source URL, source date, exact figure or short
quote, confidence tag (high=primary / med=reputable secondary / low=single
blog). Record exact gem versions + dates. Report disagreements; never resolve.
NOT FOUND beats inference. End with the 2-3 findings most likely to change a
design decision.

CONTEXT: A long-running Ruby 4.0.5 daemon on macOS using socketry/async needs
to (a) run many subprocess tasks concurrently with a bound, and (b) run
periodic work (a sync sweep every 6 hours) under a supervised reactor, with
graceful shutdown.

OBJECTIVE — Only the CONCURRENCY + DAEMON-STRUCTURE question (NOT how to run a
single subprocess; a separate lane covers that).

1. CONCURRENCY CONTROL in async. Current API + idiom for "fan out M tasks, run
   at most K concurrently, collect all results": `Async::Barrier`,
   `Async::Semaphore`, `Async::WaitGroup`. Which combination is idiomatic, and
   the current `async` gem version. Cite socketry/async docs or README.

2. LONG-LIVED REACTOR / DAEMON ENTRYPOINT. The idiomatic top-level entrypoint
   for a daemon: `Async do ... end` vs `Sync`, a supervising parent task that
   spawns/monitors children, and how a never-returning reactor is kept alive.
   How is a child task that crashes handled/restarted (supervision)? Cite docs.

3. PERIODIC SCHEDULING. The idiom for "do X every 6 hours" under async — a
   plain `loop { sleep; work }` task vs a dedicated gem. Does `async-clock`
   exist? Is there an `async`-native periodic timer / `Async::Clock` /
   `reactor.every`? Current versions of any scheduler gem found
   (async-clock, async-scheduler, async-cron) — or NOT FOUND.

4. GRACEFUL SHUTDOWN. Trapping SIGTERM/SIGINT to stop the reactor cleanly under
   async (so in-flight git operations finish or cancel). The idiom (Signal.trap
   + task.stop / reactor interrupt). Cite docs or a maintainer example.

Subjects (cap 4): socketry/async (Barrier/Semaphore/Task/Reactor), any async
periodic-scheduler gem, async graceful-shutdown idiom. Stay narrow.

End with the 2-3 findings most likely to change our design.
