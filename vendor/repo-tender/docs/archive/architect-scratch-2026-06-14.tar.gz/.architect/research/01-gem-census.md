# Lane 1: Ruby terminal-UX gem census (raw findings)

KEY VERIFIED FACTS (source read on GitHub main):
- tty-spinner: auto_spin spawns Thread.new (animation thread) + job thread in run. BUT `spin` single-tick can be called manually with no thread. deps: tty-cursor. last release 2020-01-28.
- whirly: infinite-loop render Thread. v0.4.0 2025-12-27 (recently shipped).
- cli-ui (Shopify): thread-pool WorkQueue (Thread.new workers + Mutex/ConditionVariable). Most thread-heavy. ZERO runtime deps. ACTIVELY maintained (commit 2026-06-10, v2.7.0).
- tty-progressbar: NO Thread. Caller drives bar.advance. Synchronous render. deps: strings-ansi, tty-cursor, tty-screen, unicode-display_width. v0.18.3 2024-11-10. Supports Multi (multi-bar).
- pastel: NO thread, pure string styling. deps: tty-color. v0.8.0 2020.
- tty-cursor: NO thread, emits escape codes. v0.7.1. no deps.
- tty-screen: NO thread, size detection. v0.8.2 2023-12-17. no deps.
- tty-box, tty-table, tty-link, strings, tty-color: NO threads.

THREADS SUMMARY:
- USE THREADS: tty-spinner (auto_spin), whirly, cli-ui.
- NO THREADS (caller-driven / synchronous): pastel, tty-color, tty-cursor, tty-screen, tty-box, tty-table, tty-link, strings, tty-progressbar.
- UNKNOWN: paint, rainbow, colorize, ruby-progressbar, tty-prompt.

TTY ECOSYSTEM: maintainer Piotr Murach (sole). Meta-gem repo stale (last commit 2021-04-30, not archived). Individual gems sporadic maintenance 2024. Low-activity maintenance, not dead. No "looking for maintainers"/archival announcement found.

LICENSE WATCH: colorize = GPL-2.0 (copyleft!); progress_bar = WTFPL; everything else MIT.

CRUX: No thread-free *animated* spinner exists among verified gems. But primitives (tty-cursor + pastel + tty-screen) and tty-progressbar (caller-driven, no thread) are fiber-friendly building blocks. tty-spinner's single-tick `spin` is callable manually.
