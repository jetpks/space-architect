The `write` tool isn't available in this harness — I'll output the findings directly so you can save them. The findings document is below; I've kept it to the same shape I would have written to `01b-async-daemon-structure.findings.md`.

---

# Findings — Concurrency & Daemon Structure under `socketry/async` (Ruby 4.0.5 / macOS)

**Scope:** concurrency primitives, long-lived reactor entrypoint, periodic scheduling, graceful shutdown. **Out of scope:** subprocess execution (covered by a separate lane).

All sources verified at HEAD on **2026-06-12** from clones of `socketry/async`, `socketry/async-container`, `socketry/async-service` and from `rubygems.org`. Quoted source paths given in-line.

---

## 0. Exact gem versions in play (verified 2026-06-12)

| Gem | Version | Source |
| --- | --- | --- |
| `async` | **`2.39.0`** (lib/async/version.rb) | `socketry/async` repo, MIT, © 2017–2026 Samuel Williams |
| `async-container` | **`0.35.1`** (lib/async/container/version.rb) | `socketry/async-container` repo |
| `async-service` | **`0.24.1`** (readme.md) | `socketry/async-service` repo |
| `async-cron` | `0.1.0`, published **2024-06-08**, owner ioquatix (Samuel Williams), 2 stars, MIT, 879 downloads | https://rubygems.org/gems/async-cron |
| `async-background` | `0.6.1`, published **2026-04-08**, 3rd-party `roman-haidarov`, 1 star, 21.5 KB, "production-grade lightweight scheduler built on top of Async … designed for Falcon but works with any Async-based application" | https://rubygems.org/gems/async-background |

Confidence: **high** for all (primary source). `async-cron` is a one-commit stub two years old — treat as **experimental/abandoned**. `async-background` is a one-person gem with one star.

---

## 1. Concurrency control — idiomatic fan-out-with-bound

### 1a. There is no `Async::WaitGroup`

The prompt listed `Async::Barrier`, `Async::Semaphore`, `Async::WaitGroup`. **Only the first two exist** in `socketry/async`. There is a class named `Async::Waiter`, but its own source marks it deprecated:

> "`Async::Waiter` is deprecated, use `Async::Barrier` instead." — `lib/async/waiter.rb:11`

So the design discussion reduces to **Barrier vs Semaphore**.

### 1b. The two primitives

- **`Async::Barrier`** (v1+; `lib/async/barrier.rb`): "a general purpose synchronisation primitive, which allows one task to wait for a number of other tasks to complete." `barrier.async { ... }` + `barrier.wait`. In v2.39.0 `wait` now returns the number of tasks waited for (or `nil` if none).
- **`Async::Semaphore`** (v1+; `lib/async/semaphore.rb`): count-limited gate. `Semaphore.new(K)` + `semaphore.async { ... }` runs the block once a permit is available, auto-released in `ensure`. `limit=` lets you change the bound at runtime.

### 1c. The canonical "fan out M, run at most K" pattern

**Barrier (root) + Semaphore (child of barrier)** — verbatim from `guides/best-practices/readme.md`:

```ruby
Barrier(parent: nil) do |barrier|                  # parent:nil disables Async::Idler load-management
  semaphore = Async::Semaphore.new(4, parent: barrier)

  items.each do |item|
    semaphore.async do
      process(item)
    end
  end
end
# On block exit the barrier is drained and any remaining tasks are cancelled.
```

Two things this idiom gets right that hand-rolled code usually gets wrong:

1. **The semaphore is a child of the barrier, not the other way around.** So on `barrier.cancel` / block-exit, in-flight semaphored tasks are also cancelled.
2. **`parent: nil` on the Barrier disables the default `Async::Idler`**, which is unnecessary load-shedding because the semaphore already bounds concurrency.

The same pattern is also shown in `context/tasks.md` "Combining a Barrier with a Semaphore" with manual `begin/ensure`. Both forms are official, current, and equivalent. Pick the form (block helper vs explicit) based on taste.

> Confidence: **high** (primary source — official guide).

### 1d. `Kernel::Barrier` block helper (v2.34+)

`async` v2.34.0 release notes: "creates an `Async::Barrier`, yields it to a block, waits for completion (using `Sync` to run a reactor if needed), and ensures remaining tasks are stopped on exit." Sugar form of 1c. Useful if you don't otherwise have a reactor running; for a long-lived daemon you do, so the explicit form is the better fit.

> Confidence: **high**.

---

## 2. Long-lived reactor / daemon entrypoint

### 2a. The two top-level helpers

- **`Async do |task| ... end`** — creates a reactor + root task. Both end when the block returns.
- **`Sync do |task| ... end`** (`lib/kernel/sync.rb`) — *preferred at the top level* if you don't need the block itself to be a concurrent task. From `guides/best-practices/readme.md`:

  > "`Sync{...}` is semantically equivalent to `Async{...}.wait`, but it is more efficient. It is the preferred way to run code in an event loop at the top level of your program or to ensure some code runs in an event loop without creating a new task."

**For a daemon's outermost frame, `Sync` is the recommended choice.** It still gives you a `task`; you call `task.async { ... }` to spawn concurrent children off the implicit root task.

### 2b. How a never-returning reactor is kept alive

From `context/tasks.md` "Reactor Lifecycle":

> "Generally, the reactor's event loop will not exit until all tasks complete. … However, there is one exception to this rule: tasks flagged as being `transient`."

So the canonical pattern is: keep at least one **non-transient** task alive. In a daemon that task is your supervisor (see 2c). The supervisor's lifetime is the daemon's lifetime.

### 2c. Supervising a crashed child — the most important nuance

Verbatim from `context/tasks.md` "Exception Handling":

> "Async::Task captures and logs exceptions. All unhandled exceptions will cause the enclosing task to enter the `:failed` state. Non-`StandardError` exceptions are re-raised immediately and will cause the reactor to exit."

Translated:

- A child that raises an unhandled **`StandardError` becomes `:failed`**. The **parent task is not killed and the reactor is not exited**. You only see the error if you call `child.wait` (re-raises) or read `child.status`.
- A child that raises a **non-`StandardError`** (e.g. `Async::Cancel`) propagates upward — this is the mechanism by which `Task#cancel` tears down the tree.

**Implication: `socketry/async` core does not ship an auto-restart-on-crash supervisor for child tasks.** To re-spawn a crashed child you write the loop yourself:

```ruby
supervisor = Sync do |task|
  loop do
    child = task.async { do_work }   # may raise StandardError
    begin
      child.wait                      # re-raises here; supervisor survives
    rescue => error
      log(error); sleep(backoff)
    end
  end
end
```

The non-StandardError case is what gives you the shutdown path — see §4.

### 2d. `async-container` *is* the maintained process supervisor

If process-level auto-restart is what you want, the maintained solution is the sister gem **`async-container`** (v0.35.1). From its README:

> "Supports multi-process, multi-thread and hybrid containers. … Automatic restart of failed processes."

The supervisor semantics live in `Async::Container::Generic#spawn` (`lib/async/container/generic.rb`):

```ruby
fiber do
  until @stopping
    child = self.start(name, &block)            # fork+exec a child
    status = @group.wait_for(child)             # block until exit
    if restart && !@stopping
      @statistics.restart!                      # loop -> respawn
    else
      break
    end
  end
end.resume
```

The single most important gate is **`restart && !@stopping`** — set `@stopping = true` (via `interrupt` or `stop`) and the loop exits cleanly instead of respawning. This is what makes a SIGTERM cause the process tree to drain rather than spin in a restart loop.

`Async::Container::Controller` (`lib/async/container/controller.rb`) adds the user-facing API: traps `SIGHUP`/`SIGINT`/`SIGTERM`, calls `interrupt` on first signal (drain) and `stop(false)` on second (force-kill), hot-reload via `SIGHUP`. The **v0.35.1 release notes explicitly state: "Hybrid container now stops on interrupt instead of restarting indefinitely."** That is exactly the bug-class a hand-rolled `restart: true` supervisor without a stopping-flag would hit.

> Confidence: **high** (primary source — both repos, current HEAD).

### 2e. So: which entrypoint for *our* daemon?

| Layer | What you write | What you get | What you must add |
| --- | --- | --- | --- |
| `async` only | `Sync { supervisor_loop }` | Reactor, all primitives in §1, `Async::Loop` for periodic work, `Task#cancel` for shutdown. | The whole `Signal.trap` block, the per-child restart loop, the in-flight cancel coordination. |
| `async` + `async-container` | Subclass `Async::Container::Controller`; `setup(container)` does `container.run(count: 1, restart: true) { \|instance\| Async { ... } }` | Trapped signals, multi-process restart, systemd `Type=notify` integration, health-check / startup-timeout policies. | Application logic. Periodic sweep is just a child task; cancellation is automatic on SIGTERM because `container.interrupt` sets `@stopping = true`. |

These are **not** equivalent. `async-container` is the only one that gets the "single SIGINT causes clean drain, not infinite restart loop" right out of the box, and the `restart && !@stopping` pattern in its source is the exact bit of logic a hand-rolled supervisor would otherwise have to re-derive (and get wrong, per its own release notes).

---

## 3. Periodic scheduling

### 3a. There is no `reactor.every`, no `Async::Clock.every`, no `async-clock` gem

- `Async::Clock` (v1+; `lib/async/clock.rb`) is **just a monotonic clock wrapper**: `Clock.now`, `Clock.measure`, `Clock.start`, instance `#start!`/`#stop!`/`#total`. Not a scheduler.
- No `async-clock` gem exists (web search returns no published gem by that name).
- No `reactor.every` method exists. Confirmed by `grep -E 'SIGINT|SIGTERM|Signal|trap' lib/async/reactor.rb` returning **no matches** in core `async`.

### 3b. The built-in: `Async::Loop` (v2.37+)

`async` v2.37.0 release notes: "Introduce `Async::Loop` for robust, time-aligned loops." Source: `lib/async/loop.rb`:

```ruby
# End-to-start semantics; total cycle = interval + execution_time
def self.periodic(interval: 60, &block)
  while true
    begin
      yield
    rescue => error
      Console.error(self, "Loop error:", error)
    end
    sleep(interval)
  end
end

# Time-aligned (e.g. interval:60 -> :00, :01, :02 ... regardless of start time)
def self.quantized(interval: 60, &block)
  while true
    wait = interval - (Time.now.to_f % interval)
    sleep(wait) if wait.positive?
    begin
      yield
    rescue => error
      Console.error(self, "Loop error:", error)
    end
  end
end
```

Both swallow block exceptions and log them, so a periodic sweep that crashes does not take down the loop. **This is the right idiom for a 6-hourly sync sweep in a single-process daemon.**

> Confidence: **high** (primary source).

### 3c. The pre-`Async::Loop` idioms (still in the docs)

The *Tasks* guide "Periodic Timers" shows two manual forms that pre-date `Async::Loop`:

```ruby
# End-to-start (cheap; drift accumulates if work > interval)
Async do |task|
  loop do
    puts Time.now
    # ... process job ...
    sleep(period)
  end
end

# Start-to-start with monotonic clock
Async do |task|
  run_next = Async::Clock.now
  loop do
    run_next += period
    puts Time.now
    # ... process job ...
    if (remaining = run_next - Async::Clock.now) > 0
      sleep(remaining)
    end
  end
end
```

Reaching for these only makes sense if you need custom drift behaviour that `Async::Loop.periodic`/`quantized` don't give you. For "do X every 6 hours" with normal tolerances, `Async::Loop.periodic(interval: 6 * 60 * 60)` is the idiomatic answer.

### 3d. Dedicated scheduler gems — current state

- **`async-cron` 0.1.0** — Samuel Williams, MIT, 2024-06-08. Repo is essentially a README with "Development Status" and a "Usage" stub. 2 stars, 879 downloads, one release two years ago. **Treat as abandoned / proof-of-concept.**
- **`async-background` 0.6.1** — third-party (`roman-haidarov`), 2026-04-08, 1 star. README claims cron + interval + delayed jobs on a single event loop, min-heap timer, skip-overlapping, deterministic sharding, SQLite-backed queue. Bus-factor of one. **Adopt only after pinning + thorough testing.**

> Confidence: **medium** for `async-background`'s claimed features (no source review done — we should not let a third-party scheduler become load-bearing in the design without its own evaluation pass).

### 3e. Composing periodic + fan-out

Both can live as siblings under the root task; `task.wait_all` (added in v2.36.0, recursive) keeps the reactor alive:

```ruby
Sync do |task|
  fan_out = task.async do
    Barrier(parent: nil) do |barrier|
      sem = Async::Semaphore.new(K, parent: barrier)
      loop do
        sem.async { run_subprocess_job(...) }   # see other lane
      end
    end
  end

  sweep = task.async do
    Async::Loop.periodic(interval: 6 * 60 * 60) { do_sync_sweep }
  end

  [fan_out, sweep].each(&:wait)  # reactor stays up while both are alive
end
```

On `task.cancel` (from the §4 signal trap), both children receive `Async::Cancel` at their next yield; the in-flight subprocess jobs drain or are cancelled; the loop's next `sleep` returns early.

---

## 4. Graceful shutdown

### 4a. The canonical `Signal.trap` pattern (from `async-container`)

Most load-bearing code in this lane. Verbatim from `lib/async/container/controller.rb`, `Async::Container::Controller#with_signal_handlers`:

```ruby
private def with_signal_handlers
  interrupt_action = Signal.trap(:INT) do
    # We use `Thread.current.raise(...)` so that exceptions are filtered
    # through `Thread.handle_interrupt` correctly.
    ::Thread.current.raise(Interrupt)
  end

  # SIGTERM behaves the same as SIGINT by default.
  terminate_action = Signal.trap(:TERM) do
    ::Thread.current.raise(Interrupt)  # Same as SIGINT
  end

  hangup_action = Signal.trap(:HUP) do
    ::Thread.current.raise(Restart)
  end

  ::Thread.handle_interrupt(SignalException => :never) do
    yield
  end
ensure
  # Restore the interrupt handler:
  Signal.trap(:INT, interrupt_action)
  Signal.trap(:TERM, terminate_action)
  Signal.trap(:HUP, hangup_action)
end
```

The companion `run` (same file) catches the raised `Interrupt`/`Terminate` and translates them into `stop`/`stop(false)`:

```ruby
def run
  with_signal_handlers do
    self.start
    while @container&.running?
      begin
        @container.wait
      rescue SignalException => exception
        if handler = @signals[exception.signo]
          handler.call
        else
          raise
        end
      end
    end
  end
rescue Interrupt
  self.stop
rescue Terminate
  self.stop(false)
ensure
  self.stop(false)
end
```

Key things this code does — and that a hand-rolled signal handler typically gets wrong:

1. **`Thread.current.raise(Interrupt)`** rather than mutating shared state. Only way to interact with code currently blocked on `sleep`/`wait`/IO, because those all use `Thread.handle_interrupt` under the hood.
2. **`Thread.handle_interrupt(SignalException => :never) { yield }`** to ensure the traps themselves are not unmasked by accident inside the controlled region.
3. **`ensure` block restores original traps** so a second run of the daemon process in test/dev doesn't leak handlers.
4. **SIGTERM and SIGINT both raise `Interrupt`** for graceful, with a separate `Terminate` raised elsewhere for hard-stop.

> Confidence: **high** (primary source — current HEAD of maintained controller).

### 4b. The "in-flight git operation finishes or cancels" requirement

When the root task receives `Async::Cancel` (via the `Task#cancel` chain that follows `Thread.current.raise(Interrupt)`), cancellation propagates to children on their next yield. For a subprocess child task:

- A child currently blocked on `wait_thr.value` or `read` is interrupted at the next scheduler check; the IO handle is closed by your `ensure` block.
- The cooperative piece is `Process.kill(:TERM, pid)` (covered by the subprocess lane) — the child should trap TERM, finish flushing, then exit.
- The non-blocking alternative is `task.with_timeout(grace_period) { ... }` to bound the drain.

`Task#cancel` is the modern name; renamed from `Task#stop` in v2.38.0. `Task#stop` is still an alias in 2.39.0. **Prefer `cancel` going forward** — `releases.md` v2.38.0:

> "Rename `Task#stop` to `Task#cancel` for better clarity and consistency with common concurrency terminology. The old `stop` method is still available as an alias for backward compatibility, but it is recommended to use `cancel` going forward."

`Async::Cancel` is the exception class (`lib/async/cancel.rb`); it inherits from `Exception` (not `StandardError`) precisely so a plain `rescue` will not swallow it and so it can re-raise across `Fiber.yield` boundaries.

> Confidence: **high**.

### 4c. If we don't use `async-container`

The signal-trap block in 4a is ~20 lines of correct code that we can copy verbatim. **There is no `Async` helper that does it for you** — confirmed: `grep` of `lib/async/reactor.rb` for `Signal` / `trap` returns no matches. Signal handling is intentionally pushed to `async-container`.

If we go the pure-`async` route, wire the supervisor like:

```ruby
require "async"
require "async/cancel"

Sync do |task|
  Signal.trap(:INT)  { ::Thread.current.raise(Interrupt) }
  Signal.trap(:TERM) { ::Thread.current.raise(Interrupt) }

  supervisor = task.async do
    loop do
      child = task.async { run_subprocess_job(...) }  # see other lane
      begin
        child.wait
      rescue Async::Cancel
        break   # propagate cancel upward
      rescue => error
        log(error); sleep(backoff)
      end
    end
  end

  # ... periodic sweep as a sibling task ...

  task.wait_all     # block until all children (incl. supervisor) finish
end
```

> `task.wait_all` (v2.36.0) recurses through non-transient children — confirmed in `lib/async/task.rb#wait_all`.

---

## 5. Direct answers to the four sub-questions

1. **"Fan out M, run at most K, collect all" idiom** — `Async::Barrier` + `Async::Semaphore`, semaphore constructed as a child of the barrier (`Async::Semaphore.new(K, parent: barrier)`). `Kernel::Barrier` is sugar. **No `Async::WaitGroup`** in this gem; `Async::Waiter` is explicitly deprecated in favour of `Async::Barrier`. Current `async`: **2.39.0** (lib/async/version.rb, 2026).

2. **Long-lived reactor / daemon entrypoint** — `Sync` is the preferred top-level (more efficient than `Async` at the root). Reactor stays alive while at least one non-transient child is alive. For a multi-process daemon with auto-restart, the maintained pattern is `Async::Container::Controller` (v0.35.1) — signal-trapped supervisor, `restart: true` policy (gated on `@stopping`), systemd `Type=notify` integration. In pure `async` you must write a `loop { child = task.async {…}; child.wait rescue; sleep(backoff) }` supervisor yourself; child `StandardError` failures do not kill the parent or the reactor.

3. **Periodic scheduling** — `Async::Loop.periodic(interval:)` for end-to-start, `Async::Loop.quantized(interval:)` for time-aligned, both in core `async` since v2.37.0. They log + swallow block exceptions. No `reactor.every`, no `Async::Clock.every`, no `async-clock` gem. Dedicated scheduler gems: `async-cron` 0.1.0 (2024-06-08, by ioquatix, **abandoned**), `async-background` 0.6.1 (2026-04-08, third-party, **single maintainer, untested here**).

4. **Graceful shutdown** — `async` core has no built-in signal handling (confirmed: no `Signal.trap` in `lib/async/reactor.rb`). The canonical pattern is `Async::Container::Controller#with_signal_handlers` (see §4a): trap `INT`/`TERM` → `Thread.current.raise(Interrupt)`, trap `HUP` → `Thread.current.raise(Restart)`, wrap the run in `Thread.handle_interrupt(SignalException => :never) { yield }`, restore original traps in `ensure`. In-flight tasks receive `Async::Cancel` (renamed from `Async::Stop`; alias still works) at their next yield; modern API is `Task#cancel` (formerly `Task#stop`, alias still in 2.39.0).

---

## 6. Disagreements / things the docs don't settle

- **"Periodic timer in core vs dedicated gem"** — docs treat `Async::Loop` (v2.37) as the answer. Third-party ecosystem (`async-cron`, `async-background`) disagrees by existing, but neither has meaningful adoption. Recorded; not resolved.
- **"Pure `async` vs `async-container`"** — both maintained by the same author. The *Tasks* guide (`socketry/async`) doesn't mention `async-container`; the *Scheduler* guide mentions it once ("you'd typically have one reactor per thread or process" — linking to `async-container`). The `async-service` README is unambiguous: it is the recommended shape for production services. This lane does not resolve the choice; the architect must.
- **`reactor.stop` vs `Task#cancel`** — `Async::Stop` is now an alias for `Async::Cancel` (lib/async/stop.rb is literally `Stop = Cancel`). `Scheduler#cancel` exists too. Three names for the same concept depending on which object you have. Pick one and stick to it.

---

## 7. NOT FOUND

- `Async::WaitGroup` — does not exist.
- `Async::Clock#every`, `reactor.every` — do not exist.
- `async-clock` gem (as a periodic scheduler) — does not exist.
- A built-in child-task restart supervisor in `socketry/async` core — does not exist. Must be hand-written or use `async-container`.
- A built-in `Signal.trap` helper in `socketry/async` core — does not exist. Must be hand-written or use `async-container`.

---

## 8. The 2–3 findings most likely to change our design

1. **`Async::Container` is the load-bearing piece for graceful shutdown, not `Async`.** The core gem does not trap signals, does not restart crashed children, and has no equivalent of the `restart && !@stopping` gate that the container's own v0.35.1 release notes call out as the bug they just fixed ("Hybrid container now stops on interrupt instead of restarting indefinitely"). If we hand-roll a `Sync { supervisor_loop }` we are re-implementing — and probably re-mis-implementing — a 20-line pattern that the maintainer-shipped `Controller#with_signal_handlers` already gets right. **The cost of not using it is one release notes' worth of "we got this wrong and fixed it" history.**

2. **The "Barrier-as-root, Semaphore-as-child" idiom in §1c is the official answer for "fan out M, run at most K".** It is shown verbatim in two official guides (Tasks and Best Practices). It also gives us the `ensure barrier.cancel` drain on shutdown for free, which the per-task-only version of the same problem does not. **If our concurrency primitive is anything other than a barrier+semaphore pair we are either fighting the framework or re-deriving it.**

3. **`Async::Loop.periodic(interval: 21_600)` is the right answer for the 6-hourly sync sweep, *not* a third-party scheduler.** `async-cron` is a two-year-old one-commit stub; `async-background` is a single-maintainer gem with one star. The built-in `Async::Loop` is new in v2.37 (2026), it swallows + logs loop errors so a crashed sweep does not take down the loop, and it coexists cleanly with the barrier+semaphore fan-out as a sibling task under the same root. **Adopting `async-background` here would be premature; we can add it later behind a feature flag if its SQLite-backed delayed-job queue becomes a real requirement.**

---

**Search budget used:** 3 successful web searches + 1 (partial) search response + 3 fetch_content calls (async repo, async-container repo, async-service repo) + ~20 file reads. Hit Exa rate limits on most second-batch searches, but recovered all needed primary-source data from the local clones of the three repos and the rubygems.org release pages.
