ultrathink

Execute the architect spec below. Operating rules:

PHASE 0 — Before any code: reply with your plan and EVERY disagreement you have
with this spec, with reasons, citing real files. Silent compliance is a failure.
Silent scope additions are a failure. Verify the named APIs against the live
dependencies. PHASE 0 ALSO INCLUDES THE EMPIRICAL LIVENESS CHECK (GC3): once you
have the compact renderer working, run a REAL `bin/repo-tender sync` on ≥50 real
repos (or a faithful real-git repro) and record raw observations — does the live
counter advance smoothly DURING the run, and is output bounded? Report it.

PHASE 1 — The reporter event interface (lib/repo_tender/ui/reporter.rb) and the
engine seam are ALREADY FROZEN. You are rewriting ONE implementation
(InteractiveReporter), not changing the contract. The files under docs/gates/ are
read-only at all times — editing them fails the slice.

PHASE 2 — Build YOUR LANE ONLY: exactly the files in BOUNDARIES, on the
`slice/ui-interactive` branch (you are already on it). No placeholders — full
implementations. Verify by running the gate commands; record verbatim output. Do
NOT commit and do NOT run any git write command — the architect commits/merges
after verification and verifies you made no commits. Do NOT touch the subprocess
layer (shell.rb / scm/*): if the live counter will not tick during a real sync
WITHOUT subprocess-layer changes, that is the GC3 escalation — record it as a
BLOCKED finding with evidence and STOP that thread; do not hack the subprocess
layer. Give long commands a timeout. Any scratch/spike script goes under
.architect/ or /tmp and is NOT committed. When done, write your lane report to
docs/lanes/ui-interactive-compact-01.md with RAW results only — tables, numbers,
command output, the PHASE-0 real-sync observation — no interpretation. End with
exactly one STATUS line: COMPLETE | COMPLETE_WITH_CONCERNS (list) | BLOCKED
(exact blocker + what you tried). Persist until the lane is fully handled.

=== OBJECTIVE (and why) ===

CLI-UX Slice B corrective. The current `lib/repo_tender/ui/interactive_reporter.rb`
draws ONE LINE PER REPO and redraws ALL of them in place every cadence via
`TTY::Cursor.up(n)` (lines 88-97). On the operator's real run (~400+ repos) this
(a) floods scrollback — once n exceeds the terminal height, `\e[<n>A` clamps at
the top of the viewport so each repaint re-emits all n lines and the terminal
scrolls endlessly; and (b) appears to "sit then dump" because that broken redraw
is illegible during the run. M1 (the human real-TTY smoke) caught both.

REPLACE the per-repo-line model with a COMPACT display (human ruling 2026-06-14):

- **One live status line**, rewritten IN PLACE on a SINGLE line (`\r` + clear-to-
  EOL `\e[K`; NEVER a growing multi-line `cursor.up(n)` block): a spinner frame +
  `X/total` (X = repos finished) + running tallies — at minimum clean / non-clean /
  failed counts. Example: `⠙ synced 247/422   ✓ 239   ⚠ 6   ✗ 2`.
- **Persistent scrollback lines for NON-CLEAN repos ONLY**, emitted once as each
  occurs, ABOVE the live line: `⚠ <ref>  <status>` for dirty/diverged/wrong_branch/
  detached; `✗ <ref>  <error>` for failed/error. **A CLEAN repo gets NO persistent
  line** — it only bumps the tally. (This is the operator's explicit choice: they
  want to SEE every repo that isn't clean, and not drown in the clean ones.)
- **One final summary line** at `detach`.

Mechanically, to log a persistent line above an in-place status line: clear the
status line (`\r\e[K`), write the `⚠`/`✗` line + `\n` (it scrolls into history),
then redraw the status line. The render fiber is the SOLE writer (single-writer
invariant) and owns this; worker fibers only mutate tally/event state via the
reporter methods. Each render tick: flush any newly-finished non-clean repos as
persistent lines, then rewrite the single status line. This keeps total output
bounded to (#non-clean) + a constant — never scales with the clean count, never
exceeds the screen.

Why it matters: this is the epic's headline feature made usable at real scale
(hundreds of repos). The status status set comes from the engine: terminal
`repo_finished(ref, status)` statuses are clean | dirty | diverged | wrong_branch |
detached | error; `repo_failed(ref, error)` is the failure path. Treat everything
except "clean" as non-clean (gets a persistent line).

LIVENESS (GC3) — the harder half: even with a single-line counter, if the render
fiber is starved by the git workers (reactor not yielding during `Open3.capture3`
subprocess waits), the counter won't tick until the end. The compact rewrite is
likely sufficient (the old flood was the main problem), but you MUST PROVE it:
the deterministic test (SlowSCM, intermediate X values) + the PHASE-0 real-sync.
If real liveness fails WITHOUT subprocess changes → GC3 escalation (record + stop;
do not touch shell.rb/scm).

=== OUTPUT FORMAT ===

docs/lanes/ui-interactive-compact-01.md, RAW only:
1. PHASE 0: plan, disagreements (numbered, cite real files), and the EMPIRICAL
   real-sync observation (GC3) — command run, raw observation (counter ticks live?
   output bounded?), and the liveness verdict.
2. Gate→test mapping: GC1, GC2, GC3 (deterministic part), and the carried G0/G1/G2/
   G4/G5/G7 → test file + test name(s).
3. Verbatim: `bundle exec rake test` tail (runs/assertions/failures/errors/skips),
   `bundle exec standardrb`, `git diff --name-only <FREEZE2>..`,
   `git diff --stat <FREEZE2>.. -- lib/repo_tender/sync/engine.rb` (empty),
   `git diff <FREEZE2>.. -- repo-tender.gemspec Gemfile.lock` (empty — no new gems),
   `ruby -W:no-experimental -Ilib bin/repo-tender --help`.
4. The exact STATUS line.

=== TOOL GUIDANCE (verification; verify-against-reality) ===

  bundle exec rake test                                          # 309 baseline + updated; 0 fail/err/skip
  bundle exec ruby -Itest test/repo_tender/ui/interactive_reporter_test.rb
  bundle exec standardrb            # 0   (run --fix before reporting done)
  ruby -W:no-experimental -Ilib bin/repo-tender --help           # exit 0, 5 groups

Verify before coding:
- The CURRENT interactive_reporter.rb (you are rewriting it) + its test.
- The engine event order: attach → run_started → per repo {repo_started,
  repo_phase*, (repo_finished|repo_failed)} → run_finished → detach
  (lib/repo_tender/sync/engine.rb, DO NOT EDIT — read only).
- The terminal statuses the engine emits to repo_finished: clean, dirty, diverged,
  wrong_branch, detached, error (grep engine.rb / repo_plan.rb for the exact
  strings — use the real ones, do not invent).
- The SlowSCM + real-temp-git harness in test/repo_tender/sync/engine_test.rb
  (RecordingReporter ~line 922; SlowSCM ~line 114; make_config(concurrency:)).
  Reuse for GC3's deterministic intermediate-progress test and GC1/GC2 mixed runs.
- tty-cursor API for clear-line (`TTY::Cursor.clear_line` / `clear_char` / the
  `\e[K` sequence) and that a SINGLE-line in-place rewrite needs only `\r` + clear,
  not `cursor.up`. Read the gem source if unsure.
- That `Kernel#sleep` in the render fiber yields the reactor; the render fiber is a
  child via `task.async`; child `ensure` runs on cancel (already proven last lane —
  re-confirm it still holds after your rewrite).

=== BOUNDARIES (may touch / must not touch) ===

MAY TOUCH:
- lib/repo_tender/ui/interactive_reporter.rb            (rewrite the render model)
- test/repo_tender/ui/interactive_reporter_test.rb      (rewrite/extend for GC1–GC3 + carried gates)
- lib/repo_tender/ui/spinner.rb + test/repo_tender/ui/spinner_test.rb  (only if needed)
- lib/repo_tender/cli/sync.rb  (ONLY if the InteractiveReporter constructor signature
  changes — e.g. injecting term width/cadence; keep --repo/exit codes/summary intact)
- test/repo_tender/cli/sync_test.rb  (additions only, if the constructor changed)
- docs/lanes/ui-interactive-compact-01.md  (your report)

MUST NOT TOUCH:
- lib/repo_tender/sync/engine.rb        (event seam frozen — any diff fails)
- lib/repo_tender/shell.rb, lib/repo_tender/scm/*   (the subprocess layer — GC3
  escalation: if liveness needs these, RECORD + STOP, do not edit)
- ui/{mode,reporter,plain_reporter,json_reporter}.rb, cli.rb, cli/options.rb
- cli/{repo,org,status,config,daemon}.rb, config/*, forge/*, launchd/*, state/*
- sync/repo_plan.rb, paths.rb, log_rotator.rb
- repo-tender.gemspec, Gemfile, Gemfile.lock  (3 gems already correct — NO new gems)
- test_helper.rb, all other test files, anything under docs/gates/

=== DISAGREEMENT RULINGS (from last session) ===

None new. The dep set (pastel, tty-cursor, tty-screen — tty-progressbar was
dropped as unused) is settled; do not re-add gems. Raise fresh PHASE-0
disagreements citing real files.

=== ACCEPTANCE GATES (frozen at docs/gates/ui-interactive-compact.md — read-only) ===

GC1 — Bounded output: clean repos produce ZERO persistent lines; each non-clean +
      failed produces exactly one; persistent-line count is INDEPENDENT of the
      clean count (50-clean run == 5-clean run, same persistent count); the live
      region is a SINGLE line (no repo-count-scaling cursor.up).
GC2 — Live counter (spinner + X/total + clean/non-clean/failed tallies matching the
      engine summary); persistent lines == exactly the non-clean+failed refs with
      correct status/error text; final summary at detach.
GC3 — Counter advances DURING the run (deterministic: SlowSCM, intermediate X
      values before detach) + PHASE-0 real ≥50-repo sync observation + M1 human.
      Liveness-needs-subprocess-layer → escalate, don't fix.
Carried (must stay green): G0 (suite/lint, no new gems, --help, engine.rb
      unchanged), G1 (no Thread), G2 (fiber child + detach), G4 (^C cursor-restore
      + exit-130), G5 (color gated + selection), G7 (file scope, no commits).

Read the full thresholds at docs/gates/ui-interactive-compact.md. <FREEZE2> is the
corrective freeze commit recorded by the architect at dispatch.
