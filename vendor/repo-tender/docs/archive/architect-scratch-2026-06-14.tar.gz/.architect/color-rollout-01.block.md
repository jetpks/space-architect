Think harder. Execute the architect spec below. Operating rules:

PHASE 0 — Before any code: reply with your plan and EVERY disagreement you have
with this spec, with reasons, citing real files in this repo. Silent compliance
is a failure. Silent scope additions are a failure. If you have no disagreements,
state what you checked before concluding the spec is sound. Verify the named
APIs/formats/versions against the live dependencies before planning around them
(especially: read `lib/repo_tender/cli/sync.rb` to copy the EXACT `UI::Mode`
wiring pattern; read `lib/repo_tender/ui/mode.rb` for the real readers; confirm
`tty-screen` has zero refs in lib/test/bin before dropping it; confirm how the
existing in-process command tests capture stdout and how to drive a `:pretty`/TTY
path through `UI::Mode.resolve` without modifying `mode.rb`).

PHASE 1 — There are no NEW shared contracts to freeze (Mode + reporters are
frozen from Slices A/B). The files under docs/gates/ are read-only at all times —
editing them fails the slice regardless of results.

PHASE 2 — Build YOUR LANE ONLY: exactly the files listed in BOUNDARIES. No
placeholder implementations — search the codebase before implementing; full
implementations only. Verify your work by running the lane's gate commands and
record the verbatim output. Do NOT commit and do NOT run any git write command
(commit/add/branch/reset/checkout) — the architect commits and merges after
verification, and verifies you made no commits. Do NOT delete lock files or
escalate privileges if a command fails; record the exact error and continue.
Give every potentially long command an explicit timeout. When done, write your
lane report to docs/lanes/color-rollout-01.md with RAW results only — tables,
numbers, command output — no interpretation. Every status claim must be backed by
a command result from this run. Keep it compact. End it with exactly one status
line: STATUS: COMPLETE | COMPLETE_WITH_CONCERNS (list them) | BLOCKED (exact
blocker + what you tried). Verdicts belong to the architect and the human.
Persist until your lane is fully handled end-to-end.

=== OBJECTIVE (and why) ===
Final CLI-UX slice ("Slice C", PRD docs/prd/cli-ux.md §5). Slices A (Mode +
reporter seam + Plain/Json) and B (sync's fiber-driven InteractiveReporter) are
merged. This slice rolls the SAME `UI::Mode` + `pastel` color into the remaining
NON-sync commands so that every command shows colorful output on an interactive
terminal and stays byte-clean (ANSI-free) when piped / `--plain` / `--no-color` /
`NO_COLOR` / non-TTY / under launchd. This completes the epic's Definition of
Done (PRD §7).

Two concrete deliverables:
1. COLOR ROLLOUT across `repo`, `org`, `status`, `config`, `daemon` commands —
   gate color on `mode.color`, resolved exactly like `cli/sync.rb` does
   (`UI::Mode.resolve(flags:, env: CLI.env, out: out)` → `Pastel.new(enabled:
   mode.color)`). Confirmations colorized in `:pretty`, byte-identical in
   `:plain`. `status` table: STATUS cell colorized in `:pretty`, byte-identical
   in `:plain` (stripping SGR must reproduce the plain bytes exactly).
2. DROP the dead `tty-screen` gemspec dependency (zero code refs since the
   compact rewrite) → 2 tty/color gems remain (pastel, tty-cursor). This is the
   ONLY permitted gemspec/Gemfile.lock change.

NO SPINNER / NO ANIMATION. The PRD's quick-op spinner is dropped (architect +
human ruling): `org add`/`org list` are local config ops (no `gh`), and
`sync --repo` already animates via Slice B. Adding animation here is out of scope
and fails the slice.

=== OUTPUT FORMAT (docs/lanes/color-rollout-01.md) ===
- PHASE-0 plan + every disagreement (cite real files).
- The key design decisions you made: shared color helper vs per-command Pastel;
  which flag surface each non-sync command exposes (full GlobalOptions vs a
  lighter color-only set); whether you styled stderr errors (and if so, that it
  gates on `err.tty?`). Record what + why (raw, not salesy).
- gate→test mapping table (RC0–RC6 → test file + test name).
- Verbatim: `bundle install` (tail), `bundle exec rake test` (counts line),
  `bundle exec standardrb`, `ruby -W:no-experimental -Ilib bin/repo-tender --help`,
  `git diff --name-only HEAD` + `git status --short` (you do NOT commit, so your
  changes are the working-tree diff vs HEAD, which IS the freeze commit
  `c0701ee`), and proof the MUST-NOT-TOUCH files are byte-unchanged
  (`git diff --stat HEAD -- <those paths>` empty).
- For RC2/RC3, paste a short captured `:pretty` line AND its SGR-stripped form
  next to the `:plain` line to show byte-equality.

=== TOOL GUIDANCE (verification; verify-against-reality) ===
- Verification gate (run from repo root): `bundle install` ; `bundle exec rake
  test` ; `bundle exec standardrb`. Single test file: `bundle exec ruby -Itest
  -Ilib test/repo_tender/cli/<name>_test.rb`. Help: `ruby -W:no-experimental
  -Ilib bin/repo-tender --help`.
- COPY THE PATTERN: `lib/repo_tender/cli/sync.rb` already does Mode resolution +
  reporter selection. Reuse its exact `UI::Mode.resolve(flags: {plain:, json:,
  no_color:, quiet:}, env: CLI.env, out: out)` call shape. `mode.color` is the
  single color switch; do NOT re-derive precedence.
- `pastel` is already a dependency. `Pastel.new(enabled: false)` is a passthrough
  (no SGR) — that is how color-off works without branching every call site.
- To test the `:pretty`/color path IN-PROCESS (out is a StringIO, not a TTY):
  drive it through the real `UI::Mode.resolve` using a `StringIO`-like out double
  whose `tty?` returns true, plus `CLICOLOR_FORCE` in the injected `CLI.env` (see
  how the Slice-A Mode tests + sync tests inject `env`/`out`). Do NOT modify
  `ui/mode.rb` and do NOT bypass `Mode` by hand-setting a color boolean in the
  command.
- "Has color" assertion: captured output matches `/\e\[[0-9;]*m/`. "No color":
  it matches none. For RC2/RC3 byte-equality:
  `pretty.gsub(/\e\[[0-9;]*m/, "") == plain`.
- Before dropping `tty-screen`: `grep -rn "tty.screen\|TTY::Screen" lib test bin`
  must be empty. Then remove the `spec.add_dependency "tty-screen"` line and run
  `bundle install` so the lock drops it. Confirm `git diff HEAD --
  Gemfile.lock` removes only `tty-screen` (+ orphaned transitives) and changes no
  other gem.

=== BOUNDARIES (may touch / must not touch / out of scope) ===
MAY TOUCH (exactly these):
- lib/repo_tender/cli/repo.rb, org.rb, status.rb, config.rb, daemon.rb
- lib/repo_tender/cli/options.rb  (only if you add/reuse a color flag mixin;
  additive — do not change existing GlobalOptions flags sync depends on)
- lib/repo_tender/ui/palette.rb (+ test/repo_tender/ui/palette_test.rb)  — ONLY
  if you choose a shared helper
- repo-tender.gemspec + Gemfile.lock  — the tty-screen DROP only
- test/repo_tender/cli/{repo,org,status,config,daemon}_test.rb, config_test.rb,
  org_test.rb  (ADDITIONS ONLY — existing test bodies stay byte-identical),
  test/repo_tender/cli/options_test.rb (only if the mixin changed)
- docs/lanes/color-rollout-01.md

MUST NOT TOUCH: lib/repo_tender/ui/mode.rb, ui/reporter.rb, ui/plain_reporter.rb,
ui/json_reporter.rb, ui/interactive_reporter.rb, lib/repo_tender/cli/sync.rb,
cli.rb, sync/engine.rb, sync/repo_plan.rb, forge/*, scm/*, state/*, config/* (the
store), launchd/*, paths.rb, shell.rb, log_rotator.rb, Gemfile, test_helper.rb,
all other existing test files, anything under docs/gates/.

OUT OF SCOPE: any spinner/animation; coloring sync's own output; a new `--json`
schema for the non-sync commands; changing `UI::Mode`.

=== DISAGREEMENT RULINGS (from last session) ===
None pending — this is a fresh slice. Raise yours in PHASE 0.

=== ACCEPTANCE GATES (frozen at docs/gates/color-rollout.md — read-only) ===
RC0 suite green + tty-screen dropped (3→2 gems, no other gem change);
RC1 every targeted command colors in :pretty, none under --no-color/NO_COLOR/
non-TTY/--plain; RC2 status byte-identical in :plain, STATUS cell colored in
:pretty (SGR-strip reproduces plain); RC3 confirmations colored in :pretty,
byte-identical in :plain, stderr errors unchanged; RC4 existing command tests
pass UNMODIFIED (additive only); RC5 Mode resolved via the frozen Slice-A seam,
styling `out`; RC6 file scope + no commits + mode.rb/reporters/engine/sync
byte-unchanged. Full text: docs/gates/color-rollout.md.
