#!/usr/bin/env ruby
# frozen_string_literal: true
#
# SPIKE: test tty-cursor + pastel hand-rolled multi-line renderer
# with async fibers. Under .architect/ — NOT committed.
#
# Run: bundle exec ruby -Ilib .architect/spike_interactive.rb

require "async"
require "async/semaphore"
require "async/barrier"
require "pastel"
require "tty-cursor"
require "tty-screen"

PASTEL = Pastel.new
CURSOR = TTY::Cursor

REPOS = [
  "github.com/alice/repo-alpha",
  "github.com/bob/repo-beta",
  "github.com/carol/repo-gamma",
  "github.com/dave/repo-delta",
]

FRAMES = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"].freeze
PHASES = %w[cloning fast_forwarding switching].freeze

# Shared state (written only by worker fibers, read only by render fiber)
indicators = {}
REPOS.each { |r| indicators[r] = {phase: nil, status: :waiting, final: nil} }
done = false
frame_idx = 0

width = TTY::Screen.width

def format_line(ref, info, frame, pastel, width)
  name = ref.split("/").last(2).join("/")
  name = name[0, 20].ljust(20)

  case info[:status]
  when :waiting
    "  #{pastel.dim("○")} #{name} #{pastel.dim("waiting")}"
  when :started
    "  #{pastel.yellow(frame)} #{name} #{pastel.yellow("started")}"
  when :phase
    phase_str = info[:phase].to_s.tr("_", " ")
    "  #{pastel.yellow(frame)} #{name} #{pastel.cyan(phase_str)}"
  when :done
    "  #{pastel.green("✓")} #{name} #{pastel.green(info[:final] || "done")}"
  when :failed
    "  #{pastel.red("✗")} #{name} #{pastel.red("failed")}"
  else
    "  ? #{name}"
  end
end

$stdout.sync = true

Sync do |task|
  semaphore = Async::Semaphore.new(3, parent: task)
  barrier = Async::Barrier.new

  # Render loop fiber — child of the main task
  render_task = task.async do |_t|
    n = REPOS.size
    initialized = false

    begin
      $stdout.write(CURSOR.hide)

      loop do
        lines = REPOS.map { |r| format_line(r, indicators[r], FRAMES[frame_idx % FRAMES.length], PASTEL, width) }
        frame_idx += 1

        if initialized
          $stdout.write(CURSOR.up(n))
        end
        lines.each { |l| $stdout.puts "\r#{l.ljust(width - 1)}" }
        initialized = true

        break if done
        sleep 0.1
      end
    ensure
      $stdout.write(CURSOR.show)
      $stdout.puts
      $stdout.flush
    end
  end

  # Worker fibers
  REPOS.each_with_index do |repo, i|
    barrier.async do
      inner = semaphore.async do
        indicators[repo] = {phase: nil, status: :started, final: nil}
        sleep(0.2 + i * 0.3)

        phase = PHASES[i % PHASES.length]
        indicators[repo] = {phase: phase, status: :phase, final: nil}
        sleep(0.3 + i * 0.2)

        indicators[repo] = {phase: nil, status: :done, final: "clean"}
      end
      inner.wait
    end
  end

  barrier.wait

  done = true
  render_task.wait
end

puts "Spike complete — all repos done."
