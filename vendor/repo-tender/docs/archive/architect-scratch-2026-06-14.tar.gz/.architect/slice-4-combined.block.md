Execute the architect spec below. Operating rules:

WORKING DIRECTORY: You work in the single repo checkout at
/Users/eric/src/github.com/lemonslut/repo-tender (run `pwd` to confirm; if you
are not there, `cd` there). There are NO other checkouts or worktrees — do not
look for or create any. Every file path below is relative to that root.

PHASE 0 — Before any code: reply with your plan and EVERY disagreement you have
with this spec, with reasons, citing real files in this repo. Silent compliance
is a failure. Silent scope additions are a failure. If you have no
disagreements, state what you checked before concluding the spec is sound.
Verify the named APIs/formats/tools against reality BEFORE planning: confirm no
plist gem is in the Gemfile/lock (hand-roll plist XML with stdlib; validate with
`plutil -lint`); resolve the absolute `mise` + active `ruby` paths on THIS
machine (`which mise`, `mise --version`, the ruby shim) since launchd has no
inherited PATH; and read lib/repo_tender/sync/engine.rb `expand_orgs`/
`build_new_state` and lib/repo_tender/state/store.rb `Org` to confirm exactly
where the CF3 clobber happens before changing it.

PHASE 1 — Freeze shared contracts first (the Launchd::Plist interface, the
Launchd::Agent injected-runner seam, the LogRotator interface, the daemon command
surface, and the new State::Store::Org shape with `last_error`). After you decide
them in your plan they are stable for the rest of the run. The files under
docs/gates/ are read-only at all times — editing them fails the slice regardless
of results.

PHASE 2 — Build exactly the files listed in BOUNDARIES — the full Slice 4 (both
the launchd/daemon surface AND the CF3 state-schema fix; their file sets are
disjoint, so there is no internal conflict). No placeholder implementations —
search the codebase before implementing; full implementations only. Reuse the
existing idioms: boundaries return dry-monads Result (lib/repo_tender/config/
store.rb, sync/engine.rb); the Shell wrapper is lib/repo_tender/shell.rb
(Open3.capture3 → Result); the CLI command pattern + exit-code seam is cli.rb +
cli/sync.rb + status.rb; State::Store value objects are Data.define with keyword
defaults + to_h_compact; tests reuse test/test_helper.rb helpers (with_temp_home,
with_paths) and the engine test's injected-forge seam.
CRITICAL — NEVER run `launchctl bootstrap/bootout/kickstart` against the real
machine: all launchctl interaction in tests goes through an INJECTED fake runner
that records argv and returns canned output; the real launchctl path is covered
ONLY by the human's manual checklist in docs/gates/slice-4.md. Verify your work by
running the gate commands and record the verbatim output. Do NOT commit and do
NOT run ANY git write command (commit/add/branch/reset/checkout/stash) — the
architect commits and merges after verification, and verifies you made no
commits. Read-only git (status/diff/log) is fine. Do NOT delete lock files or
escalate privileges if a command fails; record the exact error and continue. Give
every potentially long command an explicit timeout. When done, write your report
to docs/lanes/slice-4-01.md with RAW results only — tables, numbers, command
output — no interpretation. Every status claim must be backed by a command result
from this run. Keep it compact. End it with exactly one status line: STATUS:
COMPLETE | COMPLETE_WITH_CONCERNS (list them) | BLOCKED (exact blocker + what you
tried). Verdicts belong to the architect and the human. Persist until the whole
slice is handled end-to-end; do not stop at analysis or partial fixes.

=== OBJECTIVE (and why) ===

Build the FINAL slice of repo-tender (PRD §5 Slice 4): launchd integration +
daemon control, PLUS carry-forward CF3 (org-list failure resilience in state).
Slices 1–3 are merged and green. Two cohesive pieces, disjoint files, one run:

A) launchd / daemon (PRD §5 Slice 4):
   - Launchd::Plist — generate a valid launchd plist (StartInterval-driven) that
     runs `repo-tender sync` via mise non-interactively.
   - Launchd::Agent — wrap launchctl bootstrap/bootout/kickstart/print/list behind
     an INJECTED command runner (tests never touch the real domain).
   - cli/daemon.rb — `daemon install|uninstall|start|stop|restart|status`.
   - LogRotator — the sync process rotates its own log (launchd does not).
   A HUMAN DECISION governs this: the live launchctl path is proven by a manual
   real-Mac checklist (docs/gates/slice-4.md), NOT by your tests. Your tests prove
   the exact launchctl argv, plist validity/shape, the filesystem effect under a
   TEMP HOME, status parsing of canned output, and log rotation — all offline.

B) CF3 (Slice 2 disagreement #5 carry-forward): make org-list failures
   non-destructive. Today an org-list Failure records Org(last_listed_at: nil,
   repo_count: 0) and build_new_state merges that over prior good state —
   clobbering a known-good repo_count/last_listed_at on a transient blip; and the
   Org struct has no field for WHY. Two parts: (1) add `last_error` (text) to
   State::Store::Org (round-trips through state.yaml; omitted when nil); (2) on an
   org-list Failure, PRESERVE the prior good repo_count + last_listed_at and set
   last_error, instead of overwriting with nil/0. Previously-discovered repos are
   already preserved (prev.repos.dup) — keep that; the Slice 2 G10 behavior (run
   does not abort; failure recorded; other repos still process) stays intact.

The authoritative acceptance criteria are the frozen gates in
docs/gates/slice-4.md (G0–G8). Read that file first — it is the contract. Also
read PRD §3.2 (state/logs), §5 Slice 4, §7 (DoD), §4 (layout), and the CF3 row +
Slice 2 disagreement #5 ruling in docs/HANDOFF.md.

=== OUTPUT FORMAT (docs/lanes/slice-4-01.md) ===

1. PHASE 0 — plan (one paragraph) + disagreement table (your position · spec
   position · cited file:line · reason) + your PHASE-0 rulings, each with the
   file/command you used to decide it: plist emission + mise non-interactive
   invocation (cite resolved abs mise/ruby paths); launchctl injected-runner seam;
   launch_agents_dir env seam; log-rotation-vs-redirect-fd mechanism; CF3
   non-clobber point (cite the exact engine lines you change).
2. Gate → test mapping table: each gate (G0–G8) → test file + test name(s).
3. Verbatim command output: `bundle install` tail, full `bundle exec rake test`
   summary line, `bundle exec standardrb`, `ruby -Ilib bin/repo-tender --help`
   (showing the new `daemon` group), a `plutil -lint` run on a generated plist,
   and the run of the existing Slice 2 G10 org-resilience test showing it still
   passes.
4. The generated sample plist XML (so the architect can eyeball Label /
   ProgramArguments / StartInterval / no-KeepAlive / absolute paths) and a
   before/after of the org-Failure state record (repo_count/last_listed_at/
   last_error across run-1-success → run-2-failure) from your CF3 test output.
5. Final tree of files created/modified + `git status --porcelain=v2
   --untracked-files=normal` at end of run (the G8 scope check).
6. Notes on documented limitations / design choices.

=== TOOL GUIDANCE (verification commands; verify-against-reality list) ===

Build & test (from AGENTS.md):
  bundle install
  bundle exec rake test                                      # full suite, minitest
  bundle exec ruby -Itest test/repo_tender/<path>_test.rb    # single file
  bundle exec standardrb                                     # lint/format check
  bundle exec standardrb --fix                               # autofix
  ruby -Ilib bin/repo-tender --help                          # run the binary
  plutil -lint <file>                                        # validate a plist (offline)

Verify against reality BEFORE planning:
- mise/ruby abs paths: `which mise`, `mise --version`, the ruby shim. launchd has
  NO PATH — ProgramArguments[0] is an absolute mise path; pin the toolchain via
  WorkingDirectory / MISE_CONFIG_FILE (mise.toml at repo root). `mise activate` is
  broken non-interactively — do not use it.
- Shell wrapper for launchctl: lib/repo_tender/shell.rb (Open3.capture3 → Result;
  argv array). Real runner default goes through this; the test runner is a fake.
- CLI command pattern + exit-code seam: lib/repo_tender/cli.rb (Outcome, CLI.run,
  CLI.env, CLI.make_paths), cli/sync.rb + status.rb. Register the daemon group
  the same way the others are registered.
- Paths: lib/repo_tender/paths.rb (config_file/state_file/log_dir; injectable
  `environment` hash). Add `launch_agents_dir` from that env's HOME so tests
  inject a temp HOME.
- State: lib/repo_tender/state/store.rb (Org Data.define + to_h_compact +
  build_state + emit — add last_error across all). Engine:
  lib/repo_tender/sync/engine.rb (expand_orgs success ≈128–131 / failure
  ≈134–137; build_new_state `prev.orgs.merge` ≈293 — the clobber).
- Test harness: test/test_helper.rb; engine test injected-forge seam in
  test/repo_tender/sync/engine_test.rb (extend; keep G10 green). Plist/status
  tests use canned fixtures (offline, deterministic).
- launchctl modern domain syntax: `gui/<UID>` (bootstrap gui/$UID <plist>,
  bootout gui/$UID/<label>, kickstart -k gui/$UID/<label>, print gui/$UID/<label>,
  list). Resolve UID via Process.uid. Confirm against `man launchctl`/`launchctl
  help`.

=== BOUNDARIES (may touch / must not touch / out of scope) ===

MAY CREATE:
  lib/repo_tender/launchd/plist.rb
  lib/repo_tender/launchd/agent.rb
  lib/repo_tender/log_rotator.rb
  lib/repo_tender/cli/daemon.rb
  test/repo_tender/launchd/plist_test.rb
  test/repo_tender/launchd/agent_test.rb
  test/repo_tender/log_rotator_test.rb
  test/repo_tender/cli/daemon_test.rb
  docs/lanes/slice-4-01.md

MAY EDIT (narrowly, only as the spec describes):
  lib/repo_tender/paths.rb        (ADD `launch_agents_dir` from env HOME — nothing else)
  lib/repo_tender/cli.rb          (ADD `require "repo_tender/cli/daemon"` only)
  lib/repo_tender.rb              (ADD requires for the new files)
  lib/repo_tender/cli/sync.rb     (ADD a log-rotation pre-step at the top of
                                   Run#call; do NOT change --repo scoping / engine
                                   call logic — Slice 3 G4 must stay green)
  lib/repo_tender/state/store.rb  (ADD `last_error` to Org: Data.define + default +
                                   to_h_compact + build_state + emit — nothing else)
  lib/repo_tender/sync/engine.rb  (expand_orgs / build_new_state ONLY: preserve
                                   prior repo_count + last_listed_at on org-list
                                   Failure, set last_error; do NOT change repo
                                   processing, concurrency, or call(config:, paths:))
  test/repo_tender/state/store_test.rb   (ADD Org last_error round-trip cases)
  test/repo_tender/sync/engine_test.rb   (ADD the non-clobber test; keep G10 green)

MUST NOT TOUCH (failing the slice):
  lib/repo_tender/sync/repo_plan.rb, lib/repo_tender/scm/*, lib/repo_tender/forge/*
  lib/repo_tender/config/*, lib/repo_tender/cli/{repo,org,status,config}.rb
  test/test_helper.rb
  anything under docs/gates/

OUT OF SCOPE: any new gem (hand-roll plist XML with stdlib; validate with plutil);
any non-GitHub forge; surfacing org state in the `status` CLI table (status is
per-repo); running real launchctl against the live domain (manual checklist only).

If a gate seems to force you toward a MUST-NOT-TOUCH file, STOP and record it as a
disagreement with the cited gate + file — do not edit it silently.

=== ACCEPTANCE GATES (frozen at docs/gates/slice-4.md — read-only) ===

G0 suite green + lint + no new gems + `--help` lists `daemon`; G1 Launchd::Plist
valid (plutil -lint) + correct ProgramArguments/StartInterval/RunAtLoad/
ProcessType/abs log paths/NO KeepAlive/no ~ or $HOME/mise pinning; G2
Launchd::Agent exact launchctl argv via injected runner (no real launchctl); G3
daemon install/uninstall filesystem effect under a TEMP HOME (real
~/Library/LaunchAgents never written) + idempotent uninstall; G4 daemon status
parses canned launchctl output defensively (no raise on malformed); G5 LogRotator
rotates oversized → timestamped archive (bytes preserved), leaves under-threshold
untouched, wired as a no-op-safe pre-step in cli/sync.rb; G6 State::Store::Org
carries last_error (round-trips; omitted when nil; existing behavior unchanged);
G7 org-list Failure preserves prior repo_count + last_listed_at (NOT 0/nil) + sets
last_error, repos preserved, Slice 2 G10 still passes; G8 only in-scope files.
Read docs/gates/slice-4.md for the verbatim thresholds.
