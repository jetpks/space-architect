Execute the architect spec below. Operating rules:

PHASE 0 — Before any code: reply with your plan and EVERY disagreement you have
with this spec, with reasons, citing real files in this repo. Silent compliance
is a failure. Silent scope additions are a failure. If you have no
disagreements, state what you checked before concluding the spec is sound.
Verify the named APIs/formats/versions against the live tools BEFORE planning
around them — in particular: confirm no plist gem is in the Gemfile/lock (hand-roll
the XML with stdlib and validate with `plutil -lint`), and resolve the absolute
`mise` and `ruby` paths on THIS machine (`which mise`, `mise --version`, the
active ruby shim) since launchd runs with no inherited PATH.

PHASE 1 — Freeze shared contracts first (here: the Launchd::Plist interface, the
Launchd::Agent injected-runner seam, the LogRotator interface, and the daemon
command surface). After you decide them in your plan they are stable for the rest
of the run. The files under docs/gates/ are read-only at all times — editing them
fails the slice regardless of results.

PHASE 2 — Build YOUR LANE ONLY: exactly the files listed in BOUNDARIES. You are
ONE OF TWO parallel lane agents in isolated worktrees; Lane 02 owns
state/store.rb + sync/engine.rb — touching them fails your lane. No placeholder
implementations — search the codebase before implementing; full implementations
only. Reuse the existing idioms: boundaries return dry-monads Result (see
lib/repo_tender/config/store.rb, sync/engine.rb); the Shell wrapper is
lib/repo_tender/shell.rb (Open3.capture3 → Result); the CLI command pattern +
exit-code seam is lib/repo_tender/cli.rb + lib/repo_tender/cli/sync.rb +
status.rb; tests reuse test/test_helper.rb helpers (with_temp_home, with_paths).
CRITICAL: NEVER run `launchctl bootstrap/bootout/kickstart` against the real
machine — all launchctl interaction in tests goes through an injected fake runner
that records argv and returns canned output; the real launchctl path is covered
only by the human's manual checklist in docs/gates/slice-4.md. Verify your work
by running the gate commands and record the verbatim output. Do NOT commit and do
NOT run any git write command (commit/add/branch/reset/checkout) — the architect
commits and merges after verification, and verifies you made no commits. Do NOT
delete lock files or escalate privileges if a command fails; record the exact
error and continue. Give every potentially long command an explicit timeout. When
done, write your lane report to docs/lanes/slice-4-01.md with RAW results only —
tables, numbers, command output — no interpretation. Every status claim must be
backed by a command result from this run. Keep it compact. End it with exactly
one status line: STATUS: COMPLETE | COMPLETE_WITH_CONCERNS (list them) | BLOCKED
(exact blocker + what you tried). Verdicts belong to the architect and the human.
Persist until your lane is fully handled end-to-end; do not stop at analysis or
partial fixes.

=== OBJECTIVE (and why) ===

Build launchd integration + daemon control for repo-tender (PRD §5 Slice 4) so a
user can schedule the periodic sync sweep as a per-user launchd agent. This is
the FINAL slice of the dependency chain (Foundation → Sync engine → CLI →
launchd); Slices 1–3 are merged and green. This lane builds:

  - Launchd::Plist  — generate a valid launchd plist (StartInterval-driven) that
    runs `repo-tender sync` via mise non-interactively.
  - Launchd::Agent  — wrap launchctl bootstrap/bootout/kickstart/print/list
    behind an INJECTED command runner (so tests never touch the real domain).
  - cli/daemon.rb   — `daemon install|uninstall|start|stop|restart|status`.
  - LogRotator      — the sync process rotates its own log (launchd does not).

A HUMAN DECISION governs this slice: the live launchctl path is proven by a
manual real-Mac checklist (in docs/gates/slice-4.md), NOT by your tests. Your
tests prove the exact launchctl argv, the plist validity/shape, the filesystem
effect under a temp HOME, the status parsing of canned output, and log rotation —
all offline and deterministic. Do not bootstrap a real agent.

The full, authoritative acceptance criteria are the frozen gates in
docs/gates/slice-4.md (G0–G5, G8 apply to this lane). Read that file first — it
is the contract. Also read PRD §3.2 (state/logs), §5 Slice 4, §7 (DoD), and §4
(project layout: launchd/{plist,agent}, cli/daemon, log rotation).

=== OUTPUT FORMAT (docs/lanes/slice-4-01.md) ===

1. PHASE 0 — plan (one paragraph) + disagreement table (your position · spec
   position · cited file · reason) + the PHASE-0 rulings you made (plist emission
   + mise non-interactive invocation; launchctl injected-runner seam;
   launch_agents_dir env seam; log-rotation-vs-redirect-fd mechanism), each with
   the file/command you used to decide it (cite resolved abs mise/ruby paths).
2. Gate → test mapping table: each gate (G0–G5) → test file + test name(s).
3. Verbatim command output: `bundle install` tail, full `bundle exec rake test`
   summary line, `bundle exec standardrb`, `ruby -Ilib bin/repo-tender --help`
   (showing the new `daemon` group), and a `plutil -lint` run on a generated plist.
4. The generated sample plist XML (so the architect can eyeball Label /
   ProgramArguments / StartInterval / no-KeepAlive / absolute paths).
5. Final tree of files created/modified + `git status --porcelain=v2
   --untracked-files=normal` at end of run (the G8 scope check).
6. Notes on documented limitations / design choices.

=== TOOL GUIDANCE (verification commands; verify-against-reality list) ===

Build & test (from AGENTS.md):
  bundle install
  bundle exec rake test                                      # full suite, minitest
  bundle exec ruby -Itest test/repo_tender/<path>_test.rb    # single file
  bundle exec standardrb                                     # lint/format check
  bundle exec standardrb --fix                               # autofix
  ruby -Ilib bin/repo-tender --help                          # run the binary
  plutil -lint <file>                                        # validate a plist (offline)

Verify against reality BEFORE planning:
- mise / ruby abs paths: `which mise`, `mise --version`, the active ruby shim
  path. launchd has NO PATH — ProgramArguments[0] must be an absolute mise path;
  pin the toolchain via WorkingDirectory / MISE_CONFIG_FILE (mise.toml is at the
  repo root). `mise activate` is broken non-interactively — do not use it.
- Shell wrapper for launchctl: lib/repo_tender/shell.rb (Open3.capture3 → Result;
  argv array, no shell string). The real runner default goes through this; the
  test runner is an injected fake.
- CLI command pattern + exit-code seam: lib/repo_tender/cli.rb (Outcome stash,
  CLI.run, CLI.env, CLI.make_paths), lib/repo_tender/cli/sync.rb and status.rb
  (Dry::CLI::Command subclass, `out`/`err`, record_outcome, fail_with). Register
  the daemon group the same way the other groups are registered.
- Paths: lib/repo_tender/paths.rb (config_file, state_file, log_dir; honors an
  injectable `environment` hash). Add `launch_agents_dir` resolved from that env's
  HOME so tests inject a temp HOME.
- Test harness: test/test_helper.rb (with_temp_home, with_paths). Reuse these.
  Status-parser + plist tests use recorded/canned fixtures (offline, deterministic).
- launchctl modern domain syntax: `gui/<UID>` for a per-user agent
  (`bootstrap gui/$UID <plist>`, `bootout gui/$UID/<label>`,
  `kickstart -k gui/$UID/<label>`, `print gui/$UID/<label>`, `list`). Resolve UID
  via Process.uid. Confirm against `man launchctl` / `launchctl help` on this box.

=== BOUNDARIES (may touch / must not touch / out of scope) ===

MAY CREATE:
  lib/repo_tender/launchd/plist.rb
  lib/repo_tender/launchd/agent.rb
  lib/repo_tender/log_rotator.rb
  lib/repo_tender/cli/daemon.rb
  test/repo_tender/launchd/plist_test.rb
  test/repo_tender/launchd/agent_test.rb
  test/repo_tender/log_rotator_test.rb
  test/repo_tender/cli/daemon_test.rb
  docs/lanes/slice-4-01.md

MAY EDIT (narrowly, only as the spec describes):
  lib/repo_tender/paths.rb        (ADD `launch_agents_dir` from env HOME — nothing else)
  lib/repo_tender/cli.rb          (ADD `require "repo_tender/cli/daemon"` only)
  lib/repo_tender.rb              (ADD requires for the new files)
  lib/repo_tender/cli/sync.rb     (ADD a log-rotation pre-step at the top of
                                   Run#call; do NOT change the --repo scoping /
                                   engine-call logic — Slice 3 G4 must stay green)

MUST NOT TOUCH (failing the lane — Lane 02 owns the first two):
  lib/repo_tender/state/store.rb, lib/repo_tender/sync/engine.rb
  lib/repo_tender/sync/repo_plan.rb, lib/repo_tender/scm/*, lib/repo_tender/forge/*
  lib/repo_tender/config/*, lib/repo_tender/cli/{repo,org,status,config}.rb
  test/test_helper.rb
  anything under docs/gates/

OUT OF SCOPE: any new gem (hand-roll the plist XML with stdlib; validate with
plutil), any non-GitHub forge, the CF3 state-schema change (that is Lane 02),
running real launchctl against the live domain (manual checklist only).

If a gate seems to force you toward a MUST-NOT-TOUCH file, STOP and record it as a
disagreement with the cited gate + file — do not edit it silently.

=== ACCEPTANCE GATES (frozen at docs/gates/slice-4.md — read-only) ===

G0 suite green + lint + no new gems + `--help` lists `daemon`; G1 Launchd::Plist
valid (plutil -lint) + correct ProgramArguments/StartInterval/RunAtLoad/
ProcessType/abs log paths/NO KeepAlive/no ~ or $HOME/mise pinning; G2
Launchd::Agent exact launchctl argv via injected runner (no real launchctl); G3
daemon install/uninstall filesystem effect under a TEMP HOME (real
~/Library/LaunchAgents never written) + idempotent uninstall; G4 daemon status
parses canned launchctl output defensively (no raise on malformed); G5 LogRotator
rotates oversized → timestamped archive (bytes preserved), leaves under-threshold
untouched, wired as a no-op-safe pre-step in cli/sync.rb; G8 only in-scope files.
Read docs/gates/slice-4.md for the verbatim thresholds.
