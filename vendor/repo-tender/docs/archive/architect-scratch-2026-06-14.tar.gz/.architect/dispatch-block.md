Execute the architect spec below. Operating rules:

PHASE 0 — Before any code: reply with your plan and EVERY disagreement you have
with this spec, with reasons, citing real files in this repo. Silent compliance
is a failure. Silent scope additions are a failure. If you have no
disagreements, state what you checked before concluding the spec is sound.
Verify the named APIs/formats/versions against the live dependencies (the
`async` gem's `Async::Barrier`/`Async::Semaphore` API, `git` behavior) before
planning around them.

PHASE 1 — Freeze shared contracts first. The new `SCM::Client#switch` method
signature is a contract: define it in `lib/repo_tender/scm/client.rb` before
implementing. The files under docs/gates/ are READ-ONLY at all times — editing
any file under docs/gates/ fails the slice regardless of results.

PHASE 2 — Build exactly the files listed in BOUNDARIES. No placeholder
implementations — search the codebase before implementing (reuse the Slice 1
patterns: `Dry::Monads::Result` at every boundary, `Shell.run` for all
subprocesses, the `test_helper.rb` real-repo harness). Full implementations
only. Verify your work by running the lane's gate commands and record the
verbatim output. Do NOT commit and do NOT run any git write command
(commit/add/branch/reset/checkout/stash) — the architect commits and merges
after verification, and verifies you made no commits. Do NOT delete lock files
or escalate privileges if a command fails; record the exact error and continue.
Give every potentially long command an explicit timeout (e.g. prefix shell
commands that hit the network or sleep with a sane timeout); if a runtime will
not start unattended, record the exact failure in your lane report and route
around it — never busy-wait or retry in a loop. When done, write your lane
report to docs/lanes/slice-2-01.md with RAW results only — tables, numbers,
command output — no interpretation, no "promising". Every status claim must be
backed by a command result from this run. Keep the report compact. End it with
exactly one status line: STATUS: COMPLETE | COMPLETE_WITH_CONCERNS (list them) |
BLOCKED (exact blocker + what you tried). Verdicts belong to the architect.
Persist until the lane is fully handled end-to-end; do not stop at analysis or
partial fixes.

=== OBJECTIVE (and why) ===

Build Slice 2 of repo-tender: the **sync engine** that brings every tracked repo
to the evergreen invariant (clean · on default branch · fresh) in one bounded
async run, and reports — never destroys — dirty/diverged repos. This is the heart
of the tool (PRD §3.3, §5 Slice 2, DoD §7). Slice 1 (foundation: paths, config,
state, shell, scm/forge clients) is merged on `main` and is your substrate —
build on its interfaces, do not reimplement them.

Two files are the slice:
- `lib/repo_tender/sync/repo_plan.rb` — the evergreen *evaluation*: given a
  RepoRef + its on-disk path + the SCM client + refresh_interval, observe the
  repo's state and decide the *action* (`:clone | :fast_forward | :switch |
  :report_dirty | :report_diverged | :report_wrong_branch | :report_detached |
  :skip_fresh | :up_to_date`) with a resulting status enum value. Pure-ish and
  unit-testable in isolation. Follow PRD §3.3's ordered evaluation exactly:
  present? → detached/wrong-branch? → clean? → fresh (FETCH_HEAD mtime within
  refresh_interval)? → behind (rev-list left/right)?
- `lib/repo_tender/sync/engine.rb` — *orchestration + execution + state write*:
  expand OrgRefs into RepoRefs via the injected Forge, dedupe against explicit
  repos, run all repos through repo_plan + execute the decided action via the
  SCM client, bounded by `Async::Semaphore(concurrency)` inside one `Sync{}`
  with an `Async::Barrier`. Write a per-repo result to `State::Store`. A single
  repo's Failure (or the org-list Failure) must NOT abort the run.

Also fix a Slice 1 defect you will exercise live here: `Forge::GitHub#build_argv`
emits `--no-source`, which is NOT a valid `gh repo list` flag — see GATE G11.

=== OUTPUT FORMAT (docs/lanes/slice-2-01.md) ===

1. PHASE 0 — one-paragraph plan + a disagreement table (your position · spec's
   position · cited file · reason), and your rulings on the three PHASE-0 items
   in the gates file.
2. Gate→test mapping table: each gate G0–G12 → test file + test name(s).
3. Verbatim command output: `bundle exec rake test` full summary,
   `bundle exec standardrb`, and the key per-gate assertions (G7 concurrency
   probe max count; G4 no-data-loss evidence).
4. Final `git status --porcelain=v2 --untracked-files=normal` (G12 check) and a
   tree of files created/modified.
5. STATUS line.

=== TOOL GUIDANCE (verification commands; verify-against-reality list) ===

Build & test (from AGENTS.md — the architect re-runs exactly these):
```
bundle install
bundle exec rake test
bundle exec ruby -Itest test/repo_tender/sync/engine_test.rb   # single file while iterating
bundle exec standardrb
bundle exec standardrb --fix
```
Verify against reality BEFORE coding:
- `Async::Semaphore` / `Async::Barrier` API at the pinned `async` gem (read the
  installed gem source under the bundle path; confirm `Semaphore#async` and
  `Barrier#wait`).
- `git rev-list --left-right --count HEAD...origin/<default>` output shape (Slice
  1 `scm/git.rb#fast_forward` already parses it — reuse that).
- `git switch` vs `git checkout` for the new `SCM#switch`; confirm it refuses to
  clobber when the tree is dirty (you must never call switch on a dirty tree
  anyway — the engine guards it).
- `gh repo list --help` at the installed gh for valid flags (G11).

=== BOUNDARIES ===

MAY TOUCH (this is the whole slice):
- `lib/repo_tender/sync/repo_plan.rb`            (new)
- `lib/repo_tender/sync/engine.rb`               (new)
- `lib/repo_tender/scm/client.rb`                (edit: add `switch(path, branch)` abstract method)
- `lib/repo_tender/scm/git.rb`                   (edit: implement `switch`)
- `lib/repo_tender/forge/github.rb`              (edit: fix `--no-source`, G11)
- `lib/repo_tender.rb`                           (edit: add requires for the two new sync files ONLY)
- `test/repo_tender/sync/repo_plan_test.rb`      (new)
- `test/repo_tender/sync/engine_test.rb`         (new)
- `test/repo_tender/forge/github_test.rb`        (edit: add G11 argv assertions; keep existing tests green)
- `docs/lanes/slice-2-01.md`                     (your report)

MUST NOT TOUCH: `lib/repo_tender/config/*`, `lib/repo_tender/state/store.rb`
(use its public API; do NOT change its storage format or signatures),
`lib/repo_tender/paths.rb`, `lib/repo_tender/shell.rb`, `test/test_helper.rb`
(reuse it as-is; if you genuinely need a new helper, add it in your own test
file, not test_helper.rb), anything under `docs/gates/`, `Gemfile`,
`Gemfile.lock`, `mise.toml`, `repo-tender.gemspec`.

OUT OF SCOPE: `cli*`, `bin/repo-tender`, `launchd/*`. No new gems. No
refactors beyond what the gates require. `refresh_interval` human-duration
parsing (`6h`/`90m`) is explicitly Slice 3 — in Slice 2 `refresh_interval` is
Integer seconds (as Slice 1 stores it).

=== DISAGREEMENT RULINGS (carried from the Slice 1 judgment) ===

- The non-coercing config `schema`, the dry-struct defaults, and the immutable
  `cfg.new(...)` update idiom from Slice 1 are all ACCEPTED — build on them, do
  not change them.
- `refresh_interval` stays Integer seconds in this slice (duration parsing is a
  ruled Slice 3 item). Do not add duration parsing here.
- The forge `--no-source` flag is a confirmed defect (CF2) — remove it; rely on
  the authoritative `parse_repos` filter for fork/archive exclusion (G11).

=== ACCEPTANCE GATES (frozen at docs/gates/slice-2.md — READ-ONLY) ===

Read docs/gates/slice-2.md in full. Gates G0–G12 are the contract. Summary:
G0 suite green + lint clean, no new gems · G1 clean+behind→ff · G2 fresh→no
network (FETCH_HEAD unchanged) · G3 dirty→byte-untouched+reported · G4
diverged→no destruction · G5 wrong-branch: clean switched / dirty left · G6
missing→clone to $BASE/host/owner/repo · G7 concurrency:2→max in-flight ≤2 · G8
per-repo Failure isolated + state written · G9 idempotent (2nd run no network) ·
G10 org expansion + org-list Failure resilient · G11 forge argv valid · G12 only
in-scope files. G1–G6/G9/G10 prove against REAL temp git repos + a local bare
remote (reuse `with_trunk_repo`/`seed_initial_commit`); G7 and the org half of
G10 may use an injected test double for the SCM/Forge dependency (DI on the
engine's collaborators — NOT a mock of the engine). The engine MUST accept
injected `scm:` and `forge:` (defaulting to `SCM::Git.new` / `Forge::GitHub.new`)
so the gates can drive it.
