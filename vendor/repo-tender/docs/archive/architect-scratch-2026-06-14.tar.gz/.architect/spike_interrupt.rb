#!/usr/bin/env ruby
# frozen_string_literal: true
# Spike: verify render fiber ensure fires when parent task is stopped mid-run.
# Run: bundle exec ruby -Ilib .architect/spike_interrupt.rb

require "async"
require "tty-cursor"
require "stringio"

CURSOR = TTY::Cursor
out = StringIO.new

threads_before = nil
threads_after = nil

begin
  Sync do |task|
    threads_before = Thread.list.size

    render_task = task.async do |_t|
      begin
        out.write(CURSOR.hide)
        loop do
          sleep 0.05
        end
      ensure
        out.write(CURSOR.show)
        out.puts
      end
    end

    # Simulate a mid-run stop (like an interrupt unwinding the parent)
    task.async do |_t|
      sleep 0.15  # let render fiber spin a bit
      render_task.stop
    end

    # Simulate the parent continuing normally after render_task stopped
    render_task.wait rescue nil
    threads_after = Thread.list.size
  end
rescue => e
  puts "ERROR: #{e.class}: #{e.message}"
end

result = out.string
puts "Output contains cursor hide: #{result.include?("\e[?25l")}"
puts "Output contains cursor show: #{result.include?("\e[?25h")}"
puts "Thread count before: #{threads_before}, after: #{threads_after}, delta: #{threads_after - threads_before}"
puts "exit: 0"
