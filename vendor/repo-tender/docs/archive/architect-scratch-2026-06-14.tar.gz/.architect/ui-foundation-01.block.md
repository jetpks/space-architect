Think harder. Execute the architect spec below. Operating rules:

PHASE 0 — Before any code: reply with your plan and EVERY disagreement you have
with this spec, with reasons, citing real files in this repo. Silent compliance
is a failure. Silent scope additions are a failure. If you have no
disagreements, state what you checked before concluding the spec is sound.
Verify the named APIs/formats/versions against the live dependencies before
planning around them. Read first: `docs/prd/cli-ux.md` (Slice A is the contract),
`docs/gates/ui-foundation.md` (your frozen acceptance gates — READ-ONLY),
`AGENTS.md` (repo build/test/conventions — NOT auto-loaded, read it), and the
seam files `lib/repo_tender/sync/engine.rb`, `lib/repo_tender/cli/sync.rb`,
`lib/repo_tender/cli.rb`, `lib/repo_tender/cli/status.rb` (the no-ANSI precedent).

PHASE 1 — Freeze shared contracts (the `UI::Reporter` method list + the `UI::Mode`
field shape) at the top of `lib/repo_tender/ui/reporter.rb` and `lib/repo_tender/ui/mode.rb`
as the single source of truth before building consumers against them. After you
write them they are stable for the rest of your run. Files under `docs/gates/`
are read-only at all times — editing them fails the slice regardless of results.

PHASE 2 — Build the slice (this is a SINGLE-lane slice in the main checkout —
build the full file set in BOUNDARIES). No placeholder implementations — search
the codebase before implementing; full implementations only. Verify your work by
running the gate commands and record the verbatim output. Do NOT commit and do
NOT run any git write command (commit/add/branch/reset/checkout/merge/rebase/
push) — the architect commits and merges after verification, and verifies you
made no commits. Do NOT delete lock files or escalate privileges if a command
fails; record the exact error and continue. Give every potentially long command
an explicit timeout. When done, write your lane report to
`docs/lanes/ui-foundation-01.md` with RAW results only — tables, numbers, command
output — no interpretation, no "promising". Every status claim must be backed by
a command result from this run. Include a gate→test mapping table (each gate →
test file + test name). Keep it compact. End it with exactly one status line:
STATUS: COMPLETE | COMPLETE_WITH_CONCERNS (list them) | BLOCKED (exact blocker +
what you tried). Verdicts belong to the architect. Persist until your lane is
fully handled end-to-end; do not stop at analysis or partial fixes.

=== OBJECTIVE (and why) ===

Build the foundation of a dual-mode CLI output system for `repo-tender`, per
`docs/prd/cli-ux.md` Slice A ("Mode + Reporter seam + Plain/JSON renderers, no
animation"). The goal: every command can report *what is happening* through an
injected event seam that renders as clean structured output, and degrades
correctly for non-interactive use (launchd / pipes / CI) — WITHOUT any color or
animation yet (those are Slice B/C; adding them here fails the gates).

Deliver four things:
1. `UI::Mode` — an immutable `dry-struct` value resolving `(flags, env, out.tty?)`
   → `{color:, animate:, quiet:, format:}` via the precedence in PRD §3.1
   (flag > env > autodetect). Pure and exhaustively unit-testable.
2. `UI::Reporter` — a fixed-method event interface (Bundler::UI / RSpec-formatter
   shape) the domain calls; methods: `run_started(total:)`, `repo_started(ref)`,
   `repo_phase(ref, phase)`, `repo_finished(ref, status)`, `repo_failed(ref,
   error)`, `run_finished(summary)`, `attach(task, total:)`, `detach`. Plus
   `NullReporter` (all no-ops). For Slice A `attach`/`detach` are no-ops on every
   reporter (the render-fiber body is Slice B — wire the seam now, leave it empty).
3. `UI::PlainReporter(out, mode)` and `UI::JsonReporter(out)` — one structured,
   ANSI-free line per meaningful event; JSON = one parseable object per line.
4. Wire it in: `Sync::Engine#initialize` gains `reporter:` (default `NullReporter`),
   emits the events at the §3.3 seams (`call` brackets the fan-out with
   `attach`/`run_started` … `run_finished`/`detach`; `process_one` emits
   `repo_started` → `repo_phase` → `repo_finished`/`repo_failed`). `cli/sync.rb`
   resolves `Mode`, constructs the matching reporter, passes it to the engine, and
   adds the output flags via a shared `cli/options.rb` helper.

CRITICAL design constraints (gates enforce these):
- **Zero engine behavior change** with the default reporter. `engine_test.rb`'s
  existing tests must stay UNMODIFIED and green (G2). Adding `reporter:` must not
  change any result, state row, status, or control flow. The default `NullReporter`
  produces a byte-identical `state.yaml`.
- **No color, no gems.** `:pretty` resolves but is rendered by `PlainReporter`
  (no color) in this slice. Do NOT add `pastel`/`tty-*`/any gem (G0/G7).
- **No `--daemon` flag.** Non-interactive is detected (non-TTY → `:plain`), with
  `--plain`/`--json` overrides. `--daemon` must NOT be a recognized option.
- **Preserve `sync`'s `synced N repo(s)` summary line** — reporter output is
  additive detail, not a replacement. errors → stderr per clig.dev.
- The engine fan-out runs inside `Sync do |task|` on a single-threaded reactor;
  reporter event methods run synchronously inside fibers (no render loop in Slice
  A), so immediate line writes are safe (no mid-write interleave). Concurrent
  repos emit interleaved — make tests assert on the per-ref pairing/set, not a
  fixed cross-repo order.

=== OUTPUT FORMAT ===

`docs/lanes/ui-foundation-01.md`, RAW only:
- Plan + PHASE 0 disagreements (with file:line citations) and what you verified.
- Files created/changed (paths).
- Gate→test mapping table: G0–G7 → test file + test name(s).
- Verbatim command output for: `bundle install`, `bundle exec rake test` (the
  full counts line `N runs, M assertions, 0 failures, 0 errors, 0 skips`),
  `bundle exec standardrb`, `git diff --stat <freeze>.. -- Gemfile Gemfile.lock
  repo-tender.gemspec` (must be empty), `ruby -W:no-experimental -Ilib
  bin/repo-tender --help`.
- A short sample of `PlainReporter` and `JsonReporter` output (a few lines each).
- One STATUS line at the very end.

=== TOOL GUIDANCE (verification commands; verify-against-reality list) ===

Build/test (from AGENTS.md — the architect re-runs EXACTLY these to judge):
```
bundle install
bundle exec rake test                                   # full suite (minitest)
bundle exec ruby -Itest test/repo_tender/ui/mode_test.rb # a single new file
bundle exec standardrb                                  # lint/format check (must exit 0)
bundle exec standardrb --fix                            # autofix before reporting done
```
Baseline at freeze: `rake test` = 229 runs / 918 assertions / 0 / 0 / 0. Your
additions push the counts up; failures=errors=skips MUST stay 0.

Verify against the LIVE dependencies before coding (record findings in PHASE 0):
- **dry-cli 1.4** flag/option API: how to declare boolean flags (`--plain`,
  `--json`, `--no-color`, `--quiet`) and read them in `#call`, and whether a
  shared module can inject options into multiple command classes (check the
  installed gem source / existing `cli/sync.rb` `option :repo`). Confirm `--daemon`
  can be made a non-recognized flag (default dry-cli behavior for unknown flags).
- **dry-struct 1.8 / dry-types 1.9**: immutable value with `Bool` + `Symbol`
  attributes and an enum/constrained `format` (`:pretty|:plain|:json`); how
  mutation raises. Match the existing `config/model.rb` dry-struct idiom.
- **async 2.39**: confirm `attach(task, …)`/`detach` can be no-ops now and that
  emitting plain method calls from inside `process_one` (which runs in
  `semaphore.async` fibers) needs no synchronization for line-at-a-time writes on
  the single-threaded reactor. Do NOT add a render loop (Slice B).
- **stdlib `json`**: already available (transitive dep) — `require "json"`, no gem
  add. Confirm `JSON.generate`/`JSON.parse` round-trip your event lines.
- Read `cli/status.rb` (the no-ANSI, tab-separated, assertion-friendly precedent)
  and mirror that discipline in `PlainReporter`.

Tests use **real temp git repos + a local bare remote, no mocks** of classes
under test (AGENTS.md). For G3 reuse the Slice-2 engine test seam in
`test/repo_tender/sync/engine_test.rb`. A "recording reporter" that captures
`(method, args)` is a legitimate test double of the REPORTER (a seam), not of the
engine under test.

=== BOUNDARIES (may touch / must not touch / out of scope) ===

Authoritative file set is in `docs/gates/ui-foundation.md` §"Lane file set". Summary:

MAY CREATE: `lib/repo_tender/ui/{mode,reporter,plain_reporter,json_reporter}.rb`,
`lib/repo_tender/cli/options.rb`, tests under `test/repo_tender/ui/` and
`test/repo_tender/cli/`, and `docs/lanes/ui-foundation-01.md`.

MAY EXTEND (narrowly): `lib/repo_tender/sync/engine.rb` (add `reporter:` + emit
events ONLY — no other logic/result/state/timing change), `lib/repo_tender/cli/sync.rb`
(resolve Mode + construct reporter + add flags; do NOT change `--repo` scoping or
exit codes; preserve the `synced N repo(s)` line), `lib/repo_tender.rb` and/or
`lib/repo_tender/cli.rb` (requires only), `test/repo_tender/sync/engine_test.rb`
(ADDITIONS ONLY — existing tests unmodified, G2), `test/repo_tender/cli/sync_test.rb`
(additive).

MUST NOT TOUCH: `state/store.rb`, `scm/*`, `forge/*`, `config/*`,
`sync/repo_plan.rb`, `cli/{repo,org,status,config,daemon}.rb`, `launchd/*`,
`log_rotator.rb`, `shell.rb`, `paths.rb`, `test_helper.rb`, `Gemfile`,
`Gemfile.lock`, `repo-tender.gemspec`, anything under `docs/gates/`.

OUT OF SCOPE (Slice B/C — do NOT start): any color / `pastel` / `tty-*` gem; the
`InteractiveReporter`; the render-loop fiber body; rolling color/spinners into
other commands. No refactors beyond what the seam requires.

=== DISAGREEMENT RULINGS (from last session) ===

None — this is the first slice of a new epic (CLI-UX). Raise your PHASE-0
disagreements fresh; the architect rules on each in the judging session.

=== ACCEPTANCE GATES (frozen at docs/gates/ui-foundation.md — read-only) ===

G0 suite green + no new gems; G1 `Mode.resolve` precedence table; G2 engine
default `NullReporter` = zero behavior change (engine_test unmodified, byte-identical
state); G3 engine emits correct event sequence (recording reporter, real-repo);
G4 `PlainReporter` ANSI-free & deterministic + `JsonReporter` parseable; G5 non-TTY
& `--plain` → plain, `--json` → JSON, no `--daemon`; G6 `bin/repo-tender sync` e2e
unchanged + plain when piped; G7 only in-scope files, no commits, gates clean.
Read the full verbatim text and thresholds in `docs/gates/ui-foundation.md`.
