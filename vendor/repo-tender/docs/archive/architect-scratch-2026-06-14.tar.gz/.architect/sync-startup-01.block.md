ultrathink

Execute the architect spec below. Operating rules:

PHASE 0 — Before any code: reply with your plan and EVERY disagreement you have
with this spec, with reasons, citing real files. Silent compliance is a failure.
Silent scope additions are a failure. Verify the named APIs (Async barrier/
semaphore, the engine seam, the forge auth path) against the live source
(~/src/evergreen/github.com/socketry/async/ for Async) before planning around them.

PHASE 1 — FREEZE the new reporter interface FIRST in lib/repo_tender/ui/reporter.rb
(the three listing methods + the `attach(task)` signature change) and the
`Forge::Client#check_authenticated` declaration, with their doc comments, BEFORE
touching the implementations. After you write them, they are the contract for all
impls. docs/gates/ is read-only at all times.

PHASE 2 — Build the lane (one lane — interface + engine emission + all 4 reporter
impls + forge are interdependent). No placeholders; full implementations. Verify
with the gate commands; record verbatim output. Do NOT commit or run any git write
command — the architect commits/merges and verifies you made no commits. This is
HIGH-STAKES: you are modifying the proven engine concurrency and the no-data-loss
org-expansion path (CF3). The Slice-2 G10 and Slice-4 G6/G7 org tests encode
invariants that MUST stay green — run them and keep them green; adapt them only
ADDITIVELY (do not delete an invariant assertion to make a test pass). Give long
commands a timeout. Scratch scripts go under .architect/ or /tmp, NOT committed.
When done, write docs/lanes/sync-startup-01.md with RAW results only (tables,
numbers, command output, the before/after concurrency timing). End with exactly
one STATUS line: COMPLETE | COMPLETE_WITH_CONCERNS (list) | BLOCKED (exact blocker
+ what you tried). Persist until the lane is fully handled.

=== OBJECTIVE (and why) ===

`repo-tender sync` sits SILENT for ~20-35s before any output, in EVERY mode
(including --json). Root cause (measured): `Sync::Engine#expand_orgs`
(lib/repo_tender/sync/engine.rb:146-168) lists the configured orgs SEQUENTIALLY
via the forge, and `Forge::GitHub#list_org` runs a redundant `gh auth status`
per org, and NO reporter event is emitted during expansion — `run_started` only
fires AFTER all orgs are listed (engine.rb:95). On the operator's 5-org config
that's 35s of dead air (one org alone ~15s).

Make org expansion FAST and INFORMED, without weakening the engine's invariants:

1. **Parallelize expand_orgs.** Fan the per-org listing out concurrently inside
   the engine's existing `Sync do |task|` block, bounded by an `Async::Semaphore`
   (reuse `config.concurrency` or a dedicated constant — your call, justify it),
   exactly as the repo sweep does (engine.rb:105-119 uses Async::Barrier +
   Async::Semaphore). Wall-time drops from sum-of-orgs to ~slowest-org. PRESERVE:
   per-org failure isolation (one org's Failure is recorded, does NOT abort the
   run), CF3 (a failing org keeps the prior good `repo_count`/`last_listed_at` from
   `prev_orgs` + sets `last_error` — see expand_orgs:159-164), dedupe explicit-wins
   (dedupe:181-186), and the discovered set must be identical (order-independent)
   to the sequential baseline.

2. **Authenticate once.** `Forge::GitHub#check_authenticated` (github.rb:59-71) is
   currently PRIVATE and called inside every `list_org` (github.rb:27-28). Make it
   PUBLIC, add it to the `Forge::Client` interface (forge/client.rb), REMOVE the
   per-`list_org` auth call, and have the ENGINE call `@forge.check_authenticated`
   ONCE before fanning out. On auth Failure: record EVERY org as failed (CF3
   preserved), attempt no `list_org`, complete the run (no crash).

3. **Report listing progress.** Extend the reporter interface
   (lib/repo_tender/ui/reporter.rb) with: `listing_started(total:)` (org count),
   `org_listed(ref, count:)` (one per org as it finishes; `count: nil` on failure),
   `listing_finished`. **Change `attach(task, total:)` → `attach(task)`** and call
   it BEFORE expansion (so the render fiber is alive during listing); the repo
   total still arrives via the existing `run_started(total:)`. Implement in all
   four reporters: NullReporter = no-ops; PlainReporter/JsonReporter = one
   line/object per `org_listed`; InteractiveReporter = a live per-org listing
   display that then transitions to the compact repo counter (two phases under one
   attach/detach).

4. **Flush Plain/Json.** Make their output immediate when stdout is NOT a TTY (set
   `@out.sync = true` at construction, or flush per event — pick one, assert it).
   This is why piped `--json` looked silent: `puts` to a pipe is block-buffered.

Why it matters: the CLI-UX epic's whole goal (PRD §1) is "keep the user informed
as it happens." A 35s silent prologue violates that. This is the engine/forge half
of that goal; the compact renderer (already on this branch) is the sweep half.

Engine event sequence AFTER this slice (verify you achieve exactly this):
  attach(task) → listing_started(total: n_orgs) → {org_listed(ref, count:) per org}
  → listing_finished → run_started(total: n_repos) → {repo_started → repo_phase* →
  repo_finished|repo_failed} → run_finished(summary) → detach

=== OUTPUT FORMAT ===

docs/lanes/sync-startup-01.md, RAW only:
1. PHASE 0: plan, disagreements (numbered, cite real files), and your Async
   verification notes (child task / semaphore / ensure-on-cancel).
2. Before/after concurrency evidence: the SlowForge test result (max in-flight,
   wall-time vs sequential) proving GS1; the auth-once count proving GS2.
3. Gate→test mapping: GS0–GS7 + the carried Slice-2 G10 / Slice-4 G6,G7 / Slice-A
   G2,G4 / GC1–GC3,G1,G4,G5 → test file + test name(s).
4. Verbatim: `rake test` tail, `standardrb`, `git diff --name-only <FREEZE3>..`,
   `git diff --stat <FREEZE3>.. -- lib/repo_tender/state/store.rb lib/repo_tender/shell.rb lib/repo_tender/scm`
   (empty), `git diff <FREEZE3>.. -- repo-tender.gemspec Gemfile.lock` (empty),
   `ruby -W:no-experimental -Ilib bin/repo-tender --help`.
5. The exact STATUS line.

=== TOOL GUIDANCE (verification commands; verify-against-reality) ===

  bundle exec rake test                         # 316 baseline + new; 0 fail/err/skip
  bundle exec ruby -Itest test/repo_tender/sync/engine_test.rb
  bundle exec standardrb            # 0  (run --fix before reporting)
  ruby -W:no-experimental -Ilib bin/repo-tender --help

Verify before coding:
- engine.rb `call` + `expand_orgs` + the Async barrier/semaphore repo-sweep pattern
  (105-119) — mirror it for orgs.
- The Slice-2 G10 tests (`test_g10_org_*` ~ engine_test.rb:639-854) and the CF3
  tests (`test_g7_org_list_failure_preserves_*`) — these are your invariant
  guardrails; keep them green.
- forge/client.rb (interface) + forge/github.rb (check_authenticated, list_org,
  build_argv) + forge/github_test.rb (the auth-failure test moves from list_org to
  check_authenticated + the engine path).
- The reporter interface + all 4 impls (reporter.rb, plain_reporter.rb,
  json_reporter.rb, interactive_reporter.rb) and their tests; the RecordingReporter
  in engine_test.rb (~922) — extend it for the listing methods.
- Async: that org listing fibers are children of `task`, semaphore-bounded; read
  ~/src/evergreen/github.com/socketry/async/ rather than guessing.

=== BOUNDARIES (may touch / must not touch) ===

MAY TOUCH (one lane):
- lib/repo_tender/sync/engine.rb            (expand_orgs parallel + attach-early + listing emit + auth-once)
- lib/repo_tender/forge/client.rb           (declare check_authenticated)
- lib/repo_tender/forge/github.rb           (check_authenticated public; drop per-list_org auth)
- lib/repo_tender/ui/reporter.rb            (interface + NullReporter + attach(task))
- lib/repo_tender/ui/plain_reporter.rb, lib/repo_tender/ui/json_reporter.rb  (listing events + flush)
- lib/repo_tender/ui/interactive_reporter.rb (two-phase: listing + sweep)
- lib/repo_tender/cli/sync.rb               (only if reporter construction/attach wiring needs it)
- test/repo_tender/sync/engine_test.rb, test/repo_tender/forge/github_test.rb,
  test/repo_tender/ui/{reporter,plain_reporter,json_reporter,interactive_reporter}_test.rb,
  test/repo_tender/cli/sync_test.rb  (ADDITIVE where existing tests encode invariants)
- docs/lanes/sync-startup-01.md

MUST NOT TOUCH:
- lib/repo_tender/state/store.rb   (CF3 last_error schema already exists — no schema change)
- lib/repo_tender/scm/*, lib/repo_tender/shell.rb, lib/repo_tender/sync/repo_plan.rb
- config/*, launchd/*, paths.rb, log_rotator.rb, cli.rb, cli/options.rb, ui/mode.rb
- cli/{repo,org,status,config,daemon}.rb
- repo-tender.gemspec, Gemfile, Gemfile.lock   (NO new gems)
- test_helper.rb, anything under docs/gates/

=== DISAGREEMENT RULINGS (from last session) ===

None new. Raise fresh PHASE-0 disagreements citing real files. Note especially if
you believe the `attach(task)` signature change or the auth-once relocation breaks
something — cite it.

=== ACCEPTANCE GATES (frozen at docs/gates/sync-startup.md — read-only) ===

GS0 — suite/lint green, no new gems, --help 5 groups, engine diff confined to the
      expansion/attach/listing seam.
GS1 — org expansion CONCURRENT (SlowForge: max in-flight >1, wall-time < (N-1)·S).
GS2 — check_authenticated invoked EXACTLY ONCE regardless of org count; list_org
      does no auth; auth-failure records all orgs failed (CF3) without crash.
GS3 — invariants preserved: Slice-2 G10 (failure isolation) + Slice-4 G6/G7 (CF3
      preserve prior count + last_error) GREEN; discovered set + dedupe identical
      to sequential; state/store.rb unchanged.
GS4 — listing events in phase order (attach → listing_started → org_listed* →
      listing_finished → run_started → … → detach); NullReporter no-ops; existing
      default-reporter engine tests still green.
GS5 — Plain/Json flush (immediate on non-TTY) + render listing events; Slice-A G4
      plain/json gates green.
GS6 — InteractiveReporter two-phase (listing then compact counter); carries GC1/
      GC2/GC3 + G1 (no Thread) + G4 (^C) + G5 (color gated).
GS7 — file scope; no builder commits; no new gems; state/store.rb, scm/*, shell.rb
      byte-unchanged.

Read the full thresholds at docs/gates/sync-startup.md. <FREEZE3> is the freeze
commit the architect records at dispatch.
