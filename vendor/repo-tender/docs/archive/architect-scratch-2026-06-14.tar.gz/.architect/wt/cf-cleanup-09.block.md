Think harder. Execute the architect spec below. Operating rules:

PHASE 0 — Before any code: reply with your plan and EVERY disagreement you have
with this spec, with reasons, citing real files in this repo. Silent compliance
is a failure. Silent scope additions are a failure. If you have no
disagreements, state what you checked before concluding the spec is sound.
Verify the named APIs/formats/versions against the live dependencies before
planning around them.

PHASE 1 — There are no shared contracts to freeze in this lane (single file +
its test). The files under docs/gates/ are read-only at all times — editing them
fails the slice regardless of results.

PHASE 2 — Build YOUR LANE ONLY: exactly the files listed in BOUNDARIES. You are
one of three parallel lane agents working in isolated worktrees; files outside
your lane belong to other agents — touching them fails your lane. No placeholder
implementations — search the codebase before implementing; full implementations
only. Verify your work by running the lane's gate commands and record the
verbatim output. Do NOT commit and do NOT run any git write command
(commit/add/branch/reset/checkout) — the architect commits and merges after
verification, and verifies you made no commits. Do NOT delete lock files or
escalate privileges if a command fails; record the exact error and continue.
Give every potentially long command an explicit timeout. When done, write your
lane report to docs/lanes/cf-cleanup-09.md with RAW results only — tables,
numbers, command output — no interpretation. Every status claim must be backed
by a command result from this run. Keep the report compact. End it with exactly
one status line: STATUS: COMPLETE | COMPLETE_WITH_CONCERNS (list them) | BLOCKED
(exact blocker + what you tried). Verdicts belong to the architect and the human.
Persist until your lane is fully handled end-to-end.

=== OBJECTIVE (and why) ===
CF9: make the concurrent org fan-out in `Engine#expand_orgs`
(`lib/repo_tender/sync/engine.rb`, ~lines 193-223) resilient to a `list_org`
that RAISES, and make reporter teardown crash-safe. Today, if `@forge.list_org`
(or `parse_repos` inside it — e.g. `gh` emitting schema-violating JSON hitting
`nil.split`/`KeyError`) RAISES rather than returning `Failure`, the exception
propagates `inner.wait` → `org_barrier.wait` → out of `Engine#call` as a raw
raise, aborting ALL other orgs + the entire repo sweep and WRITING NO STATE. The
repo sweep's `process_one` already guards this with a last-resort `rescue => e`
(~lines 371-377, its G8 guarantee); the org fan-out lacks the equivalent.
Separately, `@reporter.detach` (~line 139) is not `ensure`-guarded even though
`@reporter.attach(task)` now fires before expansion (~line 96), so an escaping
raise leaves the render fiber un-detached.

Fix BOTH halves:
- Part A — give the org fiber the SAME last-resort `rescue => e` as
  `process_one`: inside the `semaphore.async do ... end` body in `expand_orgs`,
  rescue any exception and record the org as a FAILED ROW, mirroring the existing
  `else` (Failure) branch — preserve the prior `last_listed_at` and `repo_count`
  from `prev_orgs[key]` (CF3!), set `last_error: "unhandled: #{e.class}:
  #{e.message}"`, write the row under `org_mutex`, and emit
  `@reporter.org_listed(org_ref, count: nil)`. The raise no longer escapes; the
  run completes and writes state.
- Part B — wrap the `@reporter.attach(task)` … `@reporter.detach` span in
  `Engine#call` so `detach` runs in an `ensure` (teardown survives any escaping
  raise). Keep `attach` where it is (before expansion); move `detach` into the
  `ensure`. Do not change the engine's event ORDER on the happy path (attach →
  listing_* → run_started → repo_* → run_finished → detach).

WHY this is correct & safe: NOT a regression (the old sequential `expand_orgs`
had the identical gap), NOT a no-data-loss change to the happy path — it makes
the raise path recoverable (state IS written instead of lost). MEDIUM-HIGH
stakes (engine concurrency); a fresh architect session runs a cross-model
adversarial diff pass at judgment. Preserve EVERY existing gated behavior:
GS1–GS6 (concurrency, auth-once, phase order, isolation), G10 (org-list Failure
resilient), CF3 (prior repo_count/last_listed_at preserved on failure), and the
dedupe explicit-wins. Those tests live in engine_test.rb and must pass UNCHANGED.

=== OUTPUT FORMAT ===
docs/lanes/cf-cleanup-09.md, compact, RAW only:
- The production diff summary (what changed in engine.rb — the org-fiber rescue
  and the ensure-guarded detach).
- Verbatim output of: `bundle exec rake test`, `bundle exec standardrb`,
  `git diff <freeze>.. -- repo-tender.gemspec Gemfile.lock` (must be empty),
  `git diff <freeze>.. -- test/repo_tender/sync/engine_test.rb --stat` (+N/-0).
- For each gate G9.0–G9.4: the exact test name(s)/command proving it + pass/fail.
  For G9.2, state the EXACT injection mechanism you used to make a raise escape
  the attach…detach span.
- `git status` and `git log <freeze>..` (must be empty).
The freeze commit SHA is 5106b7b881e5c235e51fc69cc173080be341fa0b.

=== TOOL GUIDANCE (verification commands; verify-against-reality list) ===
Per CLAUDE.md / AGENTS.md, use `bundle exec`:
- `bundle exec rake test`
- `bundle exec ruby -Itest test/repo_tender/sync/engine_test.rb`  # this lane
- `bundle exec standardrb` / `bundle exec standardrb --fix`
Verify against reality BEFORE coding:
- Read `process_one`'s last-resort rescue (engine.rb ~371-377) — mirror its
  shape for the org fiber.
- Read the existing `else`/Failure branch in `expand_orgs` (~209-218) — your
  rescue must produce the SAME CF3-preserving Org row shape.
- Read the existing engine_test.rb org/GS/G10/CF3 tests (test names: test_gs1*,
  test_gs2*, test_gs3*, test_gs4*, test_g10_*, test_g7_org_list_failure_*) and
  how they build forge doubles (RecordingForge/SlowForge etc.) + a recording
  reporter — reuse those harnesses; no mocks of the class under test.
- Confirm how Async::Barrier propagates a child task raise out of `.wait`
  (socketry/async evergreen checkout) — this is the mechanism CF9 closes.

=== BOUNDARIES (may touch / must not touch / out of scope) ===
MAY TOUCH (only these):
- lib/repo_tender/sync/engine.rb
- test/repo_tender/sync/engine_test.rb
- docs/lanes/cf-cleanup-09.md   (your report)
MUST NOT TOUCH:
- lib/repo_tender/state/store.rb, lib/repo_tender/shell.rb (other lanes)
- lib/repo_tender/scm/*, lib/repo_tender/forge/* (leave byte-unchanged)
- any other lib/, test/, bin/, gemspec, Gemfile, Gemfile.lock, docs/gates/*
OUT OF SCOPE: refactoring the fan-out structure beyond adding the rescue +
ensure; changing the happy-path event order; altering process_one or the repo
sweep; touching the Failure-branch behavior (it already works — G10/CF3 green).
No new gems. No placeholders.

=== DISAGREEMENT RULINGS (pre-frozen) ===
- The org-fiber rescue MUST preserve CF3 (prior repo_count/last_listed_at from
  prev_orgs[key]) — do NOT zero them. Mirror the existing Failure branch.
- detach goes in an `ensure`; attach stays before expansion; happy-path event
  order unchanged.
- engine_test.rb is ADDITIONS-ONLY: do not edit any existing test body; only add
  new test methods.

=== ACCEPTANCE GATES (frozen at docs/gates/cf-cleanup.md — read-only) ===
Your gates are the "Lane cf-cleanup-09 — CF9" section of docs/gates/cf-cleanup.md
(G9.0–G9.4) plus the shared commands at the top. Read that file; do not edit it.
Summary:
- G9.0 suite + lint + no new gems green (re-proves GS1-6/G10/CF3).
- G9.1 a forge whose list_org RAISES for one of several orgs → Engine#call
  returns Success, run completes, raising org recorded with last_error (CF3
  prior counts preserved), other orgs listed + their repos processed, state.yaml
  IS written.
- G9.2 a raise escaping the attach…detach span still invokes @reporter.detach
  exactly once (recording reporter); record the exact injection used.
- G9.3 engine_test.rb diff is +N/-0; all existing gs*/g10/g7-org tests pass
  unchanged.
- G9.4 scope: only the 3 lane files; store.rb/shell.rb/scm/forge byte-unchanged;
  no commits; gates clean.
