Ultrathink. Execute the architect spec below. Operating rules:

PHASE 0 — Before any code: reply with your plan and EVERY disagreement you have
with this spec, with reasons, citing real files in this repo. Silent compliance
is a failure. Silent scope additions are a failure. If you have no
disagreements, state what you checked before concluding the spec is sound.
Verify the named APIs/formats/versions against the live dependencies before
planning around them — in particular, confirm `File#flock` / `File::LOCK_EX` /
`File::LOCK_NB` semantics on this macOS (BSD flock) and that two separate
`File.open` of the same path in ONE process get independent locks that contend
(this is how your GA2/GA3 tests simulate an "in-flight run" without a second
process).

PHASE 1 — There are no new shared contracts to freeze in docs/ for this lane
(the gate file is already frozen and is READ-ONLY — editing anything under
docs/gates/ fails the slice regardless of results). Expose the lockfile-path
derivation as a public method (e.g. `State::Lock.path_for(state_file)`) so the
tests compute the same sidecar path the engine uses.

PHASE 2 — Build YOUR LANE ONLY: exactly the files listed in BOUNDARIES. You are
one of TWO parallel lane agents in isolated worktrees; the other lane owns
`lib/repo_tender/state/store.rb` and its test — touching them fails your lane.
No placeholder implementations — search the codebase before implementing; full
implementations only. Verify your work by running the lane's gate commands and
record the verbatim output. Do NOT commit and do NOT run any git write command
(commit/add/branch/reset/checkout/merge/rebase) — the architect commits and
merges after verification, and verifies you made no commits. Do NOT delete lock
files or escalate privileges if a command fails; record the exact error and
continue. Give every potentially long command an explicit timeout. When done,
write your lane report to `docs/lanes/state-hardening-A.md` with RAW results
only — tables, numbers, command output — no interpretation, no "promising".
Every status claim must be backed by a command result from this run. Keep it
compact. End with exactly one status line:
STATUS: COMPLETE | COMPLETE_WITH_CONCERNS (list them) | BLOCKED (exact blocker +
what you tried). Verdicts belong to the architect and the human. Persist until
your lane is fully handled end-to-end; do not stop at analysis or partial fixes.

=== REPO ROOT (your worktree — use this absolute path for everything) ===
/Users/eric/src/github.com/lemonslut/repo-tender/.architect/wt/state-hardening-A

Work ONLY inside that path. NEVER touch
`/Users/eric/src/github.com/lemonslut/repo-tender` (the main checkout — a
different lane/branch). Run all commands from your worktree root. First, read
`AGENTS.md` (builder standing context — Claude Code does not auto-load it) and
`docs/gates/state-hardening.md` (your frozen gates) in your worktree.

=== OBJECTIVE (and why) ===
Close carry-forward **CF10**. Today two overlapping `repo-tender sync` processes
(a launchd `StartInterval` tick fires while a prior run is still in flight, OR an
operator runs `sync` during the scheduled job) each do
`State::Store.load(state_file)` → build a new state from their own run → atomic
`State::Store.write(...)`, independently. The later writer's atomic rename
**clobbers the whole file**, losing the other run's org/repo rows (the file is
always a complete valid emit — just stale). There is no `flock`/lockfile
anywhere. This is the only remaining no-data-loss gap in the engine.

Fix: serialize at the PROCESS level with an advisory lock on a sidecar lockfile,
held across the engine's entire load→write span, so an overlapping run never
writes and therefore cannot clobber the in-flight run's data.

**Design — NON-BLOCKING bail (gated; encoding details are your PHASE-0 call):**
- A sidecar lockfile whose path is derived from `paths.state_file` (e.g.
  `"#{state_file}.lock"`). Create it if missing — `FileUtils.mkdir_p` its dir
  FIRST (the state dir may not exist on a first run; `State::Store.write` does
  this mkdir, but you acquire the lock BEFORE the write). NEVER `unlink` the
  lockfile (deleting a flock'd file is a race; it is a persistent zero-byte
  sentinel).
- Acquire `flock(File::LOCK_EX | File::LOCK_NB)` BEFORE `State::Store.load`
  (engine.rb:91) and release it AFTER `State::Store.write` (engine.rb:142),
  covering the whole span. Release on EVERY exit path (normal return, write
  Failure return, AND an escaping exception/Interrupt) — use `ensure`, mirroring
  the CF9 `ensure`-guarded `@reporter.detach` already in `Engine#call`.
- If the lock is NOT acquired (another run holds it): bail cleanly — do NOT
  write `state.yaml`, do NOT raise, and signal a distinguishable "skipped —
  another sync in progress" outcome. **A blocking `LOCK_EX` is REJECTED**: under
  an unattended launchd daemon a hung run would block every later tick forever,
  and it cannot be tested in-process without hanging.
- Prefer returning the **unchanged loaded state** as `Dry::Monads::Success` +
  a user notice (via the existing `@reporter` seam or a stderr `warn`) so
  `cli/sync.rb` needs NO change and the exit code stays 0 — a skipped overlapping
  run is correct idempotent behavior, not an error (cf. CF5's idempotent
  bootout). If you are convinced `cli/sync.rb` must change, raise it in PHASE 0
  (it is currently MUST-NOT-TOUCH).
- Put the lock mechanism in a new `State::Lock` (`lib/repo_tender/state/lock.rb`)
  with a block API, e.g. `State::Lock.acquire(state_file) { ... }` that flocks
  non-blocking, yields on success, releases in its own `ensure`, and signals
  "not acquired" to the caller (return value / dedicated result — your choice).
  Expose `State::Lock.path_for(state_file)` so tests compute the same path.

The engine already runs the body inside `Sync do |task| ... end` with concurrent
repo/org fan-out (Async::Barrier + Async::Semaphore). The lock is process-level
around the WHOLE run — it MUST NOT serialize that intra-run fan-out. Read
`lib/repo_tender/sync/engine.rb` (esp. `call`, lines 82-150) and
`lib/repo_tender/paths.rb` (`state_file`) before planning. The engine test
harness lives in `test/repo_tender/sync/engine_test.rb` — reuse `with_engine_home
{ |paths, base_dir, state_file| ... }`, `Engine.new(scm:/forge:).call(config:,
paths:)`, the `SlowSCM`/`StubSCM` (note `raise_on:`) doubles, and `StateStore.load`.

=== OUTPUT FORMAT (lane report `docs/lanes/state-hardening-A.md`) ===
Raw only. Tables/numbers/verbatim command output. Sections:
1. PHASE 0 plan + disagreements (each citing real file:line) + flock-semantics
   verification result.
2. What changed, per file (paths + a one-line what; the lock API signature).
3. Gate evidence: GA1 (diff lines showing acquire-before-load / release-after-
   write), GA2 (the no-clobber test + its output), GA3 (release-on-all-paths
   test output for a/b/c), GA4 (G7/G8/G9/G10/GS1/CF3 still green — paste the
   targeted run counts), GA5 (`git status` + `git diff --name-only a1cba9d..`).
4. Verbatim: `bundle exec rake test` summary line, `standardrb` exit,
   `git diff a1cba9d.. -- Gemfile Gemfile.lock repo-tender.gemspec` (must be empty).
5. STATUS line.

=== TOOL GUIDANCE (verification; verify-against-reality) ===
- `bundle install`
- `bundle exec rake test` (full suite — must be >1302 tests, 0/0/0)
- `bundle exec standardrb`
- `bundle exec ruby -Itest test/repo_tender/sync/engine_test.rb`
- `bundle exec ruby -Itest test/repo_tender/state/lock_test.rb` (your new file)
- Verify-against-reality BEFORE coding: `File#flock` LOCK_EX|LOCK_NB return
  value on a held lock (returns `false`, does not block); two `File.open` of the
  same path in one process contend (independent open file descriptions). Write a
  tiny throwaway probe if unsure — do not assume.

=== BOUNDARIES ===
MAY TOUCH (your lane's declared set — nothing else):
- `lib/repo_tender/state/lock.rb`            (NEW)
- `lib/repo_tender/sync/engine.rb`
- `lib/repo_tender.rb`                        (add `require "repo_tender/state/lock"`)
- `test/repo_tender/state/lock_test.rb`       (NEW)
- `test/repo_tender/sync/engine_test.rb`      (ADDITIONS ONLY — do not edit existing test bodies)
- `docs/lanes/state-hardening-A.md`           (your report)

MUST NOT TOUCH (byte-unchanged — other lane / frozen / out of scope):
- `lib/repo_tender/state/store.rb`  ← Lane B owns this
- `test/repo_tender/state/store_test.rb`  ← Lane B owns this
- `lib/repo_tender/cli/sync.rb`, any `cli/*`, `paths.rb`, `scm/*`, `shell.rb`,
  all `ui/*` reporters
- `repo-tender.gemspec`, `Gemfile`, `Gemfile.lock`  (NO new gems — stdlib only)
- anything under `docs/gates/`

OUT OF SCOPE: blocking-lock variants; lockfile GC/unlink; a `--force`/`--wait`
flag; any config field; CF11 (the other lane). No refactors beyond the lock.

=== DISAGREEMENT RULINGS (from last session) === none — fresh slice.

=== ACCEPTANCE GATES (frozen at docs/gates/state-hardening.md — READ-ONLY) ===
G0 (shared), GA1–GA5. Read that file in your worktree; it is authoritative.
