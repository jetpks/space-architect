Think harder. Execute the architect spec below. Operating rules:

PHASE 0 — Before any code: reply with your plan and EVERY disagreement you have
with this spec, with reasons, citing real files in this repo. Silent compliance
is a failure. Silent scope additions are a failure. If you have no
disagreements, state what you checked before concluding the spec is sound.
Verify the named APIs/formats/versions against the live dependencies before
planning around them.

PHASE 1 — There are no shared contracts to freeze in this lane (single file +
its test). The files under docs/gates/ are read-only at all times — editing them
fails the slice regardless of results.

PHASE 2 — Build YOUR LANE ONLY: exactly the files listed in BOUNDARIES. You are
one of three parallel lane agents working in isolated worktrees; files outside
your lane belong to other agents — touching them fails your lane. No placeholder
implementations — search the codebase before implementing; full implementations
only. Verify your work by running the lane's gate commands and record the
verbatim output. Do NOT commit and do NOT run any git write command
(commit/add/branch/reset/checkout) — the architect commits and merges after
verification, and verifies you made no commits. Do NOT delete lock files or
escalate privileges if a command fails; record the exact error and continue.
Give every potentially long command an explicit timeout. When done, write your
lane report to docs/lanes/cf-cleanup-07.md with RAW results only — tables,
numbers, command output — no interpretation. Every status claim must be backed
by a command result from this run. Keep the report compact. End it with exactly
one status line: STATUS: COMPLETE | COMPLETE_WITH_CONCERNS (list them) | BLOCKED
(exact blocker + what you tried). Verdicts belong to the architect and the human.
Persist until your lane is fully handled end-to-end.

=== OBJECTIVE (and why) ===
CF7: make `RepoTender::State::Store.write` crash-safe. Today
`lib/repo_tender/state/store.rb` (the `self.write` method, ~lines 72-79) does a
direct `File.write(path, emit(state))`, which truncates the live `state.yaml`
in place. A SIGINT/crash landing in the kernel mid-`write(2)` can leave a
truncated/corrupt `state.yaml` — the machine-managed state file the whole tool
depends on. This is the project's no-data-loss invariant (see PRD / AGENTS.md)
applied to the state file.

Fix: write the emitted YAML to a sibling temp file in the SAME directory as
`path`, then `File.rename(tmp, path)`. `File.rename` is an atomic same-filesystem
swap on POSIX, so the live file is never opened for truncation — a crash before
the rename leaves the old good `state.yaml` whole. Keep everything else
identical: the `validate` early-return on Failure (no file written), the
`FileUtils.mkdir_p(File.dirname(path))`, the emitted bytes (`emit`), and the
`Success(state)` return. Clean up the temp file if the write/rename fails.

CRITICAL: the temp file MUST live under `File.dirname(path)`, NOT `Dir.tmpdir` —
a cross-device `File.rename` raises `Errno::EXDEV`. Use a unique suffix so
concurrent runs can't collide (e.g. `"#{path}.tmp.#{Process.pid}.#{...}"` or
`Tempfile`/`Dir::Tmpname` rooted at the target dir). Verify the EXDEV/atomicity
behavior against Ruby's `File.rename` docs before coding.

This is HIGH-STAKES (persistence); a fresh architect session will run a
cross-model adversarial diff pass at judgment.

=== OUTPUT FORMAT ===
docs/lanes/cf-cleanup-07.md, compact, RAW only:
- The production diff summary (what changed in store.rb).
- Verbatim output of: `bundle exec rake test`, `bundle exec standardrb`,
  `git diff <freeze>.. -- repo-tender.gemspec Gemfile.lock` (must be empty),
  `git diff <freeze>.. -- test/repo_tender/state/store_test.rb --stat` (prove
  +N/-0 additions-only).
- For each gate G7.0–G7.4: the exact test name(s) / command that proves it and
  the pass/fail line.
- `git status` (proves files ⊆ lane set) and `git log <freeze>..` (must be
  empty — you make no commits).
The freeze commit SHA is 5106b7b881e5c235e51fc69cc173080be341fa0b.

=== TOOL GUIDANCE (verification commands; verify-against-reality list) ===
Per CLAUDE.md / AGENTS.md, use `bundle exec`:
- `bundle exec rake test`              # full suite: failures/errors/skips must be 0
- `bundle exec ruby -Itest test/repo_tender/state/store_test.rb`  # this lane's file
- `bundle exec standardrb`             # lint, exit 0
- `bundle exec standardrb --fix`       # autoformat before reporting done
Verify against reality BEFORE coding:
- `File.rename` atomicity + the `Errno::EXDEV` cross-device behavior (Ruby core
  docs) — this is why the temp must be same-dir.
- Read the existing `store_test.rb` to see the established test style (real
  Tempfile + temp paths, no mocks of the class under test). Match it.

=== BOUNDARIES (may touch / must not touch / out of scope) ===
MAY TOUCH (only these):
- lib/repo_tender/state/store.rb
- test/repo_tender/state/store_test.rb
- docs/lanes/cf-cleanup-07.md   (your report)
MUST NOT TOUCH:
- lib/repo_tender/config/store.rb  (the OTHER store with the same File.write
  pattern — OUT OF SCOPE; leave byte-unchanged)
- any other lib/, test/, bin/, gemspec, Gemfile, Gemfile.lock, docs/gates/*
- any file owned by the other two lanes (shell.rb, sync/engine.rb, their tests)
OUT OF SCOPE: refactors beyond the write mechanism; touching `emit`/`validate`/
`load` logic; fsync/durability beyond rename-atomicity (rename is the gate — do
not over-engineer); changing the public signature or return type of `write`.
No new gems. No placeholders.

=== DISAGREEMENT RULINGS (pre-frozen) ===
- Temp file MUST be same-directory (not Dir.tmpdir) — non-negotiable (EXDEV).
- Test file is ADDITIONS-ONLY: do not edit any existing test body; only add new
  test methods. (Anti-gaming / byte-compat gate G7.3.)
- Do NOT alter the emitted YAML bytes or the validation-failure early-return.

=== ACCEPTANCE GATES (frozen at docs/gates/cf-cleanup.md — read-only) ===
Your gates are the "Lane cf-cleanup-07 — CF7" section of docs/gates/cf-cleanup.md
(G7.0–G7.4) plus the shared verification commands at the top. Read that file;
do not edit it. Summary:
- G7.0 suite + lint + no new gems all green.
- G7.1 mid-write failure leaves the pre-existing state.yaml byte-identical
  (inject a failure before the rename; assert old content intact).
- G7.2 temp is under File.dirname(path), atomic rename, no EXDEV, no stray temp
  file left behind; write into a non-tmpdir directory succeeds with correct bytes.
- G7.3 store_test.rb diff is +N/-0; existing round-trips pass unchanged; emitted
  bytes identical to pre-fix.
- G7.4 scope: only the 3 lane files touched; config/store.rb byte-unchanged; no
  commits; docs/gates/ clean.
