Think harder. Execute the architect spec below. Operating rules:

PHASE 0 — Before any code: reply with your plan and EVERY disagreement you have
with this spec, with reasons, citing real files in this repo. Silent compliance
is a failure. Silent scope additions are a failure. If you have no
disagreements, state what you checked before concluding the spec is sound.
Verify against the live code: confirm `State::Store.update` truly has zero
callers (grep lib/bin/exe/test), and confirm the exact lines of the bare
`rescue` in `State::Store.write` and that an `Interrupt` is NOT a `StandardError`
(so the current `rescue` does not catch it).

PHASE 1 — No new shared contracts to freeze (the gate file is frozen and
READ-ONLY — editing anything under docs/gates/ fails the slice regardless of
results).

PHASE 2 — Build YOUR LANE ONLY: exactly the files listed in BOUNDARIES. You are
one of TWO parallel lane agents in isolated worktrees; the other lane owns
`lib/repo_tender/sync/engine.rb`, the new `lib/repo_tender/state/lock.rb`, and
`lib/repo_tender.rb` — touching them fails your lane. No placeholder
implementations — search the codebase before implementing; full implementations
only. Verify your work by running the lane's gate commands and record the
verbatim output. Do NOT commit and do NOT run any git write command
(commit/add/branch/reset/checkout/merge/rebase) — the architect commits and
merges after verification, and verifies you made no commits. Do NOT delete lock
files or escalate privileges if a command fails; record the exact error and
continue. Give every potentially long command an explicit timeout. When done,
write your lane report to `docs/lanes/state-hardening-B.md` with RAW results
only — tables, numbers, command output — no interpretation. Every status claim
must be backed by a command result from this run. Keep it compact. End with
exactly one status line:
STATUS: COMPLETE | COMPLETE_WITH_CONCERNS (list them) | BLOCKED (exact blocker +
what you tried). Verdicts belong to the architect and the human. Persist until
your lane is fully handled end-to-end; do not stop at analysis or partial fixes.

=== REPO ROOT (your worktree — use this absolute path for everything) ===
/Users/eric/src/github.com/lemonslut/repo-tender/.architect/wt/state-hardening-B

Work ONLY inside that path. NEVER touch
`/Users/eric/src/github.com/lemonslut/repo-tender` (the main checkout — a
different lane/branch). Run all commands from your worktree root. First, read
`AGENTS.md` (builder standing context — Claude Code does not auto-load it) and
`docs/gates/state-hardening.md` (your frozen gates) in your worktree.

=== OBJECTIVE (and why) ===
Close carry-forward **CF11** — two small fixes to `lib/repo_tender/state/store.rb`,
both about state-write durability:

1. **Temp-orphan on interrupt.** `State::Store.write` (currently lines ~72-86)
   writes a sibling temp file then `File.rename`s it over `state.yaml` (CF7's
   atomic write). Its cleanup is a bare `rescue` (= `rescue StandardError`):
   ```
   begin
     File.write(tmp, emit(state))
     File.rename(tmp, path)
   rescue
     File.delete(tmp) if File.exist?(tmp)
     raise
   end
   ```
   An `Interrupt` (or any non-`StandardError`) landing BETWEEN `File.write(tmp)`
   and `File.rename` is NOT caught by this `rescue`, so the `File.delete(tmp)`
   cleanup is skipped → a harmless `state.yaml.tmp.<pid>` orphan is left behind.
   The live `state.yaml` is uncorrupted (it was never the write target — CF7
   intent intact); this is purely a leftover temp file.

   Fix: clean up the temp on ALL exit paths, not just `StandardError`. Prefer an
   `ensure` that deletes the temp if it still exists (after a successful
   `File.rename` the temp is already gone, so the delete is a safe no-op; on any
   failure — StandardError OR Interrupt — it removes the orphan). The original
   exception MUST still propagate (cleanup must not swallow it). Keep the
   same-dir-temp + `File.rename` atomicity exactly as CF7 left it.

2. **Dead code.** `State::Store.update` (currently lines ~88-92) has ZERO callers
   anywhere (lib/bin/exe/test) — confirm with grep, then delete it.

Read `lib/repo_tender/state/store.rb` in full and its test
`test/repo_tender/state/store_test.rb` (the CF7 atomic-write tests incl. the
ENOSPC mid-write injection) before planning. Reuse the existing test idioms
(real temp dirs, real files, no mocks of `Store`).

=== OUTPUT FORMAT (lane report `docs/lanes/state-hardening-B.md`) ===
Raw only. Sections:
1. PHASE 0 plan + disagreements + the grep proving `State::Store.update` has
   zero callers + confirmation `Interrupt < Exception` (not StandardError).
2. What changed (the `write` cleanup diff; the `update` deletion).
3. Gate evidence: GB1 (the Interrupt-injection test + output, AND a run of that
   same test against the UNMODIFIED freeze-state `write` showing it FAILS the
   no-orphan assertion — to prove the test distinguishes the fix; describe how
   you produced that red baseline, e.g. `git stash`-free by temporarily reverting
   in-memory or by reasoning — do NOT use git write commands; if you cannot
   produce the red baseline without git, state exactly why and assert it
   analytically), GB2 (grep output + the deletion), GB3 (`git diff a1cba9d.. --
   test/repo_tender/state/store_test.rb` is +N/−0; CF7 tests still green).
4. Verbatim: `bundle exec rake test` summary line, `standardrb` exit,
   `git diff a1cba9d.. -- Gemfile Gemfile.lock repo-tender.gemspec` (must be empty).
5. STATUS line.

Note on the GB1 red baseline: you may NOT run git write commands. To show the
current code fails, the cleanest path is a focused unit test that stubs
`File.rename` to raise `Interrupt` and asserts no `*.tmp.*` remains; reason about
(and state) why the current bare `rescue` leaves the orphan. If you can
temporarily exhibit the failure WITHOUT any git command (e.g. a second test that
inlines the OLD begin/rescue logic in the test file and shows it orphans), do so;
otherwise assert it analytically with the line citation. Do not contort the repo.

=== TOOL GUIDANCE (verification) ===
- `bundle install`
- `bundle exec rake test` (full suite — >1302 tests, 0/0/0)
- `bundle exec standardrb`
- `bundle exec ruby -Itest test/repo_tender/state/store_test.rb`
- `grep -rn "Store\.update\|\.update(" lib bin exe test` (confirm zero State::Store callers)

=== BOUNDARIES ===
MAY TOUCH (your lane's declared set — nothing else):
- `lib/repo_tender/state/store.rb`
- `test/repo_tender/state/store_test.rb`     (ADDITIONS ONLY — do not edit existing test bodies)
- `docs/lanes/state-hardening-B.md`          (your report)

MUST NOT TOUCH (byte-unchanged — other lane / frozen / out of scope):
- `lib/repo_tender/sync/engine.rb`, `lib/repo_tender/state/lock.rb`,
  `lib/repo_tender.rb`  ← Lane A owns these
- everything else under `lib/`, `cli/`, `scm/`, `ui/`
- `repo-tender.gemspec`, `Gemfile`, `Gemfile.lock`  (NO gem changes)
- anything under `docs/gates/`

OUT OF SCOPE: the inter-process lock (CF10, the other lane); any change to the
atomic-write mechanism itself beyond the temp-cleanup path; new state schema
fields; refactors beyond these two fixes.

=== DISAGREEMENT RULINGS (from last session) === none — fresh slice.

=== ACCEPTANCE GATES (frozen at docs/gates/state-hardening.md — READ-ONLY) ===
G0 (shared), GB1–GB4. Read that file in your worktree; it is authoritative.
