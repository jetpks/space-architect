Think hard. Execute the architect spec below. Operating rules:

PHASE 0 — Before any code: reply with your plan and EVERY disagreement you have
with this spec, with reasons, citing real files in this repo. Silent compliance
is a failure. Silent scope additions are a failure. If you have no
disagreements, state what you checked before concluding the spec is sound.
Verify the named APIs/formats/versions against the live dependencies before
planning around them.

PHASE 1 — There are no shared contracts to freeze in this lane (single file +
its test). The files under docs/gates/ are read-only at all times — editing them
fails the slice regardless of results.

PHASE 2 — Build YOUR LANE ONLY: exactly the files listed in BOUNDARIES. You are
one of three parallel lane agents working in isolated worktrees; files outside
your lane belong to other agents — touching them fails your lane. No placeholder
implementations — search the codebase before implementing; full implementations
only. Verify your work by running the lane's gate commands and record the
verbatim output. Do NOT commit and do NOT run any git write command
(commit/add/branch/reset/checkout) — the architect commits and merges after
verification, and verifies you made no commits. Do NOT delete lock files or
escalate privileges if a command fails; record the exact error and continue.
Give every potentially long command an explicit timeout. When done, write your
lane report to docs/lanes/cf-cleanup-08.md with RAW results only — tables,
numbers, command output — no interpretation. Every status claim must be backed
by a command result from this run. Keep the report compact. End it with exactly
one status line: STATUS: COMPLETE | COMPLETE_WITH_CONCERNS (list them) | BLOCKED
(exact blocker + what you tried). Verdicts belong to the architect and the human.
Persist until your lane is fully handled end-to-end.

=== OBJECTIVE (and why) ===
CF8: make `Shell.run`'s `Thread.report_on_exception` suppression
concurrency-safe. In `lib/repo_tender/shell.rb` (~lines 59-69) `Shell.run`
brackets `Open3.capture3` with a save/restore of the PROCESS-GLOBAL
`Thread.report_on_exception = false` (to silence the Open3 reader-thread
`IOError: stream closed in another thread` noise on ^C — the Slice-6 G3 fix).
But `Shell.run` runs CONCURRENTLY under `Sync{}`: fibers interleave at
`Open3.capture3`'s internal thread-join. With overlapping runs, the inner
fiber's `ensure` restores a `prev` that was already `false`, so after the runs
unwind the global is **left `false`** — a leak (architect empirically confirmed
with 8 overlapping runs). Benign in repo-tender's one-shot/launchd lifecycle but
a real robustness wart.

Fix: REFCOUNT the active `Shell.run` calls. Maintain a class-level counter and a
saved-original slot on `Shell`. On the 0→1 transition: capture
`Thread.report_on_exception` into the saved slot and set it `false`. Increment.
On exit (in `ensure`): decrement; on the 1→0 transition restore the saved
original. Net effect: the global is `false` while ANY `Shell.run` is in flight,
and restored to the original only when the LAST one exits — no leak, suppression
still total during overlap. Keep `Shell.run`'s signature, the
ambient-`Async::Task` guard, the `full_env`/`opts` handling, and the
Success/Failure return EXACTLY as they are.

MANDATED APPROACH (do not deviate): the refcount lives INSIDE `Shell.run`. The
reactor is single-threaded — `lib/` spawns no app threads (see the existing
comment block at shell.rb ~lines 42-56 enumerating every thread in flight), and
Async hosts one reactor per thread — so a plain class-ivar counter mutated only
between fiber yield points is fiber-safe WITHOUT a Mutex. You MAY use a Mutex
only if you justify it against the actual concurrency model in PHASE 0; do not
assume thread parallelism that does not exist here. Verify the single-reactor /
fiber-cooperative model against the socketry/async checkout at
~/src/evergreen/github.com/socketry/async if unsure.

=== OUTPUT FORMAT ===
docs/lanes/cf-cleanup-08.md, compact, RAW only:
- The production diff summary (what changed in shell.rb).
- Verbatim output of: `bundle exec rake test`, `bundle exec standardrb`,
  `git diff <freeze>.. -- repo-tender.gemspec Gemfile.lock` (must be empty),
  `git diff <freeze>.. -- test/repo_tender/shell_test.rb --stat` (prove +N/-0).
- For each gate G8.0–G8.4: the exact test name(s)/command proving it + pass/fail.
- `git status` and `git log <freeze>..` (must be empty).
The freeze commit SHA is 5106b7b881e5c235e51fc69cc173080be341fa0b.

=== TOOL GUIDANCE (verification commands; verify-against-reality list) ===
Per CLAUDE.md / AGENTS.md, use `bundle exec`:
- `bundle exec rake test`
- `bundle exec ruby -Itest test/repo_tender/shell_test.rb`   # this lane's file
- `bundle exec standardrb` / `bundle exec standardrb --fix`
Verify against reality BEFORE coding:
- The existing two report_on_exception tests in shell_test.rb (they shim
  `Open3.capture3` to observe the flag during the call and assert restoration
  after). Your fix MUST keep them passing UNCHANGED. Read them first.
- The single-reactor / one-thread-per-reactor fiber model in socketry/async
  (evergreen checkout) — this is the justification for a Mutex-free counter.
- Class-ivar state under `# frozen_string_literal: true` (the literal freeze
  does not freeze class ivars; confirm).

=== BOUNDARIES (may touch / must not touch / out of scope) ===
MAY TOUCH (only these):
- lib/repo_tender/shell.rb
- test/repo_tender/shell_test.rb
- docs/lanes/cf-cleanup-08.md   (your report)
MUST NOT TOUCH:
- any CLI entrypoint, bin/repo-tender, lib/repo_tender/cli*, or any startup path
  (the "set false once at startup" alternative is REJECTED — out of scope)
- any other lib/, test/, gemspec, Gemfile, Gemfile.lock, docs/gates/*
- files owned by the other two lanes (state/store.rb, sync/engine.rb, their tests)
OUT OF SCOPE: changing the Open3 call shape, the env/chdir handling, the ambient
task guard, or the Result return; the set-once-at-startup approach. No new gems.
No placeholders.

=== DISAGREEMENT RULINGS (pre-frozen) ===
- Refcount-inside-Shell.run is mandated; set-once-at-startup is REJECTED (it
  touches an entrypoint out of this lane and mutates a process-global for library
  consumers — repo-tender ships as a gem).
- Test file is ADDITIONS-ONLY: do not edit the two existing report_on_exception
  tests or any other existing test body; only add new test methods.

=== ACCEPTANCE GATES (frozen at docs/gates/cf-cleanup.md — read-only) ===
Your gates are the "Lane cf-cleanup-08 — CF8" section of docs/gates/cf-cleanup.md
(G8.0–G8.4) plus the shared commands at the top. Read that file; do not edit it.
Summary:
- G8.0 suite + lint + no new gems green.
- G8.1 the two existing report_on_exception tests pass UNCHANGED; shell_test.rb
  diff is +N/-0; single-call during=false, after=restored-to-pre (incl. raise).
- G8.2 with report_on_exception=true beforehand, ≥2 genuinely overlapping
  Shell.run in one Sync{}/Barrier, then assert the global == true afterward
  (no leaked false).
- G8.3 during overlap (≥2 active) the global is observed false (G3 suppression
  intact) — may fold into G8.2's test.
- G8.4 scope: only the 3 lane files; no entrypoint/bin/cli; no commits; gates clean.
