#!/usr/bin/env ruby
# frozen_string_literal: true
# GC3 empirical liveness repro — real git repos, real SCM, InteractiveReporter.
# Runs from repo-tender root: ruby -Ilib .architect/gc3_liveness_repro.rb
#
# Creates 20 real bare+clone git pairs, seeds commits on each,
# then runs the sync engine with InteractiveReporter (writing to a file).
# Analyzes whether the live counter (@finished) shows intermediate values
# across render ticks during the run.

require "tmpdir"
require "fileutils"
require "async"
require "stringio"
require "repo_tender"

include RepoTender

N_REPOS = 20
CONCURRENCY = 4

# Spy reporter that wraps the real InteractiveReporter and records
# (timestamp, @finished) at each render_tick so we can detect intermediate values.
class SpyReporter < UI::InteractiveReporter
  attr_reader :tick_log

  def initialize(out, mode:, cadence: 0.05)
    super
    @tick_log = []
  end

  private

  def render_tick
    @tick_log << [Process.clock_gettime(Process::CLOCK_MONOTONIC), @finished]
    super
  end
end

Dir.mktmpdir("gc3-repro-") do |dir|
  base_dir = File.join(dir, "repos")
  FileUtils.mkdir_p(base_dir)

  repo_refs = []

  puts "=== Creating #{N_REPOS} real git repos ==="
  N_REPOS.times do |i|
    host = "example.com"
    owner = "gc3"
    name = "repo-#{i}"
    bare = File.join(dir, "bare", "#{name}.git")
    clone = File.join(base_dir, host, owner, name)
    FileUtils.mkdir_p(bare)
    FileUtils.mkdir_p(clone)

    system("git", "init", "-b", "main", "--bare", bare, exception: true, out: File::NULL, err: File::NULL)
    system("git", "-c", "init.defaultBranch=main", "init", "-q", clone, exception: true, out: File::NULL)
    system("git", "-C", clone, "config", "user.email", "gc3@test.com", exception: true, out: File::NULL)
    system("git", "-C", clone, "config", "user.name", "GC3", exception: true, out: File::NULL)
    system("git", "-C", clone, "remote", "add", "origin", bare, exception: true, out: File::NULL)
    File.write(File.join(clone, "README.md"), "repo #{i}")
    system("git", "-C", clone, "add", ".", exception: true, out: File::NULL)
    system("git", "-C", clone, "commit", "-qm", "init", exception: true, out: File::NULL)
    system("git", "-C", clone, "push", "-q", "-u", "origin", "main", exception: true, out: File::NULL)

    # Add a commit to the bare remote so clones need to fast-forward
    system("git", "-C", clone, "commit", "--allow-empty", "-qm", "upstream", exception: true, out: File::NULL)
    system("git", "-C", clone, "push", "-q", "origin", "main", exception: true, out: File::NULL)
    system("git", "-C", clone, "reset", "--hard", "HEAD~1", exception: true, out: File::NULL, err: File::NULL)

    repo_refs << Config::RepoRef.new(host: host, owner: owner, name: name)
  end
  puts "Done creating repos."

  config = Config::Config.new(
    base_dir: base_dir,
    refresh_interval: 1,
    concurrency: CONCURRENCY,
    repos: repo_refs,
    orgs: []
  )

  out = StringIO.new
  mode = UI::Mode.new(color: false, animate: true, quiet: false, format: :pretty)
  reporter = SpyReporter.new(out, mode: mode, cadence: 0.05)

  state_dir = File.join(dir, "state")
  FileUtils.mkdir_p(state_dir)
  state_file = File.join(state_dir, "state.yaml")
  paths = Paths.new(environment: {
    "HOME" => dir,
    "XDG_CONFIG_HOME" => File.join(dir, ".config"),
    "XDG_STATE_HOME" => File.join(dir, ".local", "state"),
    "XDG_CACHE_HOME" => File.join(dir, ".cache")
  }, base_dir: base_dir)
  FileUtils.mkdir_p(File.join(dir, ".local", "state", "repo-tender"))

  t0 = Process.clock_gettime(Process::CLOCK_MONOTONIC)
  engine = Sync::Engine.new(reporter: reporter)
  result = engine.call(config: config, paths: paths)
  t_total = Process.clock_gettime(Process::CLOCK_MONOTONIC) - t0

  puts "=== GC3 Liveness Results ==="
  puts "Total time: #{(t_total * 1000).round}ms, N=#{N_REPOS}, concurrency=#{CONCURRENCY}"
  puts "Render ticks recorded: #{reporter.tick_log.size}"
  if reporter.tick_log.empty?
    puts "BLOCKED: No render ticks observed at all."
  else
    finished_values = reporter.tick_log.map { |_, f| f }.uniq
    puts "Observed @finished values across ticks: #{finished_values.inspect}"
    intermediate = finished_values.any? { |x| x > 0 && x < N_REPOS }
    puts "Intermediate values (> 0 and < #{N_REPOS}): #{intermediate ? "YES" : "NO"}"
    if intermediate
      puts "GC3 LIVENESS: PASS — counter advanced during the run"
    else
      puts "GC3 LIVENESS: BLOCKED — counter only showed 0 → #{N_REPOS} (no intermediate ticks)"
    end
  end
  puts "Engine result: #{result.success? ? "SUCCESS" : "FAILURE: #{result.failure}"}"
end
