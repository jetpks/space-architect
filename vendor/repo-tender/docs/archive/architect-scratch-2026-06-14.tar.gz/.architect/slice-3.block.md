Execute the architect spec below. Operating rules:

PHASE 0 — Before any code: reply with your plan and EVERY disagreement you have
with this spec, with reasons, citing real files in this repo. Silent compliance
is a failure. Silent scope additions are a failure. If you have no
disagreements, state what you checked before concluding the spec is sound.
Verify the named APIs/formats/versions against the live dependencies before
planning around them (in particular: read the installed dry-cli gem source and
confirm the nested-subcommand registration + option/argument API before building
on it).

PHASE 1 — Freeze shared contracts first (here: the CLI command surface +
exit-code seam + the Config::Duration parser interface). After you decide them in
your plan they are stable for the rest of the run. The files under docs/gates/
are read-only at all times — editing them fails the slice regardless of results.

PHASE 2 — Build exactly the files listed in BOUNDARIES. No placeholder
implementations — search the codebase before implementing; full implementations
only. Reuse the Slice 1 test helpers (with_temp_home, with_paths, with_trunk_repo,
seed_initial_commit in test/test_helper.rb) and the existing Result idioms
(boundaries return dry-monads Result; see lib/repo_tender/config/store.rb and
sync/engine.rb). Verify your work by running the gate commands and record the
verbatim output. Do NOT commit and do NOT run any git write command
(commit/add/branch/reset/checkout) — the architect commits and merges after
verification, and verifies you made no commits. Do NOT delete lock files or
escalate privileges if a command fails; record the exact error and continue.
Give every potentially long command an explicit timeout. When done, write your
lane report to docs/lanes/slice-3-01.md with RAW results only — tables, numbers,
command output — no interpretation. Every status claim must be backed by a
command result from this run. Keep it compact. End it with exactly one status
line: STATUS: COMPLETE | COMPLETE_WITH_CONCERNS (list them) | BLOCKED (exact
blocker + what you tried). Verdicts belong to the architect and the human.
Persist until the slice is fully handled end-to-end; do not stop at analysis or
partial fixes.

=== OBJECTIVE (and why) ===

Build the CLI surface for repo-tender (PRD §5 Slice 3) so a user can manage
durable config and drive a sync run from the terminal. This is the third slice
of a hard dependency chain (Foundation → Sync engine → CLI → launchd); Slices 1
and 2 are merged and green. The CLI is a thin translation layer: parse argv →
load/mutate validated config OR delegate to the already-built, already-judged
Sync::Engine / State::Store → render output / set exit code. It must NEVER
mutate a git repo directly — repo mutation only happens inside the engine, which
already upholds the no-data-loss invariant (PRD §1).

Commands (PRD §5 Slice 3):
  repo add|remove|list · org add|remove|list · sync [--repo …] · status ·
  config path|show

Also land CF1 (carry-forward from Slice 1): a hand-editable config.yaml may write
refresh_interval as a human duration ("6h", "90m") per PRD §3.1. Today the
loader requires an integer and would reject "6h". Add a Config::Duration parser
applied in Config::Store.load BEFORE contract validation, so a hand-edited "6h"
loads as 21600 integer seconds. The contract and model stay integer-typed; this
is a load-layer normalization only.

The full, authoritative acceptance criteria are the frozen gates in
docs/gates/slice-3.md (G0–G9). Read that file first — it is the contract. Also
read PRD §3.1 (config schema), §3.2 (state schema), §5 Slice 3, and §7 (DoD).

=== OUTPUT FORMAT (docs/lanes/slice-3-01.md) ===

1. PHASE 0 — plan (one paragraph) + disagreement table (your position · spec
   position · cited file · reason) + the PHASE-0 rulings you made (dry-cli API,
   exit-code seam, --repo scoping, CF1 normalization point), each with the file
   you read to decide it.
2. Gate → test mapping table: each gate (G0–G9) → test file + test name(s).
3. Verbatim command output: `bundle install` tail, full `bundle exec rake test`
   summary line, `bundle exec standardrb`, and `ruby -Ilib bin/repo-tender
   --help` (or version) output. Include any subprocess exit-code proof for G3.
4. Final tree of files created/modified + `git status --porcelain=v2
   --untracked-files=normal` at end of run (the G9 scope check).
5. Notes on documented limitations / design choices (e.g. human-duration strings
   not preserved on write-back; exit-code seam chosen).

=== TOOL GUIDANCE (verification commands; verify-against-reality list) ===

Build & test (from AGENTS.md):
  bundle install
  bundle exec rake test                                   # full suite, minitest
  bundle exec ruby -Itest test/repo_tender/cli/<x>_test.rb   # single file
  bundle exec standardrb                                  # lint/format check
  bundle exec standardrb --fix                            # autofix
  ruby -Ilib bin/repo-tender --help                       # run the binary

Verify against the live dependencies BEFORE planning around them:
- dry-cli (~> 1.4): read the installed gem source for the Registry/register API
  (nested subcommands), `argument`/`option` declaration, and how `call(**opts)`
  receives parsed args + how stdout/`out:`/`err:` are injected for tests. Cite
  the path you read (under …/gems/dry-cli-*/lib).
- dry-monads result idioms already used here: lib/repo_tender/config/store.rb
  (load/write/with/update), lib/repo_tender/state/store.rb (load/write), and
  sync/engine.rb (Engine.new(...).call(config:, paths:) → Result<State>).
- Config schema + defaults: lib/repo_tender/config/model.rb,
  lib/repo_tender/config/contract.rb (refresh_interval is :integer, gt?: 0 —
  keep it that way; CF1 normalizes the string to int before this runs).
- Paths: lib/repo_tender/paths.rb (config_file, state_file, base_dir; honors
  $XDG_CONFIG_HOME / $XDG_STATE_HOME via an injectable environment hash).
- Test harness: test/test_helper.rb (with_temp_home, with_paths(base_dir:),
  with_trunk_repo, seed_initial_commit, in_async). Reuse these — do not mock
  Config::Store / State::Store / the engine.

=== BOUNDARIES (may touch / must not touch / out of scope) ===

MAY CREATE:
  lib/repo_tender/cli.rb
  lib/repo_tender/cli/repo.rb
  lib/repo_tender/cli/org.rb
  lib/repo_tender/cli/sync.rb
  lib/repo_tender/cli/status.rb
  lib/repo_tender/cli/config.rb
  lib/repo_tender/config/duration.rb
  bin/repo-tender                       (chmod +x; shebang; requires lib + runs CLI)
  test/repo_tender/cli/repo_test.rb
  test/repo_tender/cli/org_test.rb
  test/repo_tender/cli/sync_test.rb
  test/repo_tender/cli/status_test.rb
  test/repo_tender/cli/config_test.rb
  test/repo_tender/config/duration_test.rb
  docs/lanes/slice-3-01.md

MAY EDIT (narrowly, only as the spec describes):
  lib/repo_tender/config/store.rb       (CF1: normalize refresh_interval through
                                         Config::Duration in load, before Contract)
  lib/repo_tender.rb                     (add requires for the new files)
  repo-tender.gemspec                    (register executable: bindir/executables +
                                          add bin/** to spec.files; NO dep changes)

MUST NOT TOUCH (failing the lane):
  lib/repo_tender/sync/engine.rb, lib/repo_tender/sync/repo_plan.rb
    (--repo scoping = CLI builds a filtered Config and calls the UNCHANGED engine)
  lib/repo_tender/state/store.rb         (status only READS it; CF3 is deferred)
  lib/repo_tender/scm/*, lib/repo_tender/forge/*, lib/repo_tender/paths.rb
  lib/repo_tender/config/model.rb, lib/repo_tender/config/contract.rb
    (refresh_interval stays integer-typed; CF1 is load-layer normalization)
  test/test_helper.rb
  anything under docs/gates/

OUT OF SCOPE (do not build now): launchd/* , cli/daemon (that is Slice 4),
log rotation, any non-GitHub forge, any new gem.

If the spec forces you toward a MUST-NOT-TOUCH file to satisfy a gate, STOP and
record it as a disagreement with the cited gate + file — do not edit it silently.
