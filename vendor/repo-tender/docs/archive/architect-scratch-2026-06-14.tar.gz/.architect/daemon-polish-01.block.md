Execute the architect spec below. Operating rules:

PHASE 0 — Before any code: reply with your plan and EVERY disagreement you have
with this spec, with reasons, citing real files in this repo. Silent compliance
is a failure. Silent scope additions are a failure. If you have no disagreements,
state what you checked before concluding the spec is sound. Verify the named
APIs/formats/versions against the live dependencies before planning around them
(here: confirm the `launchctl bootout` not-loaded exit status / stderr against
`man launchctl` or `launchctl help` — do NOT run a real `bootout` against the
live `gui/<UID>` domain).

PHASE 1 — There are no NEW shared contracts to freeze in this slice (you extend
existing classes). The files under docs/gates/ are read-only at all times —
editing them fails the slice regardless of results. The existing public argv of
`Launchd::Agent` is a frozen contract from Slice 4 (see the spec's argv-stability
constraint): do not change it.

PHASE 2 — Build YOUR LANE ONLY: exactly the files listed in BOUNDARIES. No
placeholder implementations — search the codebase before implementing; full
implementations only. Verify your work by running the lane's gate commands and
record the verbatim output. Do NOT commit and do NOT run any git write command
(commit/add/branch/reset/checkout) — the architect commits and merges after
verification, and verifies you made no commits. Do NOT delete lock files or
escalate privileges if a command fails; record the exact error and continue. Give
every potentially long command an explicit timeout (e.g. `timeout 300 bundle exec
rake test`); if a runtime will not start unattended, record the exact failure in
your lane report and route around it — never busy-wait or retry in a loop. When
done, write your lane report to docs/lanes/daemon-polish-01.md with RAW results
only — tables, numbers, command output — no interpretation. Every status claim
must be backed by a command result from this run. Keep it compact. End it with
exactly one status line: STATUS: COMPLETE | COMPLETE_WITH_CONCERNS (list them) |
BLOCKED (exact blocker + what you tried). Verdicts belong to the architect.
Persist until your lane is fully handled end-to-end; do not stop at analysis or
partial fixes.

=== OBJECTIVE (and why) ===

Two carry-forward fixes from the Slice 4 manual checklist + adversarial review.
The launchd daemon works (Slice 4 merged, human-verified live), but two rough
edges remain:

CF5 — `daemon stop` / `daemon uninstall` are not idempotent when the agent is
already not loaded. At a 6h refresh interval the agent is usually NOT currently
running, so `launchctl bootout gui/<UID>/<label>` returns a non-zero exit
(status 3, "Boot-out failed: 3: No such process"). Today `Launchd::Agent#stop`
short-circuits on that bootout Failure and the `Daemon::Stop` command exits 1 —
WRONG, stopping an already-stopped job should be idempotent success. And
`Daemon::Uninstall` prints a `bootout reported: ...` error line to stderr every
time (noise; uninstall already exits 0 + removes the plist). Fix: treat a
not-loaded `bootout` (launchctl status 3, or stderr matching "No such process" /
"Could not find specified service") as already-not-loaded SUCCESS in `stop` and
`uninstall` only. Bootstrap failures (install/start) are UNAFFECTED — status 3
on `bootstrap` is still a real Failure.

CF6 — `cli/sync.rb` `rotate_plist_logs` does `Integer(ENV["REPO_TENDER_LOG_MAX_BYTES"]
|| DEFAULT_LOG_MAX_BYTES)` with no rescue. A malformed operator value (e.g.
"10MB") raises ArgumentError and crashes the ENTIRE sync run before any repo
work. Fix: parse the env var defensively — valid positive integer wins; anything
else (unset/empty/non-numeric/non-positive) falls back to the 10 MiB default
(optionally warn to stderr). Do not crash sync.

Why now: both are non-blocking but user-facing; folding them together keeps the
daemon surface clean before the project is called done.

=== OUTPUT FORMAT (docs/lanes/daemon-polish-01.md) ===

Compact, raw. Include: (1) PHASE 0 plan + disagreement table (with file:line
cites) + your PHASE-0 rulings; (2) a gate→test mapping table (each gate G0–G5 →
test file + exact test name(s)); (3) verbatim command output for `bundle install`
(tail), `bundle exec rake test` (the final counts line), `bundle exec standardrb`
(exit), `ruby -Ilib bin/repo-tender --help` (showing daemon group); (4) the
before/after of the CF5 predicate and the CF6 parse helper (small code excerpts);
(5) `git status --porcelain=v2` showing only in-scope files changed, and
confirmation you made no commits (`git log <freeze>..` empty). End with the single
STATUS line.

=== TOOL GUIDANCE (verification commands; verify-against-reality list) ===

- Toolchain + commands are in AGENTS.md (ruby 4.0.5 via mise; `bundle exec rake
  test`, `bundle exec standardrb`, single file `bundle exec ruby -Itest <file>`).
- Run the full suite AND the touched files in isolation:
  `timeout 300 bundle exec rake test`
  `bundle exec ruby -Itest test/repo_tender/launchd/agent_test.rb`
  `bundle exec ruby -Itest test/repo_tender/cli/daemon_test.rb`
  `bundle exec ruby -Itest test/repo_tender/cli/sync_test.rb`
- VERIFY AGAINST REALITY before coding:
  * `launchctl bootout` not-loaded status/stderr — from `man launchctl` /
    `launchctl help` (do NOT bootout the real domain). The manual checklist
    already observed "Boot-out failed: 3: No such process" (status 3).
  * Read `lib/repo_tender/launchd/agent.rb` (the `run`/`stop`/`uninstall` seam,
    the `ShellRunner`, the Failure shape `{argv:, stderr:, status:}`),
    `lib/repo_tender/cli/daemon.rb` (`Stop`/`Uninstall` commands + `make_agent`
    factory), and `lib/repo_tender/cli/sync.rb` (`rotate_plist_logs` +
    `DEFAULT_LOG_MAX_BYTES`). Search before implementing.
  * The test seams: `RecordingRunner` in `test/repo_tender/launchd/agent_test.rb`
    (records argv, returns canned Success/Failure at the launchctl seam);
    `stub_agent` + CLI env/temp-HOME helpers in
    `test/repo_tender/cli/daemon_test.rb`; `with_engine_home_2_repos` +
    `invoke_command(Sync::Run)` in `test/repo_tender/cli/sync_test.rb`.

CRITICAL (G1/G2 anti-tautology — this is the lesson from Slice 4's G2 bug): the
status-3 bootout Failure MUST enter through the RUNNER SEAM on a REAL
`Launchd::Agent` (a RecordingRunner returning the status-3 Failure for the
bootout call), so the real benign-bootout mapping is what produces the exit-0
result. Do NOT write a G1/G2 test that fully stubs the Agent class and hand-sets
`stop_result: Success(...)` — that asserts a tautology and proves nothing. For
the CLI commands, inject a real `Agent.new(runner: recording_runner, ...)` via
the test's Agent factory seam (stub the FACTORY, keep the real Agent class).

=== BOUNDARIES (may touch / must not touch / out of scope) ===

MAY TOUCH (your lane):
- lib/repo_tender/launchd/agent.rb        (CF5: benign-bootout mapping in stop/uninstall)
- lib/repo_tender/cli/daemon.rb           (CF5: Stop/Uninstall command cleanup)
- lib/repo_tender/cli/sync.rb             (CF6: REPO_TENDER_LOG_MAX_BYTES parse hardening)
- test/repo_tender/launchd/agent_test.rb  (CF5 unit tests)
- test/repo_tender/cli/daemon_test.rb     (CF5 CLI tests)
- test/repo_tender/cli/sync_test.rb       (CF6 tests)
- docs/lanes/daemon-polish-01.md          (your report)

MUST NOT TOUCH: lib/repo_tender/state/store.rb, lib/repo_tender/sync/engine.rb,
lib/repo_tender/sync/repo_plan.rb, lib/repo_tender/launchd/plist.rb,
lib/repo_tender/log_rotator.rb, lib/repo_tender/paths.rb, lib/repo_tender/cli.rb,
lib/repo_tender.rb, scm/*, forge/*, config/*, cli/{repo,org,status,config}.rb,
test/test_helper.rb, any *_helper.rb, anything under docs/gates/.

OUT OF SCOPE: changing the launchctl argv for ANY op (install/uninstall/start/
stop/restart/status argv is frozen from Slice 4 — you only change how a bootout
Failure is INTERPRETED); adding config fields; adding gems; touching the plist or
log_rotator internals (LogRotator's injected-threshold contract stays). All
existing argv assertions in agent_test.rb / daemon_test.rb must stay green
UNMODIFIED.

=== DISAGREEMENT RULINGS (from last session) ===

N/A — first dispatch of this slice. Raise your own in PHASE 0.

=== ACCEPTANCE GATES (frozen at docs/gates/daemon-polish.md — read-only) ===

The full gate text is in docs/gates/daemon-polish.md (G0–G5). Read it. Do not
edit it. Summary: G0 suite/lint/bundle green + no new gems + --help lists daemon;
G1 `daemon stop` idempotent (exit 0, no stderr) on a status-3 bootout via the real
Agent+runner seam, real failures still exit 1; G2 `daemon uninstall` idempotent +
quiet under a temp HOME; G3 Agent unit — benign bootout (status 3 OR stderr
match) → Success in stop/uninstall, non-benign still Failure, bootstrap status-3
still Failure; G4 malformed REPO_TENDER_LOG_MAX_BYTES falls back to 10 MiB default
and never raises, sync still exits 0; G5 only in-scope files, no commits.
