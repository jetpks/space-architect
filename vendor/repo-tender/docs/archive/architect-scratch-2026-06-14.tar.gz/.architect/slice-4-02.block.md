Execute the architect spec below. Operating rules:

PHASE 0 — Before any code: reply with your plan and EVERY disagreement you have
with this spec, with reasons, citing real files in this repo. Silent compliance
is a failure. Silent scope additions are a failure. If you have no
disagreements, state what you checked before concluding the spec is sound.
Verify the current behavior against the live code BEFORE planning: read
lib/repo_tender/sync/engine.rb `expand_orgs` (≈ lines 121–138) and
`build_new_state` (≈ lines 282–294), and lib/repo_tender/state/store.rb `Org`
(≈ lines 41–52, plus `build_state` and `emit`). Confirm exactly where the
clobber happens before changing it.

PHASE 1 — Freeze the contract first (here: the new State::Store::Org shape with
`last_error`, and the preserve-on-failure rule). After you decide it in your plan
it is stable for the rest of the run. The files under docs/gates/ are read-only at
all times — editing them fails the slice regardless of results.

PHASE 2 — Build YOUR LANE ONLY: exactly the files listed in BOUNDARIES. You are
ONE OF TWO parallel lane agents in isolated worktrees; Lane 01 owns launchd/*,
log_rotator.rb, cli/daemon.rb, paths.rb, cli.rb, cli/sync.rb, repo_tender.rb —
touching any of them fails your lane. No placeholder implementations — full
implementations only. Reuse the existing idioms: State::Store value objects are
`Data.define` with keyword defaults + `to_h_compact` (.compact drops nils); the
store round-trips through real YAML on disk (see lib/repo_tender/state/store.rb).
Tests use real temp state via test/test_helper.rb (with_temp_home / with_paths)
and the existing engine test seam (injected forge double) in
test/repo_tender/sync/engine_test.rb — reuse them, do NOT mock the store or the
engine itself. Verify your work by running the gate commands and record the
verbatim output. Do NOT commit and do NOT run any git write command
(commit/add/branch/reset/checkout) — the architect commits and merges after
verification, and verifies you made no commits. Do NOT delete lock files or
escalate privileges if a command fails; record the exact error and continue. Give
every potentially long command an explicit timeout. When done, write your lane
report to docs/lanes/slice-4-02.md with RAW results only — tables, numbers,
command output — no interpretation. Every status claim must be backed by a command
result from this run. Keep it compact. End it with exactly one status line:
STATUS: COMPLETE | COMPLETE_WITH_CONCERNS (list them) | BLOCKED (exact blocker +
what you tried). Verdicts belong to the architect and the human. Persist until
your lane is fully handled end-to-end; do not stop at analysis or partial fixes.

=== OBJECTIVE (and why) ===

Land CF3 (carry-forward from Slice 2 disagreement #5): make org-list failures
non-destructive in machine state. Today, when `Forge#list_org` returns a Failure
during a sync run, the engine records the org as `Org(last_listed_at: nil,
repo_count: 0)` and `build_new_state` merges that over the prior good record —
clobbering a previously-known `repo_count`/`last_listed_at` with nil/0 on a
transient network blip. The `Org` struct also has no field to carry WHY it failed.

This is the no-data-loss invariant (PRD §1) applied to org state. Two parts:
  Part 1 — add a `last_error` (text) field to State::Store::Org (round-trips
           through state.yaml; omitted when nil).
  Part 2 — on an org-list Failure, PRESERVE the prior good `repo_count` +
           `last_listed_at` and set `last_error`, instead of overwriting with
           nil/0. A transient failure must never reduce known-good org state.

Previously-discovered repos are already preserved (`prev.repos.dup`) — keep that.
The Slice 2 G10 behavior (run does not abort; failure is recorded; other repos
still process) must stay intact.

The authoritative acceptance criteria are the frozen gates in
docs/gates/slice-4.md (G6, G7, and G0/G8 cross-lane). Read that file first. Also
read PRD §3.2 (state schema) and the Slice 2 disagreement #5 ruling + CF3 row in
docs/HANDOFF.md for the precise intent.

=== OUTPUT FORMAT (docs/lanes/slice-4-02.md) ===

1. PHASE 0 — plan (one paragraph) + disagreement table (your position · spec
   position · cited file:line · reason) + your ruling on the non-clobber point
   (thread `prev` into expand_orgs vs preserve in build_new_state's merge), citing
   the exact engine lines you change.
2. Gate → test mapping table: G6, G7 → test file + test name(s).
3. Verbatim command output: `bundle install` tail, full `bundle exec rake test`
   summary line, `bundle exec standardrb`, and the specific run of the existing
   Slice 2 G10 org-resilience test showing it still passes.
4. A before/after of the org-Failure state record (repo_count/last_listed_at/
   last_error across run-1-success → run-2-failure) from your G7 test output.
5. Final tree of files modified + `git status --porcelain=v2
   --untracked-files=normal` (the G8 scope check).

=== TOOL GUIDANCE (verification commands; verify-against-reality list) ===

Build & test (from AGENTS.md):
  bundle install
  bundle exec rake test                                          # full suite
  bundle exec ruby -Itest test/repo_tender/state/store_test.rb   # single file
  bundle exec ruby -Itest test/repo_tender/sync/engine_test.rb   # single file
  bundle exec standardrb

Verify against reality BEFORE planning:
- lib/repo_tender/state/store.rb — `Org = Data.define(:last_listed_at,
  :repo_count)` + `to_h_compact` (≈41–52), `build_state` orgs branch (≈101–106),
  `emit` (≈117–123). Add `last_error` consistently across all three.
- lib/repo_tender/sync/engine.rb — `expand_orgs` builds the per-org record
  (success ≈128–131; failure ≈134–137); `build_new_state` does
  `orgs = prev.orgs.merge(org_records)` (≈293). The clobber is here — fix so the
  failure record does not lower known-good values.
- test/repo_tender/sync/engine_test.rb — the existing injected-forge seam and the
  Slice 2 G10 org-list-Failure test. Extend it; keep it green.
- test/repo_tender/state/store_test.rb — existing Org round-trip tests. Extend.

=== BOUNDARIES (may touch / must not touch / out of scope) ===

MAY EDIT (only as the spec describes):
  lib/repo_tender/state/store.rb   (ADD `last_error` to Org: Data.define +
                                    initialize default + to_h_compact + build_state
                                    + emit — nothing else)
  lib/repo_tender/sync/engine.rb   (expand_orgs / build_new_state ONLY: preserve
                                    prior repo_count + last_listed_at on org-list
                                    Failure, set last_error; do NOT change repo
                                    processing, concurrency, or the public
                                    call(config:, paths:) signature)
  test/repo_tender/state/store_test.rb   (ADD Org last_error round-trip cases)
  test/repo_tender/sync/engine_test.rb   (ADD the non-clobber test; keep G10 green)

MAY CREATE:
  docs/lanes/slice-4-02.md

MUST NOT TOUCH (failing the lane — Lane 01 owns these):
  lib/repo_tender/launchd/*, lib/repo_tender/log_rotator.rb,
  lib/repo_tender/cli/daemon.rb, lib/repo_tender/cli.rb,
  lib/repo_tender/cli/sync.rb, lib/repo_tender/paths.rb, lib/repo_tender.rb
  Also: sync/repo_plan.rb, scm/*, forge/*, config/*, cli/{repo,org,status,config}.rb,
  test/test_helper.rb, anything under docs/gates/

OUT OF SCOPE: any new gem; surfacing org state in the `status` CLI table (status
is per-repo; not this slice); any launchd/daemon work (that is Lane 01).

If a gate seems to force you toward a MUST-NOT-TOUCH file, STOP and record it as a
disagreement with the cited gate + file — do not edit it silently.

=== ACCEPTANCE GATES (frozen at docs/gates/slice-4.md — read-only) ===

G6 State::Store::Org carries `last_error` (round-trips through real state.yaml;
omitted when nil; existing Org/Repo/State behavior unchanged); G7 an org-list
Failure preserves prior repo_count + last_listed_at (NOT 0/nil) and sets
last_error, repos preserved, run does not abort, Slice 2 G10 test still passes;
G0 full suite green + lint + no new gems; G8 only in-scope files. Read
docs/gates/slice-4.md for the verbatim thresholds.
