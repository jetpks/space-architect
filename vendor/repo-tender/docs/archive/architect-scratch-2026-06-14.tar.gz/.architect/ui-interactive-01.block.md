ultrathink

Execute the architect spec below. Operating rules:

PHASE 0 — Before any code: reply with your plan and EVERY disagreement you have
with this spec, with reasons, citing real files in this repo. Silent compliance
is a failure. Silent scope additions are a failure. If you have no
disagreements, state what you checked before concluding the spec is sound.
Verify the named APIs/formats/versions against the live dependencies before
planning around them. PHASE 0 ALSO INCLUDES THE SPIKE (see OBJECTIVE) — run it,
record raw observations, and state your bars-vs-hand-rolled decision with the
evidence before you implement.

PHASE 1 — Freeze shared contracts (schemas/interfaces) in docs/ first. After
freeze they are read-only for everyone including you. The files under
docs/gates/ are read-only at all times — editing them fails the slice
regardless of results. (For this slice the reporter interface is ALREADY frozen
in lib/repo_tender/ui/reporter.rb and the engine seam is already wired — you are
implementing one more interface implementation, not changing the contract.)

PHASE 2 — Build YOUR LANE ONLY: exactly the files listed in BOUNDARIES. You are
the only lane this slice, working in the main checkout; files outside your set
are out of bounds — touching them fails your lane. No placeholder
implementations — search the codebase before implementing; full implementations
only. Verify your work by running the lane's gate commands and record the
verbatim output. Do NOT commit and do NOT run any git write command
(commit/add/branch/reset/checkout) — the architect commits and merges after
verification, and verifies you made no commits. Do NOT delete lock files or
escalate privileges if a command fails; record the exact error and continue.
Give every potentially long command an explicit timeout; if a runtime will not
start unattended (interactive prompt, server with no timeout), record the exact
failure in your lane report and route around it — never busy-wait or retry in a
loop. Any spike/scratch script goes under .architect/ (gitignored) or /tmp and
is NOT committed to the tree. When done, write your lane report to
docs/lanes/ui-interactive-01.md with RAW results only — tables, numbers, command
output, the spike observations — no interpretation, no "promising". Every status
claim must be backed by a command result from this run. Keep the report compact —
tables and numbers, not prose. End it with exactly one status line:
STATUS: COMPLETE | COMPLETE_WITH_CONCERNS (list them) | BLOCKED (exact blocker +
what you tried). Verdicts belong to the architect and the human. Persist until
your lane is fully handled end-to-end; do not stop at analysis or partial fixes.

=== OBJECTIVE (and why) ===

CLI-UX epic, Slice B — the NOVEL part: an interactive, colorful, in-place LIVE
PROGRESS renderer for the concurrent `sync` sweep, driven entirely by Async
fibers with NO Ruby Thread. Slice A already shipped the dual-mode seam
(`UI::Mode`, the `UI::Reporter` interface + `NullReporter`/`PlainReporter`/
`JsonReporter`) and wired the engine to emit events (`attach`/`run_started`/
`repo_started`/`repo_phase`/`repo_finished`/`repo_failed`/`run_finished`/`detach`
— see lib/repo_tender/sync/engine.rb lines 94, 95, 125, 126, 198, 209, 229, 247,
272, 310, 317). Those seams are no-ops under the default `NullReporter`. Your job:
add `UI::InteractiveReporter` (color + live progress) and select it from
`cli/sync.rb` when `mode.animate` is true. THE ENGINE IS ALREADY WIRED — DO NOT
TOUCH sync/engine.rb.

Why it matters: this delivers the epic's headline feature — live, delightful,
informative progress for a human running `sync` — while the non-interactive
paths (launchd/pipe/CI, already plain via Slice A) are unaffected. The hard
constraint (PRD §1) is NO Ruby Thread: every animated Ruby spinner gem
(`tty-spinner#auto_spin`, `whirly`, `cli-ui`) spawns a Thread and is OUT.
Animation is one render-loop fiber spawned as a child of the engine's Sync task.

THE SPIKE (PHASE 0, before you commit to a design — PRD §5 Slice B / §6 / research
OQ2 found NO prior art for socketry/async + a tty progress gem): write a throwaway
script (under .architect/ or /tmp, NOT committed) that drives a
`tty-progressbar::Multi` (and/or a hand-rolled `tty-cursor`+`pastel` multi-line
renderer) advanced SYNCHRONOUSLY from ≥3 `task.async` worker fibers under a
`Sync{}` block, with one render-loop fiber repainting on a bounded sleep cadence.
Observe: does it render cleanly (no flicker/corruption/interleaved writes)? Does
it tear down cleanly on completion AND when the task is stopped mid-run (cursor
restored via the fiber's `ensure`)? DECIDE: `tty-progressbar::Multi` vs the
hand-rolled `tty-cursor`+`pastel` fallback (PRD says the fallback is fully
acceptable and the seam is identical either way). Record raw observations + the
decision in PHASE 0 and the lane report. Then implement the chosen approach.

Key design facts (verify before relying on them):
- The render fiber MUST be a child of the engine task: `attach(task, total:)`
  spawns it via `task.async`. On completion `detach` stops it, does a final
  repaint, and restores the cursor + newline. On `^C` mid-run the engine's
  `Sync{}` block unwinds and Async cancels the child render fiber — so the
  CURSOR-RESTORE must live in the render fiber's own `ensure` block (engine.rb is
  frozen; you cannot add a `detach` to the interrupt path there). Verify Async
  runs a child task's `ensure` when the parent task is stopped — this is the
  teardown-ordering [CONFIRM] from PRD §6.
- The render loop suspends with `Kernel#sleep` / `task.sleep` inside the fiber
  (this yields to the reactor, per research F3) — NEVER `Thread.new`.
- `UI::Mode` (lib/repo_tender/ui/mode.rb) is FROZEN. It exposes plain readers
  `color`, `animate`, `quiet`, `format` (dry-struct attributes) — NOT `color?`/
  `animate?` predicates. Use the real readers. Do not modify mode.rb.
- Color via `Pastel.new(enabled: <the real color reader>)`. `enabled: false` is a
  pure passthrough (ANSI-color-free). Note `--no-color` on an interactive TTY
  yields `format==:pretty`, `animate==true`, `color==false` — so the
  InteractiveReporter CAN be built with color off and must still animate but emit
  no color SGR codes (G5).
- The single reactor serializes fiber resumption → the render fiber is the single
  writer to `out`; worker fibers only mutate per-repo indicator state via the
  reporter events. No mutex needed for the terminal.

=== OUTPUT FORMAT ===

Lane report at docs/lanes/ui-interactive-01.md, RAW only:
1. PHASE 0: plan, disagreements (numbered, each citing a real file), the SPIKE
   observations (what you ran, what you saw — flicker? corruption? clean
   teardown?), and the bars-vs-hand-rolled DECISION with reasons.
2. Confirmed gem versions (pastel, tty-cursor, tty-screen, tty-progressbar; and
   transitive tty-color/strings-ansi/unicode-display_width) — `bundle list` /
   Gemfile.lock excerpts.
3. Vendor review: the `grep -rnE "Thread\.(new|start)" $(bundle show <gem>)/lib`
   output for each of the 4 gems.
4. Gate→test mapping table: each of G0–G7 → test file + test name(s).
5. Verbatim command output: `bundle install` tail, `bundle exec rake test` tail
   (runs/assertions/failures/errors/skips), `bundle exec standardrb`,
   `git diff <freeze>.. -- Gemfile Gemfile.lock repo-tender.gemspec`,
   `ruby -W:no-experimental -Ilib bin/repo-tender --help`,
   `git diff --name-only <freeze>..`.
6. Confirmation that sync/engine.rb is UNCHANGED (`git diff --stat <freeze>.. --
   lib/repo_tender/sync/engine.rb` empty).
7. The exact STATUS line.

=== TOOL GUIDANCE (verification commands; verify-against-reality list) ===

Build/test (from AGENTS.md — the architect re-runs exactly these to judge):
  bundle install
  bundle exec rake test                                   # 291 baseline + new; 0 fail/err/skip
  bundle exec ruby -Itest test/repo_tender/ui/interactive_reporter_test.rb   # single file
  bundle exec standardrb            # 0
  bundle exec standardrb --fix      # autofix before reporting done
  ruby -W:no-experimental -Ilib bin/repo-tender --help    # exit 0, 5 groups

Verify against reality BEFORE coding:
- Latest current versions of pastel, tty-cursor, tty-screen, tty-progressbar
  (research saw 0.8.0 / 0.7.1 / 0.8.2 / 0.18.3 — confirm latest at build time via
  `gem list -r <gem>` or rubygems). Pin with `~>` in the gemspec.
- That each gem spawns NO Thread (source-read grep, item 3 above). `tty-progressbar`
  advances synchronously on the caller; confirm in its source.
- The real `UI::Mode` reader names (read lib/repo_tender/ui/mode.rb).
- The Async API you rely on: that `task.async` makes a child task, that
  `Kernel#sleep` inside it suspends the fiber (not the thread), and that a stopped
  parent task runs the child's `ensure`. Read the socketry/async source at
  ~/src/evergreen/github.com/socketry/async/ rather than guessing.
- The existing engine event seam + the RecordingReporter + real-temp-git test
  harness in test/repo_tender/sync/engine_test.rb (RecordingReporter at line 922;
  Slice-A G3 four-scenario test at ~line 1025; concurrency seam via
  make_config(concurrency:)). Reuse these patterns; do not reinvent or mock the
  engine. For animation tests, inject a StringIO/pseudo-TTY as `out`.
- The Slice-6 interrupt path: lib/repo_tender/cli.rb:84 `rescue Interrupt` → exit
  130; test/repo_tender/cli/interrupt_test.rb. These must stay green (G4).

=== BOUNDARIES (may touch / must not touch / out of scope) ===

MAY CREATE (new):
- lib/repo_tender/ui/interactive_reporter.rb
- lib/repo_tender/ui/spinner.rb  (ONLY if your chosen design needs a frame helper)
- test/repo_tender/ui/interactive_reporter_test.rb
- test/repo_tender/ui/spinner_test.rb  (only if spinner.rb exists)
- docs/lanes/ui-interactive-01.md  (your report)

MAY EXTEND (narrowly):
- repo-tender.gemspec  (add exactly the 4 gems, `~>` pins; nothing else)
- Gemfile.lock         (regenerated by `bundle install`)
- lib/repo_tender/cli/sync.rb  (add `require "repo_tender/ui/interactive_reporter"`
  and the `mode.animate` selection branch — DO NOT change `--repo` scoping, exit
  codes, log rotation, or the `synced N repo(s)` summary)
- test/repo_tender/cli/sync_test.rb  (ADDITIONS ONLY — assert the selection branch)

MUST NOT TOUCH:
- lib/repo_tender/sync/engine.rb  (the event seam is ALREADY wired — any diff fails the slice)
- lib/repo_tender/ui/{mode,reporter,plain_reporter,json_reporter}.rb
- lib/repo_tender/cli.rb, lib/repo_tender/cli/options.rb
- lib/repo_tender/cli/{repo,org,status,config,daemon}.rb
- config/*, scm/*, forge/*, launchd/*, state/*, sync/repo_plan.rb
- paths.rb, shell.rb, log_rotator.rb, Gemfile, test_helper.rb
- any other existing test file
- anything under docs/gates/

OUT OF SCOPE (Slice C — do NOT do these now):
- rolling Mode/pastel color + spinners into repo/org/status/config/daemon
- the quick-op spinner for `org add`/`org list`/`sync --repo`
Slice B is `sync`'s animated reporter only.

=== DISAGREEMENT RULINGS (from last session) ===

None — this is the first dispatch of Slice B. Raise all PHASE-0 disagreements
fresh, citing real files.

=== ACCEPTANCE GATES (frozen at docs/gates/ui-interactive.md — read-only) ===

G0 — suite green & reproducible; exactly 4 new gems (pastel, tty-cursor,
     tty-screen, tty-progressbar), `~>` pinned, MIT, resolved; 291 baseline +
     new all pass, 0 fail/err/skip; standardrb 0; `--help` 5 groups.
G1 — NO Ruby Thread: `Thread.list` unchanged across attach→detach on a ≥3-repo
     real-reactor run; static grep for Thread.new/start in the new file(s) empty.
G2 — render fiber is a child of the engine task (`task.async`), torn down by
     `detach` (no live fiber after; final repaint + cursor restore); does not
     block barrier.wait; bounded repaint cadence (not a busy-loop).
G3 — N concurrent indicators advance independently; single-writer, no corrupted/
     interleaved output; all complete; works for whichever primitive the spike picks.
G4 — clean ^C teardown: cursor-restore emitted on the interrupt unwind (via the
     render fiber's `ensure`), no leaked fiber/thread, Slice-6 exit-130 path
     un-regressed. Real-TTY ^C visual is M1 (human).
G5 — color gated by Mode (`Pastel.new(enabled: <color reader>)`; color-off → no
     color SGR codes, still animates); `cli/sync.rb` builds InteractiveReporter
     ONLY when `mode.animate`, else Plain (or Json for `--json`); `--repo`/exit
     codes/`synced N repo(s)` unchanged.
G6 — 4 gems vendor-reviewed (no Thread, source-read grep) + M1 manual real-TTY
     smoke (HUMAN-RUN, post-judgment).
G7 — only in-scope files; sync/engine.rb UNCHANGED; no builder commits; no gem
     beyond the 4; nothing under docs/gates/ changed.

Read the full gate text at docs/gates/ui-interactive.md for the exact thresholds
and the frozen Lane file set. <freeze> is the freeze commit recorded in the lane
report header by the architect at dispatch.
